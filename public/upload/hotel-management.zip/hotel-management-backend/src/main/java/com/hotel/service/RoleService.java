package com.hotel.service;

import com.hotel.entity.Role;
import com.hotel.mapper.RoleMapper;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class RoleService {
    private final RoleMapper roleMapper;

    public RoleService(RoleMapper roleMapper) {
        this.roleMapper = roleMapper;
    }

    public List<Role> findAll() {
        return roleMapper.findAll();
    }

    public Role findById(Integer roleId) {
        return roleMapper.findById(roleId);
    }

    public Role findByName(String roleName) {
        return roleMapper.findByName(roleName);
    }
}
