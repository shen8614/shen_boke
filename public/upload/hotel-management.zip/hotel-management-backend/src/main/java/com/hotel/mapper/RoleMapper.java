package com.hotel.mapper;

import com.hotel.entity.Role;
import org.apache.ibatis.annotations.Mapper;
import java.util.List;

@Mapper
public interface RoleMapper {
    List<Role> findAll();
    Role findById(Integer roleId);
    Role findByName(String roleName);
}
