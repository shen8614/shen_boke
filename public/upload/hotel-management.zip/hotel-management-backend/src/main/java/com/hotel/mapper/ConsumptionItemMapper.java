package com.hotel.mapper;

import com.hotel.entity.ConsumptionItem;
import org.apache.ibatis.annotations.Mapper;
import java.util.List;

@Mapper
public interface ConsumptionItemMapper {
    List<ConsumptionItem> findAll();
    ConsumptionItem findById(Integer itemId);
    int insert(ConsumptionItem item);
    int update(ConsumptionItem item);
    int deleteById(Integer itemId);
}
