package com.hotel.entity;

import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class Room {
    private Integer roomId;
    private String roomNumber;
    private Integer typeId;
    private Integer floor;
    private BigDecimal standardPrice;
    private String status;
    private String facilities;
    private Integer storeId;
    private LocalDateTime createdAt;

    private String typeName;
    private BigDecimal basePrice;
}
