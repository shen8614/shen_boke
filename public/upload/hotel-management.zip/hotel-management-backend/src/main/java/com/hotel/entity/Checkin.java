package com.hotel.entity;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class Checkin {
    private Integer checkinId;
    private Integer reservationId;
    private Integer guestId;
    private Integer roomId;
    private LocalDateTime checkinTime;
    private LocalDateTime checkoutTime;
    private String status;
    private Integer staffId;
    private LocalDateTime createdAt;

    private String guestName;
    private String roomNumber;
    private String staffName;
    private String phone;
    private String storeName;
    private Integer storeId;
    private String typeName;
}
