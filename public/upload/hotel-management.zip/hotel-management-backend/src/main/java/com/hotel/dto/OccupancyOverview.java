package com.hotel.dto;

import lombok.Data;

@Data
public class OccupancyOverview {
    private Long totalRooms;
    private Long occupiedRooms;
    private Long availableRooms;
    private Long opsRooms;
    private Double occupancyRatePercent;
}
