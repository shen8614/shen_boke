package com.hotel.mapper;

import com.hotel.entity.Room;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;

@Mapper
public interface RoomMapper {
    List<Room> findAll();
    Room findById(@Param("roomId") Integer roomId);
    List<Room> findByStoreId(@Param("storeId") Integer storeId);
    List<Room> findByStatus(@Param("status") String status);
    int insert(Room room);
    int update(Room room);
    int deleteById(@Param("roomId") Integer roomId);
    int updateStatus(@Param("roomId") Integer roomId, @Param("status") String status);
}
