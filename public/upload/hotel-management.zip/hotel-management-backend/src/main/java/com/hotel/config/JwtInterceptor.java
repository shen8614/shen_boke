package com.hotel.config;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

@Component
public class JwtInterceptor implements HandlerInterceptor {
    @Autowired
    private JwtUtil jwtUtil;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        if ("OPTIONS".equals(request.getMethod())) {
            return true;
        }

        String token = request.getHeader("Authorization");
        if (token != null && token.startsWith("Bearer ")) {
            token = token.substring(7);
            try {
                if (!jwtUtil.isTokenExpired(token)) {
                    String username = jwtUtil.getUsernameFromToken(token);
                    Integer userId = jwtUtil.getUserIdFromToken(token);
                    String roleName = jwtUtil.getRoleNameFromToken(token);
                    Integer storeId = jwtUtil.getStoreIdFromToken(token);
                    request.setAttribute("username", username);
                    request.setAttribute("userId", userId);
                    request.setAttribute("roleName", roleName);
                    request.setAttribute("storeId", storeId);
                    System.out.println("[JWT-DEBUG] username=" + username + " roleName=" + roleName + " storeId=" + storeId + " userId=" + userId);
                    return true;
                }
            } catch (Exception e) {
            }
        }
        return false;
    }
}
