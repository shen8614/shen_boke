package com.hotel.service;

import com.hotel.entity.Bill;
import com.hotel.mapper.BillMapper;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class BillService {
    private final BillMapper billMapper;

    public BillService(BillMapper billMapper) {
        this.billMapper = billMapper;
    }

    public List<Bill> findAll() {
        return billMapper.findAll();
    }

    public Bill findById(Integer billId) {
        return billMapper.findById(billId);
    }

    public Bill findByCheckinId(Integer checkinId) {
        return billMapper.findByCheckinId(checkinId);
    }

    public int insert(Bill bill) {
        return billMapper.insert(bill);
    }

    public int update(Bill bill) {
        return billMapper.update(bill);
    }

    public int deleteById(Integer billId) {
        return billMapper.deleteById(billId);
    }

    public String findMaxInvoiceNumber() {
        return billMapper.findMaxInvoiceNumber();
    }

    public List<Bill> findByCheckoutTimeRange(String startTime, String endTime, Integer storeId) {
        return billMapper.findByCheckoutTimeRange(startTime, endTime, storeId);
    }
}
