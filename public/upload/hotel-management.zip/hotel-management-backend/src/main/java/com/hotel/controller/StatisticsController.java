package com.hotel.controller;

import com.hotel.common.Result;
import com.hotel.config.JwtUtil;
import com.hotel.dto.*;
import com.hotel.entity.Bill;
import com.hotel.service.StatisticsService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/statistics")
@CrossOrigin
public class StatisticsController {

    private final StatisticsService statisticsService;
    private final JwtUtil jwtUtil;

    public StatisticsController(StatisticsService statisticsService, JwtUtil jwtUtil) {
        this.statisticsService = statisticsService;
        this.jwtUtil = jwtUtil;
    }

    private void assertAdmin(HttpServletRequest request) {
        String header = request.getHeader("Authorization");
        if (header == null || !header.startsWith("Bearer ")) {
            throw new SecurityException("未登录");
        }
        String role = jwtUtil.getRoleNameFromToken(header.substring(7));
        if (!"管理员".equals(role)) {
            throw new SecurityException("仅管理员可访问统计数据");
        }
    }

    @GetMapping("/occupancy")
    public Result<OccupancyOverview> occupancy(HttpServletRequest request, @RequestParam(required = false) Integer storeId) {
        try {
            assertAdmin(request);
        } catch (SecurityException e) {
            return Result.error(403, e.getMessage());
        }
        return Result.success(statisticsService.getOccupancyOverview(storeId));
    }

    @GetMapping("/occupancy-by-store")
    public Result<List<StoreOccupancyRow>> occupancyByStore(HttpServletRequest request) {
        try {
            assertAdmin(request);
        } catch (SecurityException e) {
            return Result.error(403, e.getMessage());
        }
        return Result.success(statisticsService.getOccupancyByStore());
    }

    @GetMapping("/revenue-analysis")
    public Result<RevenueAnalysisVO> revenueAnalysis(HttpServletRequest request,
                                                    @RequestParam String startDate,
                                                    @RequestParam String endDate,
                                                    @RequestParam(required = false) Integer storeId) {
        try {
            assertAdmin(request);
        } catch (SecurityException e) {
            return Result.error(403, e.getMessage());
        }
        try {
            LocalDate start = LocalDate.parse(startDate);
            LocalDate end = LocalDate.parse(endDate);
            if (end.isBefore(start)) {
                return Result.error("结束日期不能早于开始日期");
            }
            return Result.success(statisticsService.getRevenueAnalysis(start, end, storeId));
        } catch (Exception e) {
            return Result.error("日期格式应为 yyyy-MM-dd");
        }
    }

    @GetMapping("/report-bills")
    public Result<List<Bill>> reportBills(HttpServletRequest request,
                                          @RequestParam String startDate,
                                          @RequestParam String endDate,
                                          @RequestParam(required = false) Integer storeId) {
        try {
            assertAdmin(request);
        } catch (SecurityException e) {
            return Result.error(403, e.getMessage());
        }
        try {
            LocalDate start = LocalDate.parse(startDate);
            LocalDate end = LocalDate.parse(endDate);
            if (end.isBefore(start)) {
                return Result.error("结束日期不能早于开始日期");
            }
            return Result.success(statisticsService.getReportBills(start, end, storeId));
        } catch (Exception e) {
            return Result.error("日期格式应为 yyyy-MM-dd");
        }
    }
}
