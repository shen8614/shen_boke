package com.hotel.entity;

import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class RoomType {
    private Integer typeId;
    private String typeName;
    private String description;
    private BigDecimal basePrice;
    private Integer maxOccupancy;
    private Integer storeId;
    private String image;
    private LocalDateTime createdAt;

    private String storeName;
}
