package com.hotel.service;

import com.hotel.entity.ConsumptionItem;
import com.hotel.mapper.ConsumptionItemMapper;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ConsumptionItemService {
    private final ConsumptionItemMapper consumptionItemMapper;

    public ConsumptionItemService(ConsumptionItemMapper consumptionItemMapper) {
        this.consumptionItemMapper = consumptionItemMapper;
    }

    public List<ConsumptionItem> findAll() {
        return consumptionItemMapper.findAll();
    }

    public ConsumptionItem findById(Integer itemId) {
        return consumptionItemMapper.findById(itemId);
    }
}
