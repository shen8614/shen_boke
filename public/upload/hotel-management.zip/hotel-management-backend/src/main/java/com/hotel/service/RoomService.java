package com.hotel.service;

import com.hotel.entity.Room;
import com.hotel.mapper.RoomMapper;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class RoomService {
    private final RoomMapper roomMapper;

    public RoomService(RoomMapper roomMapper) {
        this.roomMapper = roomMapper;
    }

    public List<Room> findAll() {
        return roomMapper.findAll();
    }

    public Room findById(Integer roomId) {
        return roomMapper.findById(roomId);
    }

    public List<Room> findByStoreId(Integer storeId) {
        return roomMapper.findByStoreId(storeId);
    }

    public List<Room> findByStatus(String status) {
        return roomMapper.findByStatus(status);
    }

    public int insert(Room room) {
        return roomMapper.insert(room);
    }

    public int update(Room room) {
        return roomMapper.update(room);
    }

    public int deleteById(Integer roomId) {
        return roomMapper.deleteById(roomId);
    }

    public int updateStatus(Integer roomId, String status) {
        return roomMapper.updateStatus(roomId, status);
    }
}
