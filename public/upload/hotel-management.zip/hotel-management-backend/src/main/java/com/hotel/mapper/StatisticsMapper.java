package com.hotel.mapper;

import com.hotel.dto.*;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface StatisticsMapper {

    OccupancyOverview selectRoomOccupancyCounts(@Param("storeId") Integer storeId);

    List<StoreOccupancyRow> selectOccupancyByStore();

    RevenueSummaryDto selectRevenueSummary(@Param("startTime") String startTime,
                                           @Param("endTime") String endTime,
                                           @Param("storeId") Integer storeId);

    List<RevenueTrendPoint> selectRevenueTrend(@Param("startTime") String startTime,
                                               @Param("endTime") String endTime,
                                               @Param("storeId") Integer storeId);

    List<PaymentMixRow> selectPaymentMix(@Param("startTime") String startTime,
                                         @Param("endTime") String endTime,
                                         @Param("storeId") Integer storeId);
}
