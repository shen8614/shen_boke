package com.hotel.controller;

import com.hotel.common.Result;
import com.hotel.entity.Store;
import com.hotel.service.StoreService;
import org.springframework.web.bind.annotation.*;
import jakarta.servlet.http.HttpServletRequest;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/stores")
@CrossOrigin
public class StoreController {
    private final StoreService storeService;

    public StoreController(StoreService storeService) {
        this.storeService = storeService;
    }

    @GetMapping
    public Result<List<Store>> findAll(HttpServletRequest request) {
        String roleName = (String) request.getAttribute("roleName");
        Integer storeId = (Integer) request.getAttribute("storeId");
        if (!"管理员".equals(roleName) && storeId != null) {
            List<Store> all = storeService.findAll();
            return Result.success(all.stream().filter(s -> storeId.equals(s.getStoreId())).collect(Collectors.toList()));
        }
        return Result.success(storeService.findAll());
    }

    @GetMapping("/{id}")
    public Result<Store> findById(@PathVariable Integer id, HttpServletRequest request) {
        String roleName = (String) request.getAttribute("roleName");
        Integer userStoreId = (Integer) request.getAttribute("storeId");
        if (!"管理员".equals(roleName)) {
            if (userStoreId == null || !userStoreId.equals(id)) {
                return Result.error(403, "无权访问其他门店信息");
            }
        }
        return Result.success(storeService.findById(id));
    }

    @PostMapping
    public Result<Integer> insert(@RequestBody Store store, HttpServletRequest request) {
        String roleName = (String) request.getAttribute("roleName");
        if ("管理员".equals(roleName)) {
            return Result.success(storeService.insert(store));
        }
        return Result.error(403, "仅管理员可创建门店");
    }

    @PutMapping
    public Result<Integer> update(@RequestBody Store store, HttpServletRequest request) {
        String roleName = (String) request.getAttribute("roleName");
        Integer userStoreId = (Integer) request.getAttribute("storeId");
        if (!"管理员".equals(roleName) && userStoreId != null) {
            if (!userStoreId.equals(store.getStoreId())) {
                return Result.error(403, "无权修改其他门店信息");
            }
        }
        return Result.success(storeService.update(store));
    }

    @DeleteMapping("/{id}")
    public Result<Integer> deleteById(@PathVariable Integer id, HttpServletRequest request) {
        String roleName = (String) request.getAttribute("roleName");
        if (!"管理员".equals(roleName)) {
            return Result.error(403, "仅管理员可删除门店");
        }
        return Result.success(storeService.deleteById(id));
    }
}
