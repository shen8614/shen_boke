package com.hotel.entity;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class Role {
    private Integer roleId;
    private String roleName;
    private String description;
    private LocalDateTime createdAt;
}
