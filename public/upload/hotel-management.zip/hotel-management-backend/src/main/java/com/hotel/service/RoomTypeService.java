package com.hotel.service;

import com.hotel.entity.RoomType;
import com.hotel.mapper.RoomTypeMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

@Service
public class RoomTypeService {
    private final RoomTypeMapper roomTypeMapper;
    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(RoomTypeService.class);

    @Value("${file.upload-dir:./uploads}")
    private String uploadDir;

    public RoomTypeService(RoomTypeMapper roomTypeMapper) {
        this.roomTypeMapper = roomTypeMapper;
    }

    public List<RoomType> findAll() {
        return roomTypeMapper.findAll();
    }

    public RoomType findById(Integer typeId) {
        return roomTypeMapper.findById(typeId);
    }

    public int insert(RoomType roomType) {
        return roomTypeMapper.insert(roomType);
    }

    public int update(RoomType roomType) {
        RoomType existing = roomTypeMapper.findById(roomType.getTypeId());
        if (existing != null && existing.getImage() != null && !existing.getImage().isEmpty()
                && !existing.getImage().equals(roomType.getImage())) {
            deleteImageFile(existing.getImage(), "room-types");
        }
        return roomTypeMapper.update(roomType);
    }

    public int deleteById(Integer typeId) {
        RoomType roomType = roomTypeMapper.findById(typeId);
        if (roomType != null) {
            deleteImageFile(roomType.getImage(), "room-types");
        }
        return roomTypeMapper.deleteById(typeId);
    }

    private void deleteImageFile(String relativePath, String folder) {
        if (relativePath == null || relativePath.isEmpty()) return;
        try {
            String filename = relativePath.substring(relativePath.lastIndexOf('/') + 1);
            Path basePath = Paths.get(uploadDir).toAbsolutePath().normalize();
            Path filePath = basePath.resolve(folder).resolve(filename);
            Files.deleteIfExists(filePath);
            log.info("已删除旧图片: {}", relativePath);
        } catch (Exception e) {
            log.warn("删除图片文件失败: {} - {}", relativePath, e.getMessage());
        }
    }
}
