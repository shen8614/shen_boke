package com.hotel.entity;

import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class ConsumptionItem {
    private Integer itemId;
    private String itemName;
    private BigDecimal price;
    private String category;
    private LocalDateTime createdAt;
}
