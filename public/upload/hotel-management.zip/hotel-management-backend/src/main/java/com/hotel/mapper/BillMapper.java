package com.hotel.mapper;

import com.hotel.entity.Bill;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;

@Mapper
public interface BillMapper {
    List<Bill> findAll();
    Bill findById(@Param("billId") Integer billId);
    Bill findByCheckinId(@Param("checkinId") Integer checkinId);
    List<Bill> findByInvoiceStatus(@Param("invoiceStatus") String invoiceStatus);
    int insert(Bill bill);
    int update(Bill bill);
    int deleteById(@Param("billId") Integer billId);
    String findMaxInvoiceNumber();

    List<Bill> findByCheckoutTimeRange(@Param("startTime") String startTime,
                                       @Param("endTime") String endTime,
                                       @Param("storeId") Integer storeId);
}
