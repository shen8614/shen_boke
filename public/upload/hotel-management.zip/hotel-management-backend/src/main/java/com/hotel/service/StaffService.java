package com.hotel.service;

import com.hotel.entity.Staff;
import com.hotel.mapper.StaffMapper;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class StaffService {
    private final StaffMapper staffMapper;

    public StaffService(StaffMapper staffMapper) {
        this.staffMapper = staffMapper;
    }

    public List<Staff> findAll() {
        return staffMapper.findAll();
    }

    public Staff findById(Integer staffId) {
        return staffMapper.findById(staffId);
    }

    public Staff findByUsername(String username) {
        return staffMapper.findByUsername(username);
    }

    public int insert(Staff staff) {
        return staffMapper.insert(staff);
    }

    public int update(Staff staff) {
        return staffMapper.update(staff);
    }

    public int deleteById(Integer staffId) {
        return staffMapper.deleteById(staffId);
    }
}
