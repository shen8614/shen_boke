package com.hotel.mapper;

import com.hotel.entity.Staff;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;

@Mapper
public interface StaffMapper {
    List<Staff> findAll();
    Staff findById(@Param("staffId") Integer staffId);
    Staff findByUsername(@Param("username") String username);
    int insert(Staff staff);
    int update(Staff staff);
    int deleteById(@Param("staffId") Integer staffId);
}
