package com.hotel.controller;

import com.hotel.common.Result;
import com.hotel.config.JwtUtil;
import com.hotel.dto.LoginRequest;
import com.hotel.dto.LoginResponse;
import com.hotel.entity.Guest;
import com.hotel.entity.Staff;
import com.hotel.service.GuestService;
import com.hotel.service.StaffService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin
public class AuthController {
    private final StaffService staffService;
    private final GuestService guestService;
    private final JwtUtil jwtUtil;

    public AuthController(StaffService staffService, GuestService guestService, JwtUtil jwtUtil) {
        this.staffService = staffService;
        this.guestService = guestService;
        this.jwtUtil = jwtUtil;
    }

    @PostMapping("/login")
    public Result<LoginResponse> login(@RequestBody LoginRequest request) {
        if ("staff".equals(request.getUserType())) {
            Staff staff = staffService.findByUsername(request.getUsername());
            if (staff == null || !staff.getPassword().equals(request.getPassword())) {
                return Result.error("用户名或密码错误");
            }
            LoginResponse response = new LoginResponse();
            response.setId(staff.getStaffId());
            response.setUsername(staff.getUsername());
            response.setName(staff.getName());
            response.setRoleName(staff.getRoleName());
            response.setRoleId(staff.getRoleId());
            response.setStoreId(staff.getStoreId());
            response.setStoreName(staff.getStoreName());
            response.setToken(jwtUtil.generateToken(staff.getStaffId(), staff.getUsername(), staff.getRoleName(), staff.getStoreId()));
            return Result.success(response);
        } else if ("guest".equals(request.getUserType())) {
            Guest guest = guestService.findByPhone(request.getUsername());
            if (guest == null || !guest.getPassword().equals(request.getPassword())) {
                return Result.error("手机号或密码错误");
            }
            LoginResponse response = new LoginResponse();
            response.setId(guest.getGuestId());
            response.setUsername(guest.getPhone());
            response.setName(guest.getName());
            response.setRoleName("客人");
            response.setToken(jwtUtil.generateToken(guest.getGuestId(), guest.getPhone(), "客人", null));
            return Result.success(response);
        }
        return Result.error("无效的用户类型");
    }

    @PostMapping("/guest/register")
    public Result<Guest> register(@RequestBody Guest guest) {
        if (guestService.findByPhone(guest.getPhone()) != null) {
            return Result.error("该手机号已注册");
        }
        if (guestService.findByIdNumber(guest.getIdNumber()) != null) {
            return Result.error("该证件号码已被注册");
        }
        guestService.insert(guest);
        return Result.success(guest);
    }
}
