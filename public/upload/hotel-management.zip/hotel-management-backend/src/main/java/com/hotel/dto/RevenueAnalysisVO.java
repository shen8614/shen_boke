package com.hotel.dto;

import lombok.Data;
import java.util.List;

@Data
public class RevenueAnalysisVO {
    private RevenueSummaryDto summary;
    private List<RevenueTrendPoint> trend;
    private List<PaymentMixRow> paymentMix;
}
