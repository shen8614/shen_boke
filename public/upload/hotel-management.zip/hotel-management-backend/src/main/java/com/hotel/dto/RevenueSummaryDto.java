package com.hotel.dto;

import lombok.Data;
import java.math.BigDecimal;

@Data
public class RevenueSummaryDto {
    private BigDecimal totalActualPay;
    private BigDecimal totalRoomCharge;
    private BigDecimal totalOtherCharge;
    private Integer billCount;
    private BigDecimal avgActualPay;
}
