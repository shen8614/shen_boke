package com.hotel.mapper;

import com.hotel.entity.RoomType;
import org.apache.ibatis.annotations.Mapper;
import java.util.List;

@Mapper
public interface RoomTypeMapper {
    List<RoomType> findAll();
    RoomType findById(Integer typeId);
    int insert(RoomType roomType);
    int update(RoomType roomType);
    int deleteById(Integer typeId);
}
