package com.hotel.service;

import com.hotel.entity.Store;
import com.hotel.mapper.StoreMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

@Service
public class StoreService {
    private final StoreMapper storeMapper;
    private static final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(StoreService.class);

    @Value("${file.upload-dir:./uploads}")
    private String uploadDir;

    public StoreService(StoreMapper storeMapper) {
        this.storeMapper = storeMapper;
    }

    public List<Store> findAll() {
        return storeMapper.findAll();
    }

    public Store findById(Integer storeId) {
        return storeMapper.findById(storeId);
    }

    public int insert(Store store) {
        return storeMapper.insert(store);
    }

    public int update(Store store) {
        Store existing = storeMapper.findById(store.getStoreId());
        if (existing != null && existing.getImage() != null && !existing.getImage().isEmpty()
                && !existing.getImage().equals(store.getImage())) {
            deleteImageFile(existing.getImage(), "stores");
        }
        return storeMapper.update(store);
    }

    public int deleteById(Integer storeId) {
        Store store = storeMapper.findById(storeId);
        if (store != null) {
            deleteImageFile(store.getImage(), "stores");
        }
        return storeMapper.deleteById(storeId);
    }

    private void deleteImageFile(String relativePath, String folder) {
        if (relativePath == null || relativePath.isEmpty()) return;
        try {
            String filename = relativePath.substring(relativePath.lastIndexOf('/') + 1);
            Path basePath = Paths.get(uploadDir).toAbsolutePath().normalize();
            Path filePath = basePath.resolve(folder).resolve(filename);
            Files.deleteIfExists(filePath);
            log.info("已删除旧图片: {}", relativePath);
        } catch (Exception e) {
            log.warn("删除图片文件失败: {} - {}", relativePath, e.getMessage());
        }
    }
}
