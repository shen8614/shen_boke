package com.hotel.controller;

import com.hotel.common.Result;
import com.hotel.entity.Reservation;
import com.hotel.service.ReservationService;
import org.springframework.web.bind.annotation.*;
import jakarta.servlet.http.HttpServletRequest;

import java.util.List;

@RestController
@RequestMapping("/api/reservations")
@CrossOrigin
public class ReservationController {
    private final ReservationService reservationService;

    public ReservationController(ReservationService reservationService) {
        this.reservationService = reservationService;
    }

    @GetMapping
    public Result<List<Reservation>> findAll(HttpServletRequest request) {
        String roleName = (String) request.getAttribute("roleName");
        Integer storeId = (Integer) request.getAttribute("storeId");
        System.out.println("[RESERVATION-DEBUG] findAll called: roleName=" + roleName + " storeId=" + storeId);
        if (!"管理员".equals(roleName) && storeId != null) {
            System.out.println("[RESERVATION-DEBUG] Using findAllByStoreId with storeId=" + storeId);
            return Result.success(reservationService.findAllByStoreId(storeId));
        }
        System.out.println("[RESERVATION-DEBUG] Using findAll (full access)");
        return Result.success(reservationService.findAll());
    }

    @GetMapping("/debug-token")
    public Result<?> debugToken(HttpServletRequest request) {
        return Result.success(java.util.Map.of(
            "roleName", request.getAttribute("roleName"),
            "storeId", request.getAttribute("storeId"),
            "userId", request.getAttribute("userId"),
            "username", request.getAttribute("username")
        ));
    }

    @GetMapping("/{id}")
    public Result<Reservation> findById(@PathVariable Integer id) {
        return Result.success(reservationService.findById(id));
    }

    @GetMapping("/guest/{guestId}")
    public Result<List<Reservation>> findByGuestId(@PathVariable Integer guestId) {
        return Result.success(reservationService.findByGuestId(guestId));
    }

    @GetMapping("/status/{status}")
    public Result<List<Reservation>> findByStatus(@PathVariable String status, HttpServletRequest request) {
        String roleName = (String) request.getAttribute("roleName");
        Integer storeId = (Integer) request.getAttribute("storeId");
        if (!"管理员".equals(roleName) && storeId != null) {
            return Result.success(reservationService.findByStatusAndStoreId(status, storeId));
        }
        return Result.success(reservationService.findByStatus(status));
    }

    @PostMapping
    public Result<Integer> insert(@RequestBody Reservation reservation, HttpServletRequest request) {
        String roleName = (String) request.getAttribute("roleName");
        Integer userStoreId = (Integer) request.getAttribute("storeId");
        if (!"管理员".equals(roleName) && userStoreId != null) {
            if (reservation.getStoreId() == null || !userStoreId.equals(reservation.getStoreId())) {
                return Result.error(403, "无权为其他门店创建预订");
            }
        }
        return Result.success(reservationService.insert(reservation));
    }

    @PutMapping
    public Result<Integer> update(@RequestBody Reservation reservation, HttpServletRequest request) {
        String roleName = (String) request.getAttribute("roleName");
        Integer userStoreId = (Integer) request.getAttribute("storeId");
        if (!"管理员".equals(roleName) && userStoreId != null) {
            Reservation existing = reservationService.findById(reservation.getReservationId());
            if (existing != null && !userStoreId.equals(existing.getStoreId())) {
                return Result.error(403, "无权操作其他门店的预订");
            }
        }
        return Result.success(reservationService.update(reservation));
    }

    @DeleteMapping("/{id}")
    public Result<Integer> deleteById(@PathVariable Integer id, HttpServletRequest request) {
        String roleName = (String) request.getAttribute("roleName");
        Integer userStoreId = (Integer) request.getAttribute("storeId");
        if (!"管理员".equals(roleName) && userStoreId != null) {
            Reservation existing = reservationService.findById(id);
            if (existing != null && !userStoreId.equals(existing.getStoreId())) {
                return Result.error(403, "无权删除其他门店的预订");
            }
        }
        return Result.success(reservationService.deleteById(id));
    }

    @PutMapping("/{id}/status")
    public Result<Integer> updateStatus(@PathVariable Integer id, @RequestParam String status, HttpServletRequest request) {
        String roleName = (String) request.getAttribute("roleName");
        Integer userStoreId = (Integer) request.getAttribute("storeId");
        if (!"管理员".equals(roleName) && userStoreId != null) {
            Reservation existing = reservationService.findById(id);
            if (existing != null && !userStoreId.equals(existing.getStoreId())) {
                return Result.error(403, "无权操作其他门店的预订");
            }
        }
        return Result.success(reservationService.updateStatus(id, status));
    }
}
