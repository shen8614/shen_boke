package com.hotel.service;

import com.hotel.entity.Reservation;
import com.hotel.mapper.ReservationMapper;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ReservationService {
    private final ReservationMapper reservationMapper;

    public ReservationService(ReservationMapper reservationMapper) {
        this.reservationMapper = reservationMapper;
    }

    public List<Reservation> findAll() {
        return reservationMapper.findAll();
    }

    public List<Reservation> findAllByStoreId(Integer storeId) {
        return reservationMapper.findAllByStoreId(storeId);
    }

    public Reservation findById(Integer reservationId) {
        return reservationMapper.findById(reservationId);
    }

    public List<Reservation> findByGuestId(Integer guestId) {
        return reservationMapper.findByGuestId(guestId);
    }

    public List<Reservation> findByStatus(String status) {
        return reservationMapper.findByStatus(status);
    }

    public List<Reservation> findByStatusAndStoreId(String status, Integer storeId) {
        return reservationMapper.findByStatusAndStoreId(status, storeId);
    }

    public int insert(Reservation reservation) {
        return reservationMapper.insert(reservation);
    }

    public int update(Reservation reservation) {
        return reservationMapper.update(reservation);
    }

    public int deleteById(Integer reservationId) {
        return reservationMapper.deleteById(reservationId);
    }

    public int updateStatus(Integer reservationId, String status) {
        return reservationMapper.updateStatus(reservationId, status);
    }
}
