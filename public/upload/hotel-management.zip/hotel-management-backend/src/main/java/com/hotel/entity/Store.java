package com.hotel.entity;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class Store {
    private Integer storeId;
    private String storeName;
    private String address;
    private String phone;
    private String description;
    private String image;
    private LocalDateTime createdAt;
}
