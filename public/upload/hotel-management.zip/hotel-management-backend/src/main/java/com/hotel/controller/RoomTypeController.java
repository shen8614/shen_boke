package com.hotel.controller;

import com.hotel.common.Result;
import com.hotel.entity.RoomType;
import com.hotel.service.RoomTypeService;
import org.springframework.web.bind.annotation.*;
import jakarta.servlet.http.HttpServletRequest;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/room-types")
@CrossOrigin
public class RoomTypeController {
    private final RoomTypeService roomTypeService;

    public RoomTypeController(RoomTypeService roomTypeService) {
        this.roomTypeService = roomTypeService;
    }

    @GetMapping
    public Result<List<RoomType>> findAll(HttpServletRequest request) {
        String roleName = (String) request.getAttribute("roleName");
        Integer storeId = (Integer) request.getAttribute("storeId");
        if (!"管理员".equals(roleName) && storeId != null) {
            List<RoomType> all = roomTypeService.findAll();
            return Result.success(all.stream().filter(rt -> storeId.equals(rt.getStoreId())).collect(Collectors.toList()));
        }
        return Result.success(roomTypeService.findAll());
    }

    @GetMapping("/{id}")
    public Result<RoomType> findById(@PathVariable Integer id) {
        return Result.success(roomTypeService.findById(id));
    }

    @PostMapping
    public Result<Integer> insert(@RequestBody RoomType roomType, HttpServletRequest request) {
        String roleName = (String) request.getAttribute("roleName");
        Integer userStoreId = (Integer) request.getAttribute("storeId");
        if (!"管理员".equals(roleName) && userStoreId != null) {
            roomType.setStoreId(userStoreId);
        }
        return Result.success(roomTypeService.insert(roomType));
    }

    @PutMapping
    public Result<Integer> update(@RequestBody RoomType roomType, HttpServletRequest request) {
        String roleName = (String) request.getAttribute("roleName");
        Integer userStoreId = (Integer) request.getAttribute("storeId");
        if (!"管理员".equals(roleName) && userStoreId != null) {
            RoomType existing = roomTypeService.findById(roomType.getTypeId());
            if (existing != null && !userStoreId.equals(existing.getStoreId())) {
                return Result.error(403, "无权操作其他门店的房型");
            }
        }
        return Result.success(roomTypeService.update(roomType));
    }

    @DeleteMapping("/{id}")
    public Result<Integer> deleteById(@PathVariable Integer id, HttpServletRequest request) {
        String roleName = (String) request.getAttribute("roleName");
        Integer userStoreId = (Integer) request.getAttribute("storeId");
        if (!"管理员".equals(roleName) && userStoreId != null) {
            RoomType existing = roomTypeService.findById(id);
            if (existing != null && !userStoreId.equals(existing.getStoreId())) {
                return Result.error(403, "无权删除其他门店的房型");
            }
        }
        return Result.success(roomTypeService.deleteById(id));
    }
}
