package com.hotel.controller;

import com.hotel.common.Result;
import com.hotel.entity.Checkin;
import com.hotel.service.CheckinService;
import org.springframework.web.bind.annotation.*;
import jakarta.servlet.http.HttpServletRequest;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/checkins")
@CrossOrigin
public class CheckinController {
    private final CheckinService checkinService;

    public CheckinController(CheckinService checkinService) {
        this.checkinService = checkinService;
    }

    @GetMapping
    public Result<List<Checkin>> findAll(HttpServletRequest request) {
        String roleName = (String) request.getAttribute("roleName");
        Integer storeId = (Integer) request.getAttribute("storeId");
        if (!"管理员".equals(roleName) && storeId != null) {
            return Result.success(checkinService.findAllByStoreId(storeId));
        }
        return Result.success(checkinService.findAll());
    }

    @GetMapping("/{id}")
    public Result<Checkin> findById(@PathVariable Integer id) {
        return Result.success(checkinService.findById(id));
    }

    @GetMapping("/guest/{guestId}")
    public Result<List<Checkin>> findByGuestId(@PathVariable Integer guestId) {
        return Result.success(checkinService.findByGuestId(guestId));
    }

    @GetMapping("/status/{status}")
    public Result<List<Checkin>> findByStatus(@PathVariable String status, HttpServletRequest request) {
        String roleName = (String) request.getAttribute("roleName");
        Integer storeId = (Integer) request.getAttribute("storeId");
        if (!"管理员".equals(roleName) && storeId != null) {
            return Result.success(checkinService.findByStatusAndStoreId(status, storeId));
        }
        return Result.success(checkinService.findByStatus(status));
    }

    @GetMapping("/active")
    public Result<List<Checkin>> findActiveCheckins(HttpServletRequest request) {
        String roleName = (String) request.getAttribute("roleName");
        Integer storeId = (Integer) request.getAttribute("storeId");
        if (!"管理员".equals(roleName) && storeId != null) {
            return Result.success(checkinService.findActiveCheckinsByStoreId(storeId));
        }
        return Result.success(checkinService.findActiveCheckins());
    }

    @PostMapping
    public Result<Integer> insert(@RequestBody Checkin checkin, HttpServletRequest request) {
        String roleName = (String) request.getAttribute("roleName");
        Integer userStoreId = (Integer) request.getAttribute("storeId");
        if (!"管理员".equals(roleName) && userStoreId != null) {
            checkin.setStoreId(userStoreId);
        }
        checkin.setCheckinTime(LocalDateTime.now());
        checkin.setStatus("入住中");
        return Result.success(checkinService.insert(checkin));
    }

    @PutMapping
    public Result<Integer> update(@RequestBody Checkin checkin, HttpServletRequest request) {
        String roleName = (String) request.getAttribute("roleName");
        Integer userStoreId = (Integer) request.getAttribute("storeId");
        if (!"管理员".equals(roleName) && userStoreId != null) {
            Checkin existing = checkinService.findById(checkin.getCheckinId());
            if (existing != null && !userStoreId.equals(existing.getStoreId())) {
                return Result.error(403, "无权操作其他门店的入住记录");
            }
        }
        return Result.success(checkinService.update(checkin));
    }

    @DeleteMapping("/{id}")
    public Result<Integer> deleteById(@PathVariable Integer id, HttpServletRequest request) {
        String roleName = (String) request.getAttribute("roleName");
        Integer userStoreId = (Integer) request.getAttribute("storeId");
        if (!"管理员".equals(roleName) && userStoreId != null) {
            Checkin existing = checkinService.findById(id);
            if (existing != null && !userStoreId.equals(existing.getStoreId())) {
                return Result.error(403, "无权删除其他门店的入住记录");
            }
        }
        return Result.success(checkinService.deleteById(id));
    }

    @PutMapping("/{id}/checkout")
    public Result<Integer> checkout(@PathVariable Integer id, HttpServletRequest request) {
        String roleName = (String) request.getAttribute("roleName");
        Integer userStoreId = (Integer) request.getAttribute("storeId");
        if (!"管理员".equals(roleName) && userStoreId != null) {
            Checkin existing = checkinService.findById(id);
            if (existing != null && !userStoreId.equals(existing.getStoreId())) {
                return Result.error(403, "无权操作其他门店的入住记录");
            }
        }
        return Result.success(checkinService.checkout(id));
    }
}
