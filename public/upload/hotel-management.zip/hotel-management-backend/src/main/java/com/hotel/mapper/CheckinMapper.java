package com.hotel.mapper;

import com.hotel.entity.Checkin;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;

@Mapper
public interface CheckinMapper {
    List<Checkin> findAll();
    List<Checkin> findAllByStoreId(@Param("storeId") Integer storeId);
    Checkin findById(@Param("checkinId") Integer checkinId);
    List<Checkin> findByGuestId(@Param("guestId") Integer guestId);
    List<Checkin> findByStatus(@Param("status") String status);
    List<Checkin> findByStatusAndStoreId(@Param("status") String status, @Param("storeId") Integer storeId);
    List<Checkin> findActiveCheckins();
    List<Checkin> findActiveCheckinsByStoreId(@Param("storeId") Integer storeId);
    int insert(Checkin checkin);
    int update(Checkin checkin);
    int deleteById(@Param("checkinId") Integer checkinId);
    int checkout(@Param("checkinId") Integer checkinId);
    int countByGuestId(@Param("guestId") Integer guestId);
}
