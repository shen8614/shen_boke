package com.hotel.dto;

import lombok.Data;

@Data
public class LoginResponse {
    private Integer id;
    private String username;
    private String name;
    private String roleName;
    private Integer roleId;
    private Integer storeId;
    private String storeName;
    private String token;
}
