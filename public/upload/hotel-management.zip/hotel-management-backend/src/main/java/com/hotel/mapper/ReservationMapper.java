package com.hotel.mapper;

import com.hotel.entity.Reservation;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;

@Mapper
public interface ReservationMapper {
    List<Reservation> findAll();
    List<Reservation> findAllByStoreId(@Param("storeId") Integer storeId);
    Reservation findById(@Param("reservationId") Integer reservationId);
    List<Reservation> findByGuestId(@Param("guestId") Integer guestId);
    List<Reservation> findByStatus(@Param("status") String status);
    List<Reservation> findByStatusAndStoreId(@Param("status") String status, @Param("storeId") Integer storeId);
    int insert(Reservation reservation);
    int update(Reservation reservation);
    int deleteById(@Param("reservationId") Integer reservationId);
    int updateStatus(@Param("reservationId") Integer reservationId, @Param("status") String status);
    int countByGuestId(@Param("guestId") Integer guestId);
}
