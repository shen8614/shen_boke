package com.hotel.service;

import com.hotel.entity.Consumption;
import com.hotel.mapper.ConsumptionMapper;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

@Service
public class ConsumptionService {
    private final ConsumptionMapper consumptionMapper;

    public ConsumptionService(ConsumptionMapper consumptionMapper) {
        this.consumptionMapper = consumptionMapper;
    }

    public List<Consumption> findByCheckinId(Integer checkinId) {
        return consumptionMapper.findByCheckinId(checkinId);
    }

    public Consumption findById(Integer consumptionId) {
        return consumptionMapper.findById(consumptionId);
    }

    public int insert(Consumption consumption) {
        return consumptionMapper.insert(consumption);
    }

    public int update(Consumption consumption) {
        return consumptionMapper.update(consumption);
    }

    public int deleteById(Integer consumptionId) {
        return consumptionMapper.deleteById(consumptionId);
    }

    public BigDecimal sumByCheckinId(Integer checkinId) {
        return consumptionMapper.sumByCheckinId(checkinId);
    }
}
