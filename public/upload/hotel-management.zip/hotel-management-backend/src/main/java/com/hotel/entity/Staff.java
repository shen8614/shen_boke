package com.hotel.entity;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class Staff {
    private Integer staffId;
    private String username;
    private String password;
    private String name;
    private Integer roleId;
    private String phone;
    private Integer storeId;
    private LocalDateTime createdAt;

    private String roleName;
    private String storeName;
}
