package com.hotel.controller;

import com.hotel.common.Result;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/upload")
@CrossOrigin
public class UploadController {

    @Value("${file.upload-dir:./uploads}")
    private String uploadDir;

    @PostMapping
    public Result<Map<String, String>> upload(@RequestParam("file") MultipartFile file,
                                              @RequestParam(defaultValue = "stores") String folder) {
        if (file.isEmpty()) {
            return Result.error(400, "文件不能为空");
        }

        String originalFilename = file.getOriginalFilename();
        if (originalFilename == null) {
            return Result.error(400, "文件名无效");
        }

        String extension = "";
        int dotIndex = originalFilename.lastIndexOf('.');
        if (dotIndex > 0) {
            extension = originalFilename.substring(dotIndex).toLowerCase();
        }

        if (!extension.matches("\\.(jpg|jpeg|png|gif|bmp|webp)$")) {
            return Result.error(400, "仅支持 jpg、jpeg、png、gif、bmp、webp 格式的图片");
        }

        String filename = UUID.randomUUID() + extension;

        Path basePath = Paths.get(uploadDir).toAbsolutePath().normalize();
        Path dirPath = basePath.resolve(folder);
        try {
            Files.createDirectories(dirPath);
        } catch (IOException e) {
            return Result.error(500, "创建上传目录失败: " + e.getMessage());
        }

        Path filePath = dirPath.resolve(filename);
        try {
            file.transferTo(filePath.toFile());
        } catch (IOException e) {
            return Result.error(500, "文件保存失败: " + e.getMessage());
        }

        String url = "/uploads/" + folder + "/" + filename;
        Map<String, String> data = new HashMap<>();
        data.put("url", url);
        return Result.success(data);
    }
}
