package com.hotel.controller;

import com.hotel.common.Result;
import com.hotel.entity.ConsumptionItem;
import com.hotel.service.ConsumptionItemService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/consumption-items")
@CrossOrigin
public class ConsumptionItemController {
    private final ConsumptionItemService itemService;

    public ConsumptionItemController(ConsumptionItemService itemService) {
        this.itemService = itemService;
    }

    @GetMapping
    public Result<List<ConsumptionItem>> findAll() {
        return Result.success(itemService.findAll());
    }

    @GetMapping("/{id}")
    public Result<ConsumptionItem> findById(@PathVariable Integer id) {
        return Result.success(itemService.findById(id));
    }
}
