package com.hotel.mapper;

import com.hotel.entity.Guest;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;

@Mapper
public interface GuestMapper {
    List<Guest> findAll();
    Guest findById(@Param("guestId") Integer guestId);
    Guest findByPhone(@Param("phone") String phone);
    Guest findByIdNumber(@Param("idNumber") String idNumber);
    int insert(Guest guest);
    int update(Guest guest);
    int deleteById(@Param("guestId") Integer guestId);
}
