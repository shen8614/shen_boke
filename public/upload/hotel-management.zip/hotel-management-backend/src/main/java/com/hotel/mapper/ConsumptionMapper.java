package com.hotel.mapper;

import com.hotel.entity.Consumption;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.math.BigDecimal;
import java.util.List;

@Mapper
public interface ConsumptionMapper {
    List<Consumption> findByCheckinId(@Param("checkinId") Integer checkinId);
    Consumption findById(@Param("consumptionId") Integer consumptionId);
    int insert(Consumption consumption);
    int update(Consumption consumption);
    int deleteById(@Param("consumptionId") Integer consumptionId);
    BigDecimal sumByCheckinId(@Param("checkinId") Integer checkinId);
}
