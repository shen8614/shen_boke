package com.hotel.entity;

import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class Consumption {
    private Integer consumptionId;
    private Integer checkinId;
    private Integer itemId;
    private Integer quantity;
    private BigDecimal amount;
    private LocalDateTime consumptionTime;

    private String itemName;
}
