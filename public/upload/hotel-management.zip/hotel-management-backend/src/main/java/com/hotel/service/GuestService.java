package com.hotel.service;

import com.hotel.entity.Guest;
import com.hotel.mapper.GuestMapper;
import com.hotel.mapper.ReservationMapper;
import com.hotel.mapper.CheckinMapper;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class GuestService {
    private final GuestMapper guestMapper;
    private final ReservationMapper reservationMapper;
    private final CheckinMapper checkinMapper;

    public GuestService(GuestMapper guestMapper, ReservationMapper reservationMapper, CheckinMapper checkinMapper) {
        this.guestMapper = guestMapper;
        this.reservationMapper = reservationMapper;
        this.checkinMapper = checkinMapper;
    }

    public List<Guest> findAll() {
        return guestMapper.findAll();
    }

    public Guest findById(Integer guestId) {
        return guestMapper.findById(guestId);
    }

    public Guest findByPhone(String phone) {
        return guestMapper.findByPhone(phone);
    }

    public Guest findByIdNumber(String idNumber) {
        return guestMapper.findByIdNumber(idNumber);
    }

    public Integer insert(Guest guest) {
        guestMapper.insert(guest);
        return guest.getGuestId();
    }

    public int update(Guest guest) {
        return guestMapper.update(guest);
    }

    public String deleteById(Integer guestId) {
        if (reservationMapper.countByGuestId(guestId) > 0) {
            return "该客户有预订记录，无法删除";
        }
        if (checkinMapper.countByGuestId(guestId) > 0) {
            return "该客户有入住记录，无法删除";
        }
        guestMapper.deleteById(guestId);
        return "success";
    }
}
