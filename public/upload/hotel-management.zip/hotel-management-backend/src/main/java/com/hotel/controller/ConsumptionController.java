package com.hotel.controller;

import com.hotel.common.Result;
import com.hotel.entity.Consumption;
import com.hotel.entity.Checkin;
import com.hotel.service.ConsumptionService;
import com.hotel.service.CheckinService;
import org.springframework.web.bind.annotation.*;
import jakarta.servlet.http.HttpServletRequest;

import java.math.BigDecimal;
import java.util.List;

@RestController
@RequestMapping("/api/consumption")
@CrossOrigin
public class ConsumptionController {
    private final ConsumptionService consumptionService;
    private final CheckinService checkinService;

    public ConsumptionController(ConsumptionService consumptionService,
                                  CheckinService checkinService) {
        this.consumptionService = consumptionService;
        this.checkinService = checkinService;
    }

    @GetMapping("/checkin/{checkinId}")
    public Result<List<Consumption>> findByCheckinId(@PathVariable Integer checkinId,
                                                      HttpServletRequest request) {
        if (!checkStoreAccess(checkinId, request)) {
            return Result.error(403, "无权查看其他门店的消费记录");
        }
        return Result.success(consumptionService.findByCheckinId(checkinId));
    }

    @GetMapping("/checkin/{checkinId}/total")
    public Result<BigDecimal> sumByCheckinId(@PathVariable Integer checkinId,
                                              HttpServletRequest request) {
        if (!checkStoreAccess(checkinId, request)) {
            return Result.error(403, "无权查看其他门店的消费记录");
        }
        return Result.success(consumptionService.sumByCheckinId(checkinId));
    }

    @PostMapping
    public Result<Integer> insert(@RequestBody Consumption consumption, HttpServletRequest request) {
        if (!checkStoreAccess(consumption.getCheckinId(), request)) {
            return Result.error(403, "无权操作其他门店的消费记录");
        }
        return Result.success(consumptionService.insert(consumption));
    }

    @PutMapping
    public Result<Integer> update(@RequestBody Consumption consumption, HttpServletRequest request) {
        if (!checkStoreAccess(consumption.getCheckinId(), request)) {
            return Result.error(403, "无权操作其他门店的消费记录");
        }
        return Result.success(consumptionService.update(consumption));
    }

    @DeleteMapping("/{id}")
    public Result<Integer> deleteById(@PathVariable Integer id, HttpServletRequest request) {
        Consumption record = consumptionService.findById(id);
        if (record == null) {
            return Result.error(404, "消费记录不存在");
        }
        if (!checkStoreAccess(record.getCheckinId(), request)) {
            return Result.error(403, "无权操作其他门店的消费记录");
        }
        return Result.success(consumptionService.deleteById(id));
    }

    private boolean checkStoreAccess(Integer checkinId, HttpServletRequest request) {
        String roleName = (String) request.getAttribute("roleName");
        if ("管理员".equals(roleName)) return true;
        Integer userStoreId = (Integer) request.getAttribute("storeId");
        if (userStoreId == null) return true;
        Checkin checkin = checkinService.findById(checkinId);
        return checkin != null && userStoreId.equals(checkin.getStoreId());
    }
}
