package com.hotel.controller;

import com.hotel.common.Result;
import com.hotel.entity.Bill;
import com.hotel.service.BillService;
import org.springframework.web.bind.annotation.*;
import jakarta.servlet.http.HttpServletRequest;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/bills")
@CrossOrigin
public class BillController {
    private final BillService billService;

    public BillController(BillService billService) {
        this.billService = billService;
    }

    @GetMapping
    public Result<List<Bill>> findAll(HttpServletRequest request) {
        String roleName = (String) request.getAttribute("roleName");
        Integer storeId = (Integer) request.getAttribute("storeId");
        if (!"管理员".equals(roleName) && storeId != null) {
            List<Bill> all = billService.findAll();
            return Result.success(all.stream().filter(b -> storeId.equals(b.getStoreId())).collect(Collectors.toList()));
        }
        return Result.success(billService.findAll());
    }

    @GetMapping("/{id}")
    public Result<Bill> findById(@PathVariable Integer id) {
        return Result.success(billService.findById(id));
    }

    @GetMapping("/checkin/{checkinId}")
    public Result<Bill> findByCheckinId(@PathVariable Integer checkinId, HttpServletRequest request) {
        String roleName = (String) request.getAttribute("roleName");
        Integer userStoreId = (Integer) request.getAttribute("storeId");
        if (!"管理员".equals(roleName)) {
            return Result.success(billService.findByCheckinId(checkinId));
        }
        return Result.success(billService.findByCheckinId(checkinId));
    }

    @PostMapping
    public Result<Integer> insert(@RequestBody Bill bill, HttpServletRequest request) {
        String roleName = (String) request.getAttribute("roleName");
        Integer userStoreId = (Integer) request.getAttribute("storeId");
        if (!"管理员".equals(roleName) && userStoreId != null) {
            bill.setStoreId(userStoreId);
        }
        return Result.success(billService.insert(bill));
    }

    @PutMapping
    public Result<Integer> update(@RequestBody Bill bill, HttpServletRequest request) {
        String roleName = (String) request.getAttribute("roleName");
        Integer userStoreId = (Integer) request.getAttribute("storeId");
        if (!"管理员".equals(roleName) && userStoreId != null) {
            Bill existing = billService.findById(bill.getBillId());
            if (existing != null && !userStoreId.equals(existing.getStoreId())) {
                return Result.error(403, "无权操作其他门店的账单");
            }
        }
        return Result.success(billService.update(bill));
    }

    @DeleteMapping("/{id}")
    public Result<Integer> deleteById(@PathVariable Integer id, HttpServletRequest request) {
        String roleName = (String) request.getAttribute("roleName");
        Integer userStoreId = (Integer) request.getAttribute("storeId");
        if (!"管理员".equals(roleName) && userStoreId != null) {
            Bill existing = billService.findById(id);
            if (existing != null && !userStoreId.equals(existing.getStoreId())) {
                return Result.error(403, "无权删除其他门店的账单");
            }
        }
        return Result.success(billService.deleteById(id));
    }

    @GetMapping("/maxInvoiceNumber")
    public Result<String> findMaxInvoiceNumber() {
        return Result.success(billService.findMaxInvoiceNumber());
    }
}
