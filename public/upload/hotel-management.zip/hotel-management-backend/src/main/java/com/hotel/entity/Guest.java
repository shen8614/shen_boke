package com.hotel.entity;

import lombok.Data;
import java.time.LocalDateTime;

@Data
public class Guest {
    private Integer guestId;
    private String name;
    private String idType;
    private String idNumber;
    private String phone;
    private String password;
    private String email;
    private LocalDateTime createdAt;
}
