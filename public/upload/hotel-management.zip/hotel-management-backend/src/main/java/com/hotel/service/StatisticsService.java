package com.hotel.service;

import com.hotel.dto.*;
import com.hotel.entity.Bill;
import com.hotel.mapper.StatisticsMapper;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
public class StatisticsService {

    private static final DateTimeFormatter DT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private final StatisticsMapper statisticsMapper;
    private final BillService billService;

    public StatisticsService(StatisticsMapper statisticsMapper, BillService billService) {
        this.statisticsMapper = statisticsMapper;
        this.billService = billService;
    }

    public OccupancyOverview getOccupancyOverview(Integer storeId) {
        OccupancyOverview o = statisticsMapper.selectRoomOccupancyCounts(storeId);
        if (o == null) {
            o = new OccupancyOverview();
            o.setTotalRooms(0L);
            o.setOccupiedRooms(0L);
            o.setAvailableRooms(0L);
            o.setOpsRooms(0L);
        }
        long total = o.getTotalRooms() == null ? 0L : o.getTotalRooms();
        long occ = o.getOccupiedRooms() == null ? 0L : o.getOccupiedRooms();
        o.setOccupancyRatePercent(total > 0 ? Math.round(10000.0 * occ / total) / 100.0 : 0.0);
        return o;
    }

    public List<StoreOccupancyRow> getOccupancyByStore() {
        List<StoreOccupancyRow> rows = statisticsMapper.selectOccupancyByStore();
        for (StoreOccupancyRow r : rows) {
            long t = r.getTotalRooms() == null ? 0L : r.getTotalRooms();
            long o = r.getOccupiedRooms() == null ? 0L : r.getOccupiedRooms();
            r.setOccupancyRatePercent(t > 0 ? Math.round(10000.0 * o / t) / 100.0 : 0.0);
        }
        return rows;
    }

    public RevenueAnalysisVO getRevenueAnalysis(LocalDate startDate, LocalDate endDate, Integer storeId) {
        String start = startDate.atStartOfDay().format(DT);
        String end = endDate.atTime(23, 59, 59).format(DT);

        RevenueAnalysisVO vo = new RevenueAnalysisVO();
        vo.setSummary(statisticsMapper.selectRevenueSummary(start, end, storeId));
        vo.setTrend(statisticsMapper.selectRevenueTrend(start, end, storeId));
        vo.setPaymentMix(statisticsMapper.selectPaymentMix(start, end, storeId));

        if (vo.getSummary() == null) vo.setSummary(new RevenueSummaryDto());
        if (vo.getTrend() == null) vo.setTrend(java.util.Collections.emptyList());
        if (vo.getPaymentMix() == null) vo.setPaymentMix(java.util.Collections.emptyList());

        return vo;
    }

    public List<Bill> getReportBills(LocalDate startDate, LocalDate endDate, Integer storeId) {
        String start = startDate.atStartOfDay().format(DT);
        String end = endDate.atTime(23, 59, 59).format(DT);
        return billService.findByCheckoutTimeRange(start, end, storeId);
    }
}
