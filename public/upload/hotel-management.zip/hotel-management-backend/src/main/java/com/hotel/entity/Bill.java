package com.hotel.entity;

import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class Bill {
    private Integer billId;
    private Integer checkinId;
    private BigDecimal roomCharge;
    private BigDecimal otherCharge;
    private BigDecimal totalCharge;
    private BigDecimal deposit;
    private BigDecimal actualPay;
    private String paymentMethod;
    private String invoiceStatus;
    private String invoiceNumber;
    private LocalDateTime checkoutTime;
    private Integer staffId;
    private LocalDateTime createdAt;

    private String guestName;
    private String roomNumber;
    private String checkinTime;
    private Integer storeId;
}
