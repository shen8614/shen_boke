package com.hotel.dto;

import lombok.Data;
import java.math.BigDecimal;

@Data
public class RevenueTrendPoint {
    private String day;
    private BigDecimal amount;
    private Integer billCount;
}
