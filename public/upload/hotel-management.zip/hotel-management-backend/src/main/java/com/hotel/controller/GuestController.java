package com.hotel.controller;

import com.hotel.common.Result;
import com.hotel.entity.Guest;
import com.hotel.service.GuestService;
import org.springframework.web.bind.annotation.*;
import jakarta.servlet.http.HttpServletRequest;

import java.util.List;

@RestController
@RequestMapping("/api/guests")
@CrossOrigin
public class GuestController {
    private final GuestService guestService;

    public GuestController(GuestService guestService) {
        this.guestService = guestService;
    }

    @GetMapping
    public Result<List<Guest>> findAll(HttpServletRequest request) {
        String roleName = (String) request.getAttribute("roleName");
        Integer userId = (Integer) request.getAttribute("userId");
        if ("客人".equals(roleName) && userId != null) {
            Guest self = guestService.findById(userId);
            return Result.success(self != null ? List.of(self) : List.of());
        }
        return Result.success(guestService.findAll());
    }

    @GetMapping("/{id}")
    public Result<Guest> findById(@PathVariable Integer id, HttpServletRequest request) {
        String roleName = (String) request.getAttribute("roleName");
        Integer userId = (Integer) request.getAttribute("userId");
        if ("客人".equals(roleName) && !userId.equals(id)) {
            return Result.error(403, "仅能查看自己的信息");
        }
        return Result.success(guestService.findById(id));
    }

    @PostMapping
    public Result<Integer> insert(@RequestBody Guest guest, HttpServletRequest request) {
        String roleName = (String) request.getAttribute("roleName");
        if ("客人".equals(roleName)) {
            return Result.error(403, "客人无权创建客人记录");
        }
        return Result.success(guestService.insert(guest));
    }

    @PutMapping
    public Result<Integer> update(@RequestBody Guest guest, HttpServletRequest request) {
        String roleName = (String) request.getAttribute("roleName");
        Integer userId = (Integer) request.getAttribute("userId");
        if ("客人".equals(roleName)) {
            if (!userId.equals(guest.getGuestId())) {
                return Result.error(403, "仅能修改自己的信息");
            }
        }
        return Result.success(guestService.update(guest));
    }

    @DeleteMapping("/{id}")
    public Result<?> deleteById(@PathVariable Integer id, HttpServletRequest request) {
        String roleName = (String) request.getAttribute("roleName");
        if ("客人".equals(roleName)) {
            return Result.error(403, "客人无权删除记录");
        }
        String result = guestService.deleteById(id);
        return "success".equals(result) ? Result.success(1) : Result.error(result);
    }
}
