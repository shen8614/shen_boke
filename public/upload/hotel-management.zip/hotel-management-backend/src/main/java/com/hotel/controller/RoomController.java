package com.hotel.controller;

import com.hotel.common.Result;
import com.hotel.entity.Room;
import com.hotel.service.RoomService;
import org.springframework.web.bind.annotation.*;
import jakarta.servlet.http.HttpServletRequest;

import java.util.List;

@RestController
@RequestMapping("/api/rooms")
@CrossOrigin
public class RoomController {
    private final RoomService roomService;

    public RoomController(RoomService roomService) {
        this.roomService = roomService;
    }

    @GetMapping
    public Result<List<Room>> findAll(HttpServletRequest request) {
        String roleName = (String) request.getAttribute("roleName");
        Integer storeId = (Integer) request.getAttribute("storeId");
        if (!"管理员".equals(roleName) && storeId != null) {
            return Result.success(roomService.findByStoreId(storeId));
        }
        return Result.success(roomService.findAll());
    }

    @GetMapping("/{id}")
    public Result<Room> findById(@PathVariable Integer id) {
        return Result.success(roomService.findById(id));
    }

    @GetMapping("/store/{storeId}")
    public Result<List<Room>> findByStoreId(@PathVariable Integer storeId, HttpServletRequest request) {
        String roleName = (String) request.getAttribute("roleName");
        Integer userStoreId = (Integer) request.getAttribute("storeId");
        if (!"管理员".equals(roleName)) {
            if (userStoreId == null || !userStoreId.equals(storeId)) {
                return Result.error(403, "无权访问其他门店数据");
            }
        }
        return Result.success(roomService.findByStoreId(storeId));
    }

    @GetMapping("/status/{status}")
    public Result<List<Room>> findByStatus(@PathVariable String status, HttpServletRequest request) {
        String roleName = (String) request.getAttribute("roleName");
        Integer storeId = (Integer) request.getAttribute("storeId");
        if (!"管理员".equals(roleName) && storeId != null) {
            List<Room> allByStore = roomService.findByStoreId(storeId);
            allByStore.removeIf(r -> !r.getStatus().equals(status));
            return Result.success(allByStore);
        }
        return Result.success(roomService.findByStatus(status));
    }

    @PostMapping
    public Result<Integer> insert(@RequestBody Room room, HttpServletRequest request) {
        String roleName = (String) request.getAttribute("roleName");
        Integer userStoreId = (Integer) request.getAttribute("storeId");
        if (!"管理员".equals(roleName) && userStoreId != null) {
            room.setStoreId(userStoreId);
        }
        return Result.success(roomService.insert(room));
    }

    @PutMapping
    public Result<Integer> update(@RequestBody Room room, HttpServletRequest request) {
        String roleName = (String) request.getAttribute("roleName");
        Integer userStoreId = (Integer) request.getAttribute("storeId");
        if (!"管理员".equals(roleName) && userStoreId != null) {
            Room existing = roomService.findById(room.getRoomId());
            if (existing != null && !userStoreId.equals(existing.getStoreId())) {
                return Result.error(403, "无权操作其他门店的客房");
            }
        }
        return Result.success(roomService.update(room));
    }

    @DeleteMapping("/{id}")
    public Result<Integer> deleteById(@PathVariable Integer id, HttpServletRequest request) {
        String roleName = (String) request.getAttribute("roleName");
        Integer userStoreId = (Integer) request.getAttribute("storeId");
        if (!"管理员".equals(roleName) && userStoreId != null) {
            Room existing = roomService.findById(id);
            if (existing != null && !userStoreId.equals(existing.getStoreId())) {
                return Result.error(403, "无权删除其他门店的客房");
            }
        }
        return Result.success(roomService.deleteById(id));
    }

    @PutMapping("/{id}/status")
    public Result<Integer> updateStatus(@PathVariable Integer id, @RequestParam String status, HttpServletRequest request) {
        String roleName = (String) request.getAttribute("roleName");
        Integer userStoreId = (Integer) request.getAttribute("storeId");
        if (!"管理员".equals(roleName) && userStoreId != null) {
            Room existing = roomService.findById(id);
            if (existing != null && !userStoreId.equals(existing.getStoreId())) {
                return Result.error(403, "无权操作其他门店的客房");
            }
        }
        return Result.success(roomService.updateStatus(id, status));
    }
}
