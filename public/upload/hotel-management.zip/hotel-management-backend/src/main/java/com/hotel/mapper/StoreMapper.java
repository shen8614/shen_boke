package com.hotel.mapper;

import com.hotel.entity.Store;
import org.apache.ibatis.annotations.Mapper;
import java.util.List;

@Mapper
public interface StoreMapper {
    List<Store> findAll();
    Store findById(Integer storeId);
    int insert(Store store);
    int update(Store store);
    int deleteById(Integer storeId);
}
