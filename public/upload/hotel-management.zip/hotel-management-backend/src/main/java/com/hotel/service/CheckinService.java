package com.hotel.service;

import com.hotel.entity.Checkin;
import com.hotel.mapper.CheckinMapper;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class CheckinService {
    private final CheckinMapper checkinMapper;

    public CheckinService(CheckinMapper checkinMapper) {
        this.checkinMapper = checkinMapper;
    }

    public List<Checkin> findAll() {
        return checkinMapper.findAll();
    }

    public List<Checkin> findAllByStoreId(Integer storeId) {
        return checkinMapper.findAllByStoreId(storeId);
    }

    public Checkin findById(Integer checkinId) {
        return checkinMapper.findById(checkinId);
    }

    public List<Checkin> findByGuestId(Integer guestId) {
        return checkinMapper.findByGuestId(guestId);
    }

    public List<Checkin> findByStatus(String status) {
        return checkinMapper.findByStatus(status);
    }

    public List<Checkin> findByStatusAndStoreId(String status, Integer storeId) {
        return checkinMapper.findByStatusAndStoreId(status, storeId);
    }

    public List<Checkin> findActiveCheckins() {
        return checkinMapper.findActiveCheckins();
    }

    public List<Checkin> findActiveCheckinsByStoreId(Integer storeId) {
        return checkinMapper.findActiveCheckinsByStoreId(storeId);
    }

    public int insert(Checkin checkin) {
        return checkinMapper.insert(checkin);
    }

    public int update(Checkin checkin) {
        return checkinMapper.update(checkin);
    }

    public int deleteById(Integer checkinId) {
        return checkinMapper.deleteById(checkinId);
    }

    public int checkout(Integer checkinId) {
        return checkinMapper.checkout(checkinId);
    }
}
