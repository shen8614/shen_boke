package com.hotel.controller;

import com.hotel.common.Result;
import com.hotel.entity.Staff;
import com.hotel.service.StaffService;
import org.springframework.web.bind.annotation.*;
import jakarta.servlet.http.HttpServletRequest;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/staff")
@CrossOrigin
public class StaffController {
    private final StaffService staffService;

    public StaffController(StaffService staffService) {
        this.staffService = staffService;
    }

    @GetMapping
    public Result<List<Staff>> findAll(HttpServletRequest request) {
        String roleName = (String) request.getAttribute("roleName");
        Integer storeId = (Integer) request.getAttribute("storeId");
        if (!"管理员".equals(roleName) && storeId != null) {
            List<Staff> all = staffService.findAll();
            return Result.success(all.stream().filter(s -> storeId.equals(s.getStoreId())).collect(Collectors.toList()));
        }
        return Result.success(staffService.findAll());
    }

    @GetMapping("/{id}")
    public Result<Staff> findById(@PathVariable Integer id) {
        return Result.success(staffService.findById(id));
    }

    @PostMapping
    public Result<Integer> insert(@RequestBody Staff staff, HttpServletRequest request) {
        String roleName = (String) request.getAttribute("roleName");
        Integer userStoreId = (Integer) request.getAttribute("storeId");
        if (!"管理员".equals(roleName) && userStoreId != null) {
            staff.setStoreId(userStoreId);
        }
        return Result.success(staffService.insert(staff));
    }

    @PutMapping
    public Result<Integer> update(@RequestBody Staff staff, HttpServletRequest request) {
        String roleName = (String) request.getAttribute("roleName");
        Integer userStoreId = (Integer) request.getAttribute("storeId");
        if (!"管理员".equals(roleName) && userStoreId != null) {
            Staff existing = staffService.findById(staff.getStaffId());
            if (existing != null && !userStoreId.equals(existing.getStoreId())) {
                return Result.error(403, "无权操作其他门店的员工");
            }
        }
        return Result.success(staffService.update(staff));
    }

    @DeleteMapping("/{id}")
    public Result<Integer> deleteById(@PathVariable Integer id, HttpServletRequest request) {
        String roleName = (String) request.getAttribute("roleName");
        Integer userStoreId = (Integer) request.getAttribute("storeId");
        if (!"管理员".equals(roleName) && userStoreId != null) {
            Staff existing = staffService.findById(id);
            if (existing != null && !userStoreId.equals(existing.getStoreId())) {
                return Result.error(403, "无权删除其他门店的员工");
            }
        }
        return Result.success(staffService.deleteById(id));
    }
}
