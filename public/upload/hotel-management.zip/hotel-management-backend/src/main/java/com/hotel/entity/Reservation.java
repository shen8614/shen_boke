package com.hotel.entity;

import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class Reservation {
    private Integer reservationId;
    private Integer guestId;
    private Integer roomId;
    private Integer typeId;
    private LocalDate checkinDate;
    private LocalDate checkoutDate;
    private Integer roomCount;
    private Integer actualGuests;
    private String status;
    private BigDecimal deposit;
    private String notes;
    private LocalDateTime createdAt;

    private String guestName;
    private String roomNumber;
    private String typeName;
    private Integer storeId;
    private String storeName;
}
