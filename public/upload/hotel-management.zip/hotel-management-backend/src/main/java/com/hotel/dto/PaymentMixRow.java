package com.hotel.dto;

import lombok.Data;
import java.math.BigDecimal;

@Data
public class PaymentMixRow {
    private String paymentMethod;
    private BigDecimal amount;
    private Integer billCount;
}
