package com.hotel.dto;

import lombok.Data;

@Data
public class StoreOccupancyRow {
    private Integer storeId;
    private String storeName;
    private Long totalRooms;
    private Long occupiedRooms;
    private Double occupancyRatePercent;
}
