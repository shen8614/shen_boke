<template>
  <div class="room-status hm-card-panel">
    <el-row :gutter="20">
      <el-col :span="6" v-for="status in statusList" :key="status.name">
        <el-card class="status-card" :class="status.class">
          <div class="status-header">
            <span class="status-name">{{ status.name }}</span>
            <span class="status-count">{{ status.count }}</span>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <el-card class="room-list-card" shadow="never">
      <template #header>
        <span>本门店客房实时列表</span>
      </template>
      <el-table :data="rooms" border>
        <el-table-column prop="roomNumber" label="房间号" width="100" />
        <el-table-column prop="typeName" label="房型" width="120" />
        <el-table-column prop="floor" label="楼层" width="80" />
        <el-table-column prop="standardPrice" label="价格" width="100">
          <template #default="scope">¥{{ scope.row.standardPrice }}</template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="100">
          <template #default="scope">
            <el-tag :type="getStatusType(scope.row.status)">{{ scope.row.status }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="facilities" label="设施" />
        <el-table-column label="操作" width="180">
          <template #default="scope">
            <el-select
              v-if="scope.row.status !== '已入住'"
              v-model="scope.row.status"
              size="small"
              style="width: 120px"
              @change="handleStatusChange(scope.row)"
            >
              <el-option label="可售" value="可售" />
              <el-option label="清扫中" value="清扫中" />
              <el-option label="维修中" value="维修中" />
            </el-select>
            <span v-else>已入住</span>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script>
import { getRooms, getRoomsByStore, updateRoomStatus } from '../../api'
import { getUser } from '../../utils/authStorage'
import { ElMessage } from 'element-plus'

export default {
  name: 'RoomStatus',
  data() {
    return {
      rooms: [],
      statusList: [
        { name: '可售', count: 0, class: 'status-available' },
        { name: '已入住', count: 0, class: 'status-occupied' },
        { name: '清扫中', count: 0, class: 'status-cleaning' },
        { name: '维修中', count: 0, class: 'status-maintenance' }
      ]
    }
  },
  mounted() {
    this.loadData()
  },
  methods: {
    async loadData() {
      try {
        const storeId = getUser()?.storeId ?? null
        let res
        if (storeId) {
          res = await getRoomsByStore(storeId)
        } else {
          res = await getRooms()
        }
        if (res.code === 200) {
          this.rooms = res.data
          this.updateStatusCount()
        }
      } catch (e) {
        console.error('加载房态失败:', e)
      }
    },
    updateStatusCount() {
      this.statusList.forEach(s => {
        s.count = this.rooms.filter(r => r.status === s.name).length
      })
    },
    getStatusType(status) {
      const map = { '可售': 'success', '已入住': 'primary', '清扫中': 'info', '维修中': 'danger', '已预订': 'warning' }
      return map[status] || 'info'
    },
    async handleStatusChange(row) {
      const res = await updateRoomStatus(row.roomId, row.status)
      if (res.code === 200) {
        ElMessage.success('状态更新成功')
        this.updateStatusCount()
      }
    }
  }
}
</script>

<style scoped>
.room-list-card {
  margin-top: 20px;
}

.status-card {
  margin-bottom: 20px;
  border-radius: var(--hm-radius, 10px);
  border: 1px solid var(--hm-border, #d5dde6);
  box-shadow: var(--hm-shadow, 0 1px 3px rgba(15, 36, 51, 0.08));
}

.status-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.status-name {
  font-size: 15px;
  font-weight: 600;
  color: var(--hm-text, #1c2938);
}

.status-count {
  font-size: 26px;
  font-weight: 700;
  color: var(--hm-primary, #1a3a52);
}

.status-available {
  border-left: 4px solid #2d6a4f;
}

.status-occupied {
  border-left: 4px solid #3d5a73;
}

.status-cleaning {
  border-left: 4px solid #6b7785;
}

.status-maintenance {
  border-left: 4px solid #a94442;
}
</style>
