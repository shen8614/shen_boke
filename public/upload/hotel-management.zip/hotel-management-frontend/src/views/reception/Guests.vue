<template>
  <div class="guests-container">
    <el-card>
      <template #header>
        <span>客户管理</span>
      </template>
      <el-table :data="guests" border>
        <el-table-column prop="guestId" label="ID" width="60" />
        <el-table-column prop="name" label="姓名" width="100" />
        <el-table-column prop="phone" label="手机号" width="120" />
        <el-table-column prop="idType" label="证件类型" width="100" />
        <el-table-column prop="idNumber" label="证件号码" width="180" />
        <el-table-column prop="email" label="邮箱" width="180" />
        <el-table-column label="操作" width="150">
          <template #default="scope">
            <el-button type="primary" size="small" @click="handleEdit(scope.row)">编辑</el-button>
            <el-button type="danger" size="small" @click="handleDelete(scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <el-dialog v-model="dialogVisible" :title="dialogTitle" width="500px">
      <el-form :model="form" :rules="rules" ref="formRef" label-width="100px">
        <el-form-item label="姓名" prop="name">
          <el-input v-model="form.name" />
        </el-form-item>
        <el-form-item label="手机号" prop="phone">
          <el-input v-model="form.phone" />
        </el-form-item>
        <el-form-item label="证件类型" prop="idType">
          <el-select v-model="form.idType" style="width: 100%">
            <el-option label="身份证" value="身份证" />
            <el-option label="护照" value="护照" />
            <el-option label="军官证" value="军官证" />
            <el-option label="其他" value="其他" />
          </el-select>
        </el-form-item>
        <el-form-item label="证件号码" prop="idNumber">
          <el-input v-model="form.idNumber" />
        </el-form-item>
        <el-form-item label="邮箱" prop="email">
          <el-input v-model="form.email" />
        </el-form-item>
        <el-form-item label="密码" prop="password">
          <el-input v-model="form.password" type="password" show-password />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="handleSubmit">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script>
import { getGuests, addGuest, updateGuest, deleteGuest } from '../../api'
import { ElMessage, ElMessageBox } from 'element-plus'

export default {
  name: 'Guests',
  data() {
    return {
      guests: [],
      dialogVisible: false,
      dialogTitle: '新增客户',
      form: {
        guestId: null,
        name: '',
        phone: '',
        idType: '身份证',
        idNumber: '',
        email: '',
        password: '123456'
      },
      rules: {
        name: [{ required: true, message: '请输入姓名', trigger: 'blur' }],
        phone: [{ required: true, message: '请输入手机号', trigger: 'blur' }],
        idType: [{ required: true, message: '请选择证件类型', trigger: 'change' }]
      }
    }
  },
  mounted() {
    this.loadData()
  },
  methods: {
    async loadData() {
      const res = await getGuests()
      if (res.code === 200) this.guests = res.data
    },
    handleEdit(row) {
      this.dialogTitle = '编辑客户'
      this.form = { ...row, password: '' }
      this.dialogVisible = true
    },
    handleDelete(row) {
      ElMessageBox.confirm('确定删除该客户吗？', '提示', {
        type: 'warning'
      }).then(async () => {
        const res = await deleteGuest(row.guestId)
        console.log('删除结果:', res)
        if (res.code === 200) {
          ElMessage.success('删除成功')
          this.loadData()
        } else {
          ElMessage.error(res.message || '删除失败')
        }
      }).catch(() => {})
    },
    handleSubmit() {
      this.$refs.formRef.validate(async (valid) => {
        if (valid) {
          let res
          if (this.form.guestId) {
            const updateData = { ...this.form }
            if (!updateData.password || updateData.password === '') {
              delete updateData.password
            }
            res = await updateGuest(updateData)
          } else {
            res = await addGuest(this.form)
          }
          if (res.code === 200) {
            ElMessage.success(this.form.guestId ? '修改成功' : '添加成功')
            this.dialogVisible = false
            this.loadData()
          }
        }
      })
    }
  }
}
</script>
