<template>
  <div class="checkout-container">
    <el-card>
      <template #header>
        <span>退房结算</span>
      </template>
      <el-table :data="activeCheckins" border>
        <el-table-column prop="guestName" label="客人姓名" width="100" />
        <el-table-column prop="phone" label="手机号" width="120" />
        <el-table-column prop="storeName" label="酒店" width="150" />
        <el-table-column prop="roomNumber" label="房间号" width="100" />
        <el-table-column prop="typeName" label="房型" width="120" />
        <el-table-column prop="checkinTime" label="入住时间" width="180">
          <template #default="scope">
            {{ formatTime(scope.row.checkinTime) }}
          </template>
        </el-table-column>
        <el-table-column label="操作" width="120">
          <template #default="scope">
            <el-button type="primary" size="small" @click="handleCheckout(scope.row)">结算退房</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <el-dialog v-model="dialogVisible" title="退房结算" width="500px">
      <el-descriptions :column="2" border v-if="currentCheckin">
        <el-descriptions-item label="客人">{{ currentCheckin.guestName }}</el-descriptions-item>
        <el-descriptions-item label="手机号">{{ currentCheckin.phone }}</el-descriptions-item>
        <el-descriptions-item label="酒店">{{ currentCheckin.storeName }}</el-descriptions-item>
        <el-descriptions-item label="房型">{{ currentCheckin.typeName }}</el-descriptions-item>
        <el-descriptions-item label="房间号">{{ currentCheckin.roomNumber }}</el-descriptions-item>
        <el-descriptions-item label="入住时间">{{ formatTime(currentCheckin.checkinTime) }}</el-descriptions-item>
      </el-descriptions>
      <el-form :model="billForm" label-width="100px" style="margin-top: 20px;">
        <el-form-item label="房费">
          <el-input-number v-model="billForm.roomCharge" :min="0" :precision="2" />
        </el-form-item>
        <el-form-item label="其他费用">
          <el-input-number v-model="billForm.otherCharge" :min="0" :precision="2" />
        </el-form-item>
        <el-form-item label="押金">
          <el-input-number v-model="billForm.deposit" :min="0" :precision="2" />
        </el-form-item>
        <el-form-item label="支付方式">
          <el-select v-model="billForm.paymentMethod">
            <el-option label="现金" value="现金" />
            <el-option label="刷卡" value="刷卡" />
            <el-option label="微信" value="微信" />
            <el-option label="支付宝" value="支付宝" />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="handleSubmit">确认结算</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script>
import { getActiveCheckins, getCheckin, checkout, updateRoomStatus, addBill, getConsumptionTotal } from '../../api'
import { getUser } from '../../utils/authStorage'
import { ElMessage } from 'element-plus'

export default {
  name: 'Checkout',
  data() {
    return {
      activeCheckins: [],
      dialogVisible: false,
      currentCheckin: null,
      billForm: { roomCharge: 0, otherCharge: 0, deposit: 0, paymentMethod: '微信' }
    }
  },
  mounted() {
    this.loadData()
  },
  methods: {
    formatTime(time) {
      if (!time) return ''
      const date = new Date(time)
      return date.toLocaleString('zh-CN')
    },
    async loadData() {
      try {
        const res = await getActiveCheckins()
        if (res.code === 200) {
          const storeId = getUser()?.storeId ?? null
          if (storeId) {
            this.activeCheckins = res.data.filter(c => c.storeId === storeId)
          } else {
            this.activeCheckins = res.data
          }
        }
      } catch (e) {
        console.error('加载退房数据失败:', e)
      }
    },
    async handleCheckout(row) {
      this.currentCheckin = row
      let otherCharge = 0
      try {
        const res = await getConsumptionTotal(row.checkinId)
        if (res.code === 200 && res.data) otherCharge = res.data
      } catch (e) {
        console.error('获取消费合计失败:', e)
      }
      this.billForm = { roomCharge: 0, otherCharge, deposit: 0, paymentMethod: '微信' }
      this.dialogVisible = true
    },
    async handleSubmit() {
      const user = getUser()
      if (!user?.id) {
        ElMessage.error('登录已失效，请重新登录')
        return
      }
      const total = this.billForm.roomCharge + this.billForm.otherCharge
      const actualPay = total - this.billForm.deposit

      await checkout(this.currentCheckin.checkinId)
      
      const checkinRes = await getCheckin(this.currentCheckin.checkinId)
      const checkoutTime = checkinRes.data.checkoutTime

      const billRes = await addBill({
        checkinId: this.currentCheckin.checkinId,
        roomCharge: this.billForm.roomCharge,
        otherCharge: this.billForm.otherCharge,
        totalCharge: total,
        deposit: this.billForm.deposit,
        actualPay: actualPay,
        paymentMethod: this.billForm.paymentMethod,
        invoiceStatus: '未开具',
        checkoutTime: checkoutTime,
        staffId: user.id
      })

      if (billRes.code === 200) {
        await updateRoomStatus(this.currentCheckin.roomId, '可售')
        ElMessage.success('结算成功')
        this.dialogVisible = false
        this.loadData()
      }
    }
  }
}
</script>

<style scoped>
:deep(.el-select) { width: 100%; }
</style>
