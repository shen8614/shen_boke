<template>
  <div class="consumption-container">
    <el-card>
      <template #header>
        <span>消费管理 — 选择在住客人添加消费项目</span>
      </template>
      <el-table :data="activeCheckins" border highlight-current-row @current-change="handleSelectCheckin" v-loading="checkinLoading">
        <el-table-column prop="guestName" label="客人姓名" width="100" />
        <el-table-column prop="roomNumber" label="房间号" width="100" />
        <el-table-column prop="typeName" label="房型" width="120" />
        <el-table-column prop="storeName" label="酒店" width="150" />
        <el-table-column prop="checkinTime" label="入住时间" width="170">
          <template #default="scope">
            {{ formatTime(scope.row.checkinTime) }}
          </template>
        </el-table-column>
        <el-table-column label="累计消费" width="120">
          <template #default="scope">
            <span style="color: #e6a23c; font-weight: bold">
              ¥{{ consumptionTotals[scope.row.checkinId] || 0 }}
            </span>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <el-card v-if="selectedCheckin" style="margin-top: 20px;">
      <template #header>
        <span>{{ selectedCheckin.guestName }} · {{ selectedCheckin.roomNumber }} — 消费明细</span>
      </template>

      <div class="add-row">
        <el-select v-model="selectedItemId" placeholder="选择消费项目" style="width: 200px" @change="selectedQuantity = 1">
          <el-option v-for="item in items" :key="item.itemId" :label="`${item.itemName} (¥${item.price})`" :value="item.itemId" />
        </el-select>
        <span style="margin: 0 10px;">数量</span>
        <el-input-number v-model="selectedQuantity" :min="1" :max="99" style="width: 100px" />
        <el-button type="primary" style="margin-left: 16px" @click="handleAddItem" :disabled="!selectedItemId" :loading="adding">
          添加消费
        </el-button>
      </div>

      <el-table :data="records" border style="margin-top: 16px;" v-loading="recordsLoading">
        <el-table-column prop="itemName" label="消费项目" width="150" />
        <el-table-column label="单价" width="100">
          <template #default="scope">
            ¥{{ getItemPrice(scope.row.itemId) }}
          </template>
        </el-table-column>
        <el-table-column label="数量" width="130">
          <template #default="scope">
            <el-input-number
              v-model="scope.row.quantity"
              :min="1"
              :max="99"
              size="small"
              @change="handleUpdateQty(scope.row)"
            />
          </template>
        </el-table-column>
        <el-table-column label="金额" width="100">
          <template #default="scope">¥{{ scope.row.amount }}</template>
        </el-table-column>
        <el-table-column prop="consumptionTime" label="时间" width="170">
          <template #default="scope">
            {{ formatTime(scope.row.consumptionTime) }}
          </template>
        </el-table-column>
        <el-table-column label="操作" width="80">
          <template #default="scope">
            <el-button size="small" type="danger" @click="handleDelete(scope.row.consumptionId)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>

      <div style="text-align: right; margin-top: 16px; font-size: 18px;">
        消费合计：<span style="color: #e6a23c; font-weight: bold;">¥{{ currentTotal }}</span>
      </div>
    </el-card>
  </div>
</template>

<script>
import {
  getActiveCheckins, getConsumptionItems, getConsumptionByCheckin, getConsumptionTotal,
  addConsumption, updateConsumption, deleteConsumption
} from '../../api'
import { getUser } from '../../utils/authStorage'
import { ElMessage, ElMessageBox } from 'element-plus'

export default {
  name: 'Consumption',
  data() {
    return {
      activeCheckins: [],
      items: [],
      selectedCheckin: null,
      records: [],
      selectedItemId: null,
      selectedQuantity: 1,
      consumptionTotals: {},
      checkinLoading: false,
      recordsLoading: false,
      adding: false
    }
  },
  computed: {
    currentTotal() {
      return this.records.reduce((sum, r) => sum + (parseFloat(r.amount) || 0), 0).toFixed(2)
    }
  },
  mounted() {
    this.loadData()
  },
  methods: {
    formatTime(time) {
      if (!time) return ''
      return new Date(time).toLocaleString('zh-CN')
    },
    getItemPrice(itemId) {
      const item = this.items.find(i => i.itemId === itemId)
      return item ? item.price : 0
    },
    async loadData() {
      this.checkinLoading = true
      try {
        const storeId = getUser()?.storeId ?? null
        const [checkinsRes, itemsRes] = await Promise.all([
          getActiveCheckins(),
          getConsumptionItems()
        ])
        if (checkinsRes.code === 200) {
          this.activeCheckins = storeId
            ? checkinsRes.data.filter(c => c.storeId === storeId)
            : checkinsRes.data
          const totals = {}
          await Promise.all(this.activeCheckins.map(async (c) => {
            try {
              const res = await getConsumptionTotal(c.checkinId)
              if (res.code === 200) totals[c.checkinId] = res.data
            } catch (e) { /* ignore individual failures */ }
          }))
          this.consumptionTotals = totals
        }
        if (itemsRes.code === 200) this.items = itemsRes.data
      } catch (e) {
        ElMessage.error('加载数据失败')
      } finally {
        this.checkinLoading = false
      }
    },
    async refreshRecords() {
      if (!this.selectedCheckin) return
      this.recordsLoading = true
      try {
        const [recordsRes, totalRes] = await Promise.all([
          getConsumptionByCheckin(this.selectedCheckin.checkinId),
          getConsumptionTotal(this.selectedCheckin.checkinId)
        ])
        if (recordsRes.code === 200) this.records = recordsRes.data
        if (totalRes.code === 200) {
          this.consumptionTotals[this.selectedCheckin.checkinId] = totalRes.data
        }
      } catch (e) {
        ElMessage.error('刷新消费数据失败')
      } finally {
        this.recordsLoading = false
      }
    },
    async handleSelectCheckin(row) {
      if (!row) return
      this.selectedCheckin = row
      this.selectedItemId = null
      await this.refreshRecords()
    },
    async handleAddItem() {
      if (!this.selectedItemId) return
      const item = this.items.find(i => i.itemId === this.selectedItemId)
      if (!item) return
      const amount = item.price * this.selectedQuantity
      this.adding = true
      try {
        const res = await addConsumption({
          checkinId: this.selectedCheckin.checkinId,
          itemId: this.selectedItemId,
          quantity: this.selectedQuantity,
          amount: amount
        })
        if (res.code === 200) {
          ElMessage.success('添加成功')
          this.selectedItemId = null
          this.selectedQuantity = 1
          await this.refreshRecords()
        } else {
          ElMessage.error(res.message || '添加失败')
        }
      } catch (e) {
        ElMessage.error('添加失败，请检查网络')
      } finally {
        this.adding = false
      }
    },
    async handleUpdateQty(row) {
      const item = this.items.find(i => i.itemId === row.itemId)
      if (!item) return
      const amount = item.price * row.quantity
      try {
        const res = await updateConsumption({
          consumptionId: row.consumptionId,
          checkinId: row.checkinId,
          itemId: row.itemId,
          quantity: row.quantity,
          amount: amount
        })
        if (res.code === 200) {
          row.amount = amount
          const totalRes = await getConsumptionTotal(row.checkinId)
          if (totalRes.code === 200) {
            this.consumptionTotals[row.checkinId] = totalRes.data
          }
        }
      } catch (e) {
        ElMessage.error('更新失败')
      }
    },
    async handleDelete(consumptionId) {
      await ElMessageBox.confirm('确定删除该消费记录吗？', '提示', { type: 'warning' })
      try {
        const res = await deleteConsumption(consumptionId)
        if (res.code === 200) {
          ElMessage.success('删除成功')
          await this.refreshRecords()
        } else {
          ElMessage.error(res.message || '删除失败')
        }
      } catch (e) {
        ElMessage.error('删除失败，请检查网络')
      }
    }
  }
}
</script>

<style scoped>
.consumption-container {
  padding: 0;
}
.add-row {
  display: flex;
  align-items: center;
  padding: 12px;
  background: #f5f7fa;
  border-radius: 6px;
}
</style>
