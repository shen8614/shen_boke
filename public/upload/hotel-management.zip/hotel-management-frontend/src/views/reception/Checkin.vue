<template>
  <div class="checkin-container">
    <el-row :gutter="20">
      <el-col :span="16">
        <el-card>
          <template #header>
            <span>{{ reservationInfo ? '预订客人入住' : '直接入住登记' }}</span>
          </template>
          <el-alert v-if="reservationInfo" :title="`预订信息：${reservationInfo.typeName} | 房间数：${reservationInfo.roomCount}间 | ${reservationInfo.checkinDate} 至 ${reservationInfo.checkoutDate}`" type="info" :closable="false" style="margin-bottom: 20px;" />
          <el-form :model="form" :rules="rules" ref="formRef" label-width="100px">
            <el-row :gutter="20">
              <el-col :span="12">
                <el-form-item label="客人手机" prop="phone">
                  <el-input v-model="form.phone" @blur="handlePhoneBlur" placeholder="输入手机号自动查找客人" />
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item label="客人姓名" prop="guestName">
                  <el-input v-model="form.guestName" placeholder="请输入姓名" />
                </el-form-item>
              </el-col>
            </el-row>
            <el-row :gutter="20">
              <el-col :span="12">
                <el-form-item label="证件类型" prop="idType">
                  <el-select v-model="form.idType" style="width: 100%;">
                    <el-option label="身份证" value="身份证" />
                    <el-option label="护照" value="护照" />
                    <el-option label="军官证" value="军官证" />
                    <el-option label="其他" value="其他" />
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item label="证件号码" prop="idNumber">
                  <el-input v-model="form.idNumber" placeholder="请输入证件号码" />
                </el-form-item>
              </el-col>
            </el-row>
            <el-row :gutter="20">
              <el-col :span="24">
                <el-form-item label="选择房间" prop="roomIds">
                  <el-select v-model="form.roomIds" multiple placeholder="请选择房间" style="width: 100%;" @change="handleRoomChange">
                    <el-option-group v-for="group in roomOptions" :key="group.label" :label="group.label">
                      <el-option v-for="r in group.options" :key="r.roomId" :label="`${r.roomNumber} - ${r.typeName}`" :value="r.roomId" :disabled="!isRoomAvailable(r)" />
                    </el-option-group>
                  </el-select>
                  <div style="margin-top: 5px; color: #909399; font-size: 12px;">已选择 {{ form.roomIds ? form.roomIds.length : 0 }} 间</div>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row :gutter="20">
              <el-col :span="12">
                <el-form-item label="入住人数" prop="actualGuests">
                  <el-input-number v-model="form.actualGuests" :min="1" :max="10" style="width: 100%;" />
                </el-form-item>
              </el-col>
            </el-row>
            <el-form-item>
              <el-button type="primary" @click="handleSubmit" :loading="loading">立即办理入住</el-button>
              <el-button @click="resetForm">重置表单</el-button>
            </el-form-item>
          </el-form>
        </el-card>
      </el-col>
      <el-col :span="8">
        <el-card>
          <template #header>
            <span>已入住列表</span>
          </template>
          <el-table :data="checkinList" max-height="400">
            <el-table-column prop="guestName" label="客人" />
            <el-table-column prop="roomNumber" label="房间号" />
            <el-table-column label="入住时间" width="150">
              <template #default="scope">
                {{ formatTime(scope.row.checkinTime) }}
              </template>
            </el-table-column>
          </el-table>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import { getRooms, getRoomsByStore, getGuests, addGuest, addCheckin, updateRoomStatus, getActiveCheckins, getReservation, updateReservationStatus } from '../../api'
import { getUser } from '../../utils/authStorage'
import { ElMessage } from 'element-plus'

export default {
  name: 'Checkin',
  data() {
    return {
      allRooms: [],
      checkinList: [],
      loading: false,
      reservationInfo: null,
      form: { phone: '', guestName: '', idType: '身份证', idNumber: '', roomIds: [], actualGuests: 1 },
      rules: {
        phone: [{ required: true, message: '请输入手机号', trigger: 'blur' }],
        guestName: [{ required: true, message: '请输入姓名', trigger: 'blur' }],
        idType: [{ required: true, message: '请选择证件类型', trigger: 'change' }],
        idNumber: [{ required: false, message: '请输入证件号码', trigger: 'blur' }],
        roomIds: [{ required: true, message: '请选择房间', trigger: 'change' }]
      }
    }
  },
  computed: {
    roomOptions() {
      const stores = {}
      this.allRooms.forEach(room => {
        const storeName = room.storeId === 1 ? '阳光大酒店' : '海景度假酒店'
        if (!stores[storeName]) {
          stores[storeName] = []
        }
        stores[storeName].push(room)
      })
      return Object.keys(stores).map(storeName => ({
        label: storeName,
        options: stores[storeName]
      }))
    }
  },
  mounted() {
    this.loadRooms()
    this.loadCheckinList()
    if (this.$route.query.reservationId) {
      this.loadReservation()
    }
  },
  methods: {
    isRoomAvailable(room) {
      if (this.reservationInfo && this.form.roomIds && this.form.roomIds.includes(room.roomId)) {
        return true
      }
      return room.status === '可售'
    },
    handleRoomChange() {
      if (this.reservationInfo && this.form.roomIds && this.form.roomIds.length > 0) {
        const selectedRoom = this.allRooms.find(r => this.form.roomIds.includes(r.roomId))
        if (selectedRoom) {
          const selectedStoreId = selectedRoom.storeId
          this.form.roomIds = this.form.roomIds.filter(rid => {
            const r = this.allRooms.find(ar => ar.roomId === rid)
            return r && r.storeId === selectedStoreId
          })
        }
      }
    },
    async loadRooms() {
      try {
        const storeId = getUser()?.storeId ?? null
        let res
        if (storeId) {
          res = await getRoomsByStore(storeId)
        } else {
          res = await getRooms()
        }
        if (res.code === 200) this.allRooms = res.data
      } catch (e) {
        console.error('加载房间失败:', e)
      }
    },
    async loadCheckinList() {
      try {
        const res = await getActiveCheckins()
        if (res.code === 200) {
          const storeId = getUser()?.storeId ?? null
          if (storeId) {
            this.checkinList = res.data.filter(c => c.storeId === storeId)
          } else {
            this.checkinList = res.data
          }
        }
      } catch (e) {
        console.error('加载入住列表失败:', e)
      }
    },
    async loadReservation() {
      const res = await getReservation(this.$route.query.reservationId)
      if (res.code === 200 && res.data) {
        this.reservationInfo = res.data
        this.form.guestName = res.data.guestName || ''
        this.form.actualGuests = res.data.actualGuests || 1
        if (res.data.roomId) {
          this.form.roomIds = [res.data.roomId]
        }
        const guestsRes = await getGuests()
        if (guestsRes.code === 200) {
          const guest = guestsRes.data.find(g => g.guestId === res.data.guestId)
          if (guest) {
            this.form.phone = guest.phone || ''
            this.form.idType = guest.idType || '身份证'
            this.form.idNumber = guest.idNumber || ''
          }
        }
      }
    },
    formatTime(time) {
      if (!time) return ''
      return time.substring(0, 16)
    },
    async handlePhoneBlur() {
      if (this.form.phone && this.form.phone.length === 11) {
        const guestsRes = await getGuests()
        if (guestsRes.code === 200) {
          const guest = guestsRes.data.find(g => g.phone === this.form.phone)
          if (guest) {
            this.form.guestName = guest.name
            this.form.idType = guest.idType || '身份证'
            this.form.idNumber = guest.idNumber || ''
            ElMessage.success('已找到客人信息')
          }
        }
      }
    },
    resetForm() {
      this.$refs.formRef.resetFields()
      this.form = { phone: '', guestName: '', idType: '身份证', idNumber: '', roomIds: [], actualGuests: 1 }
      this.reservationInfo = null
    },
    async handleSubmit() {
      this.$refs.formRef.validate(async (valid) => {
        if (valid) {
          this.loading = true
          try {
            let guestId = null
            const guestsRes = await getGuests()
            if (guestsRes.code === 200) {
              let guest = guestsRes.data.find(g => g.phone === this.form.phone)
              if (!guest) {
                const newGuest = { 
                  name: this.form.guestName, 
                  phone: this.form.phone, 
                  idType: this.form.idType, 
                  idNumber: this.form.idNumber,
                  password: '123456'
                }
                const insertRes = await addGuest(newGuest)
                if (insertRes.code === 200) {
                  guestId = insertRes.data
                } else {
                  ElMessage.error(insertRes.message || '创建客人失败')
                  this.loading = false
                  return
                }
              } else {
                guestId = guest.guestId
              }
            }

            const user = getUser()
            if (!user?.id) {
              ElMessage.error('登录已失效，请重新登录')
              this.loading = false
              return
            }

            for (const roomId of this.form.roomIds) {
              const checkinRes = await addCheckin({ 
                guestId, 
                roomId: roomId,
                reservationId: this.reservationInfo?.reservationId || null,
                staffId: user.id 
              })
              
              if (checkinRes.code === 200) {
                await updateRoomStatus(roomId, '已入住')
              }
            }
            
            if (this.reservationInfo) {
              await updateReservationStatus(this.reservationInfo.reservationId, '已入住')
            }
            
            ElMessage.success('入住办理成功')
            this.resetForm()
            this.loadRooms()
            this.loadCheckinList()
            
            if (this.$route.query.reservationId) {
              this.$router.push('/reception/checkin')
            }
          } catch (error) {
            ElMessage.error('操作失败，请重试')
          } finally {
            this.loading = false
          }
        }
      })
    }
  }
}
</script>

<style scoped>
.checkin-container {
  padding: 20px;
}
</style>
