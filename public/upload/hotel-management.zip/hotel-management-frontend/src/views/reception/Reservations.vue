<template>
  <div class="reservations-container">
    <el-card>
      <template #header>
        <div class="card-header">
          <span>预订管理</span>
          <el-button type="primary" @click="handleAdd">新增预订</el-button>
        </div>
      </template>
      <el-table :data="reservations" border :cell-style="cellStyle">
        <el-table-column prop="reservationId" label="ID" width="60" align="center" />
        <el-table-column prop="guestName" label="客人姓名" width="90" />
        <el-table-column prop="typeName" label="房型" width="80" />
        <el-table-column label="房间号" width="80" align="center">
          <template #default="scope">
            {{ scope.row.roomNumber || '-' }}
          </template>
        </el-table-column>
        <el-table-column prop="checkinDate" label="入住日期" width="100" align="center" />
        <el-table-column prop="checkoutDate" label="离店日期" width="100" align="center" />
        <el-table-column prop="roomCount" label="房间数" width="60" align="center" />
        <el-table-column prop="status" label="状态" width="80" align="center">
          <template #default="scope">
            <el-tag :type="getStatusType(scope.row.status)">{{ scope.row.status }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="deposit" label="押金" width="70" align="center">
          <template #default="scope">¥{{ scope.row.deposit }}</template>
        </el-table-column>
        <el-table-column prop="notes" label="备注" min-width="120" />
        <el-table-column label="操作" width="180" align="center" fixed="right">
          <template #default="scope">
            <el-button v-if="scope.row.status === '待确认'" size="small" type="success" @click="openConfirmDialog(scope.row)">确认</el-button>
            <el-button v-if="scope.row.status === '已确认'" size="small" type="warning" @click="handleCheckin(scope.row)">入住</el-button>
            <el-button v-if="scope.row.status === '待确认'" size="small" type="danger" @click="handleCancel(scope.row.reservationId)">取消</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <el-dialog v-model="dialogVisible" title="新增预订" width="480px">
      <el-form :model="form" :rules="rules" ref="formRef" label-width="90px">
        <el-form-item label="客人手机" prop="phone">
          <el-input v-model="form.phone" @blur="handlePhoneBlur" />
        </el-form-item>
        <el-form-item label="客人姓名" prop="guestName">
          <el-input v-model="form.guestName" />
        </el-form-item>
        <el-form-item label="房型" prop="typeId">
          <el-select v-model="form.typeId" style="width: 100%;">
            <el-option v-for="t in roomTypes" :key="t.typeId" :label="t.typeName" :value="t.typeId" />
          </el-select>
        </el-form-item>
        <el-row :gutter="15">
          <el-col :span="12">
            <el-form-item label="入住日期" prop="checkinDate">
              <el-date-picker v-model="form.checkinDate" type="date" value-format="YYYY-MM-DD" style="width: 100%;" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="离店日期" prop="checkoutDate">
              <el-date-picker v-model="form.checkoutDate" type="date" value-format="YYYY-MM-DD" style="width: 100%;" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="15">
          <el-col :span="12">
            <el-form-item label="房间数" prop="roomCount">
              <el-input-number v-model="form.roomCount" :min="1" style="width: 100%;" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="入住人数" prop="actualGuests">
              <el-input-number v-model="form.actualGuests" :min="1" style="width: 100%;" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-form-item label="押金" prop="deposit">
          <el-input-number v-model="form.deposit" :min="0" :precision="2" style="width: 100%;" />
        </el-form-item>
        <el-form-item label="备注" prop="notes">
          <el-input v-model="form.notes" type="textarea" rows="2" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="handleSubmit">确定</el-button>
      </template>
    </el-dialog>

    <el-dialog v-model="confirmDialogVisible" title="确认预订 - 选择房间" width="550px">
      <el-alert :title="`预订信息：${confirmForm.guestName} | ${confirmForm.typeName} | 房间数：${confirmForm.roomCount}间`" type="info" :closable="false" style="margin-bottom: 15px;" />
      <el-form-item label="选择房间">
        <el-select v-model="confirmForm.roomIds" multiple placeholder="请选择房间" style="width: 100%;" :max="confirmForm.roomCount" @change="handleRoomChange">
          <el-option-group v-for="group in roomOptions2" :key="group.label" :label="group.label">
            <el-option v-for="r in group.options" :key="r.roomId" :label="`${r.roomNumber} - ${r.typeName}`" :value="r.roomId" :disabled="!isRoomSelectable(r)" />
          </el-option-group>
        </el-select>
        <div style="margin-top: 5px; color: #909399; font-size: 12px;">已选择 {{ confirmForm.roomIds ? confirmForm.roomIds.length : 0 }} / {{ confirmForm.roomCount }} 间</div>
      </el-form-item>
      <el-form-item label="押金">
        <el-input-number v-model="confirmForm.deposit" :min="0" :precision="2" style="width: 100%;" />
      </el-form-item>
      <template #footer>
        <el-button @click="confirmDialogVisible = false">取消</el-button>
        <el-button @click="clearSelectedRooms">清空选择</el-button>
        <el-button type="primary" @click="handleConfirmSubmit">确认预订</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script>
import { getReservations, addReservation, updateReservation, updateRoomStatus, getRoomTypes, getRooms, getRoomsByStore, getGuests, addGuest } from '../../api'
import { getUser } from '../../utils/authStorage'
import { ElMessage, ElMessageBox } from 'element-plus'

export default {
  name: 'Reservations',
  data() {
    const validateDate = (rule, value, callback) => {
      if (this.form.checkinDate && this.form.checkoutDate) {
        if (this.form.checkinDate >= this.form.checkoutDate) {
          callback(new Error('入住日期必须早于退房日期'))
        } else {
          callback()
        }
      } else {
        callback()
      }
    }
    return {
      reservations: [],
      roomTypes: [],
      allRooms: [],
      dialogVisible: false,
      confirmDialogVisible: false,
      confirmForm: { reservationId: null, guestName: '', typeName: '', roomId: null, roomIds: [], roomCount: 1, deposit: 0 },
      form: { phone: '', guestName: '', typeId: null, roomId: null, checkinDate: '', checkoutDate: '', roomCount: 1, actualGuests: 1, deposit: 0, notes: '' },
      rules: {
        phone: [{ required: true, message: '请输入手机号', trigger: 'blur' }],
        guestName: [{ required: true, message: '请输入客人姓名', trigger: 'blur' }],
        typeId: [{ required: true, message: '请选择房型', trigger: 'change' }],
        checkinDate: [{ required: true, message: '请选择入住日期', trigger: 'change' }, { validator: validateDate, trigger: 'change' }],
        checkoutDate: [{ required: true, message: '请选择离店日期', trigger: 'change' }, { validator: validateDate, trigger: 'change' }]
      }
    }
  },
  computed: {
    roomOptions() {
      const stores = {}
      this.allRooms.forEach(room => {
        const storeName = room.storeId === 1 ? '阳光大酒店' : '海景度假酒店'
        if (!stores[storeName]) {
          stores[storeName] = []
        }
        stores[storeName].push(room)
      })
      return Object.keys(stores).map(storeName => ({
        label: storeName,
        options: stores[storeName]
      }))
    },
    roomOptions2() {
      const typeRooms = this.allRooms.filter(r => r.typeId === this.confirmForm.typeId)
      const stores = {}
      typeRooms.forEach(room => {
        const storeName = room.storeId === 1 ? '阳光大酒店' : '海景度假酒店'
        if (!stores[storeName]) {
          stores[storeName] = []
        }
        stores[storeName].push(room)
      })
      return Object.keys(stores).map(storeName => ({
        label: storeName,
        options: stores[storeName]
      }))
    }
  },
  mounted() { this.loadData() },
  methods: {
    isRoomSelectable(room) {
      if (room.status !== '可售') return false
      if (this.confirmForm.roomIds && this.confirmForm.roomIds.includes(room.roomId)) return true
      if (this.confirmForm.roomIds && this.confirmForm.roomIds.length > 0) {
        const selectedRoom = this.allRooms.find(r => this.confirmForm.roomIds.includes(r.roomId))
        if (selectedRoom && selectedRoom.storeId !== room.storeId) return false
      }
      return true
    },
    handleRoomChange() {
      if (this.confirmForm.roomIds && this.confirmForm.roomIds.length > 0) {
        const selectedRoom = this.allRooms.find(r => this.confirmForm.roomIds.includes(r.roomId))
        if (selectedRoom) {
          const selectedStoreId = selectedRoom.storeId
          this.confirmForm.roomIds = this.confirmForm.roomIds.filter(rid => {
            const r = this.allRooms.find(ar => ar.roomId === rid)
            return r && r.storeId === selectedStoreId
          })
        }
      }
    },
    clearSelectedRooms() {
      this.confirmForm.roomIds = []
    },
    cellStyle({ columnIndex }) {
      if ([0, 3, 4, 5, 6, 7, 8].includes(columnIndex)) {
        return { textAlign: 'center' }
      }
      return {}
    },
    async loadData() {
      try {
        const storeId = getUser()?.storeId ?? null
        
        const [resRes, typesRes] = await Promise.all([getReservations(), getRoomTypes()])
        
        let allReservations = []
        if (resRes.code === 200) {
          allReservations = resRes.data
        }
        
        if (typesRes.code === 200) {
          if (storeId) {
            this.roomTypes = typesRes.data.filter(t => t.storeId === storeId)
          } else {
            this.roomTypes = typesRes.data
          }
        }
        
        if (storeId) {
          this.reservations = allReservations.filter(res => res.storeId === storeId)
        } else {
          this.reservations = allReservations
        }
        
        let roomsRes
        if (storeId) {
          roomsRes = await getRoomsByStore(storeId)
        } else {
          roomsRes = await getRooms()
        }
        if (roomsRes.code === 200) {
          this.allRooms = roomsRes.data
        }
      } catch (e) {
        console.error('加载预订数据失败:', e)
      }
    },
    getStatusType(status) {
      const map = { '待确认': 'info', '已确认': 'success', '已入住': 'warning', '已取消': 'danger', '已完成': 'success', '已退房': 'info' }
      return map[status] || ''
    },
    handleAdd() {
      this.form = { phone: '', guestName: '', typeId: null, roomId: null, checkinDate: '', checkoutDate: '', roomCount: 1, actualGuests: 1, deposit: 0, notes: '' }
      this.dialogVisible = true
    },
    async handlePhoneBlur() {
      if (this.form.phone) {
        const guestsRes = await getGuests()
        if (guestsRes.code === 200) {
          const guest = guestsRes.data.find(g => g.phone === this.form.phone)
          if (guest) this.form.guestName = guest.name
        }
      }
    },
    async handleSubmit() {
      this.$refs.formRef.validate(async (valid) => {
        if (valid) {
          let guestId = null
          const guestsRes = await getGuests()
          if (guestsRes.code === 200) {
            let guest = guestsRes.data.find(g => g.phone === this.form.phone)
            if (!guest) {
              const newGuest = { 
                name: this.form.guestName, 
                phone: this.form.phone, 
                idType: '身份证', 
                idNumber: '',
                password: '123456'
              }
              const insertRes = await addGuest(newGuest)
              if (insertRes.code === 200) {
                guestId = insertRes.data
              } else {
                ElMessage.error('创建客人失败')
                return
              }
            } else {
              guestId = guest.guestId
            }
          }

          const res = await addReservation({ 
            guestId,
            typeId: this.form.typeId,
            roomId: null,
            checkinDate: this.form.checkinDate,
            checkoutDate: this.form.checkoutDate,
            roomCount: this.form.roomCount,
            actualGuests: this.form.actualGuests,
            status: '待确认',
            deposit: this.form.deposit,
            notes: this.form.notes
          })
          if (res.code === 200) {
            ElMessage.success('预订成功')
            this.dialogVisible = false
            this.loadData()
          } else {
            ElMessage.error(res.message || '预订失败')
          }
        }
      })
    },
    openConfirmDialog(row) {
      const type = this.roomTypes.find(t => t.typeId === row.typeId)
      this.confirmForm = {
        reservationId: row.reservationId,
        guestName: row.guestName,
        typeName: row.typeName || (type ? type.typeName : ''),
        typeId: row.typeId,
        roomId: row.roomId,
        roomIds: row.roomId ? [row.roomId] : [],
        roomCount: row.roomCount || 1,
        deposit: row.deposit || 0
      }
      this.confirmDialogVisible = true
    },
    async handleConfirmSubmit() {
      if (!this.confirmForm.roomIds || this.confirmForm.roomIds.length === 0) {
        ElMessage.warning('请选择房间')
        return
      }
      if (this.confirmForm.roomIds.length !== this.confirmForm.roomCount) {
        ElMessage.warning(`请选择 ${this.confirmForm.roomCount} 间房间`)
        return
      }
      const roomId = this.confirmForm.roomIds[0]
      const reservation = {
        reservationId: this.confirmForm.reservationId,
        roomId: roomId,
        deposit: this.confirmForm.deposit,
        status: '已确认'
      }
      const res = await updateReservation(reservation)
      if (res.code === 200) {
        for (const roomId of this.confirmForm.roomIds) {
          await updateRoomStatus(roomId, '已预订')
        }
        ElMessage.success('确认成功')
        this.confirmDialogVisible = false
        this.loadData()
      } else {
        ElMessage.error(res.message || '确认失败')
      }
    },
    async handleCancel(id) {
      try {
        await ElMessageBox.confirm('确定要取消该预订吗？', '提示', { type: 'warning' })
        await updateReservation({ reservationId: id, status: '已取消' })
        ElMessage.success('取消成功')
        this.loadData()
      } catch (e) {}
    },
    handleCheckin(row) {
      this.$router.push({ path: '/reception/checkin', query: { reservationId: row.reservationId } })
    }
  }
}
</script>

<style scoped>
.card-header { display: flex; justify-content: space-between; align-items: center; }
:deep(.el-select) { width: 100%; }
</style>
