<template>
  <div class="bills-container">
    <el-card>
      <template #header>
        <span>账单管理</span>
      </template>
      <el-table :data="bills" border>
        <el-table-column prop="billId" label="账单ID" width="80" />
        <el-table-column prop="guestName" label="客人" width="100" />
        <el-table-column prop="roomNumber" label="房间号" width="100" />
        <el-table-column prop="checkinTime" label="入住时间" width="180">
          <template #default="scope">
            {{ formatTime(scope.row.checkinTime) }}
          </template>
        </el-table-column>
        <el-table-column prop="checkoutTime" label="退房时间" width="180">
          <template #default="scope">
            {{ formatTime(scope.row.checkoutTime) }}
          </template>
        </el-table-column>
        <el-table-column prop="roomCharge" label="房费" width="100">
          <template #default="scope">¥{{ scope.row.roomCharge }}</template>
        </el-table-column>
        <el-table-column prop="otherCharge" label="其他费用" width="100">
          <template #default="scope">¥{{ scope.row.otherCharge }}</template>
        </el-table-column>
        <el-table-column prop="totalCharge" label="总费用" width="100">
          <template #default="scope">¥{{ scope.row.totalCharge }}</template>
        </el-table-column>
        <el-table-column prop="deposit" label="押金" width="100">
          <template #default="scope">¥{{ scope.row.deposit }}</template>
        </el-table-column>
        <el-table-column prop="actualPay" label="实收" width="100">
          <template #default="scope">¥{{ scope.row.actualPay }}</template>
        </el-table-column>
        <el-table-column prop="paymentMethod" label="支付方式" width="100" />
        <el-table-column prop="invoiceStatus" label="发票状态" width="100">
          <template #default="scope">
            <el-tag :type="scope.row.invoiceStatus === '已开具' ? 'success' : 'info'">{{ scope.row.invoiceStatus }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="120">
          <template #default="scope">
            <el-button type="primary" size="small" @click="handlePrint(scope.row)">打印发票</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <el-dialog v-model="printDialogVisible" title="发票预览" width="500px">
      <div class="invoice-content" v-if="currentBill">
        <div class="invoice-header">
          <h2>酒店住宿发票</h2>
        </div>
        <el-descriptions :column="1" border>
          <el-descriptions-item label="发票编号">{{ previewInvoiceNumber }}</el-descriptions-item>
          <el-descriptions-item label="客人姓名">{{ currentBill.guestName }}</el-descriptions-item>
          <el-descriptions-item label="房间号">{{ currentBill.roomNumber }}</el-descriptions-item>
          <el-descriptions-item label="入住时间">{{ formatTime(currentBill.checkinTime) }}</el-descriptions-item>
          <el-descriptions-item label="退房时间">{{ formatTime(currentBill.checkoutTime) }}</el-descriptions-item>
          <el-descriptions-item label="房费">¥{{ currentBill.roomCharge }}</el-descriptions-item>
          <el-descriptions-item label="其他费用">¥{{ currentBill.otherCharge }}</el-descriptions-item>
          <el-descriptions-item label="总费用">¥{{ currentBill.totalCharge }}</el-descriptions-item>
          <el-descriptions-item label="押金">¥{{ currentBill.deposit }}</el-descriptions-item>
          <el-descriptions-item label="实收金额">¥{{ currentBill.actualPay }}</el-descriptions-item>
          <el-descriptions-item label="支付方式">{{ currentBill.paymentMethod }}</el-descriptions-item>
          <el-descriptions-item label="开票时间">{{ formatTime(new Date()) }}</el-descriptions-item>
        </el-descriptions>
      </div>
      <template #footer>
        <el-button @click="printDialogVisible = false">取消</el-button>
        <el-button type="primary" @click="confirmPrint">确认打印</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script>
import { getBills, updateBill, getMaxInvoiceNumber } from '../../api'
import { getUser } from '../../utils/authStorage'
import { ElMessage } from 'element-plus'

export default {
  name: 'Bills',
  data() {
    return {
      bills: [],
      printDialogVisible: false,
      currentBill: null,
      previewInvoiceNumber: ''
    }
  },
  mounted() {
    this.loadData()
  },
  methods: {
    formatTime(time) {
      if (!time) return ''
      const date = new Date(time)
      return date.toLocaleString('zh-CN')
    },
    async loadData() {
      const storeId = getUser()?.storeId ?? null
      const res = await getBills()
      if (res.code === 200) {
        if (storeId) {
          this.bills = res.data.filter(b => b.storeId === storeId)
        } else {
          this.bills = res.data
        }
      }
    },
    async handlePrint(row) {
      this.currentBill = { ...row }
      if (!this.currentBill.invoiceNumber) {
        this.previewInvoiceNumber = await this.generateInvoiceNumber()
      } else {
        this.previewInvoiceNumber = this.currentBill.invoiceNumber
      }
      this.printDialogVisible = true
    },
    async generateInvoiceNumber() {
      const res = await getMaxInvoiceNumber()
      const maxNumber = res.data
      let nextNum = 1
      if (maxNumber && maxNumber.startsWith('A')) {
        const numPart = maxNumber.substring(1)
        nextNum = parseInt(numPart, 10) + 1
      }
      return 'A' + String(nextNum).padStart(4, '0')
    },
    async confirmPrint() {
      const res = await updateBill({
        billId: this.currentBill.billId,
        checkinId: this.currentBill.checkinId,
        roomCharge: this.currentBill.roomCharge,
        otherCharge: this.currentBill.otherCharge,
        totalCharge: this.currentBill.totalCharge,
        deposit: this.currentBill.deposit,
        actualPay: this.currentBill.actualPay,
        paymentMethod: this.currentBill.paymentMethod,
        invoiceStatus: '已开具',
        invoiceNumber: this.previewInvoiceNumber,
        checkoutTime: this.currentBill.checkoutTime,
        staffId: this.currentBill.staffId
      })
      
      if (res.code === 200) {
        ElMessage.success('发票打印成功')
        this.printDialogVisible = false
        this.loadData()
        window.print()
      }
    }
  }
}
</script>

<style scoped>
.invoice-content {
  padding: 20px;
}
.invoice-header {
  text-align: center;
  margin-bottom: 20px;
}
.invoice-header h2 {
  margin: 0;
  font-size: 24px;
}
@media print {
  :deep(.el-dialog__footer),
  :deep(.el-button),
  :deep(.el-card__header) {
    display: none !important;
  }
  :deep(.el-dialog) {
    border: none;
    box-shadow: none;
  }
  :deep(.el-descriptions) {
    border: 1px solid #000;
  }
}
</style>
