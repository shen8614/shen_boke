<template>
  <el-container class="layout-container hm-layout">
    <el-aside width="220px">
      <div class="hm-logo">
        <div class="hm-logo-row">
          <img class="hm-logo-icon" src="/images/brand-mark.svg" width="36" height="36" alt="" />
          <div class="hm-logo-texts">
            <span class="brand-cn">酒店客房管理</span>
            <span class="brand-en">Hotel Room Mgmt</span>
          </div>
        </div>
        <span class="brand-tag">门店前台工作台</span>
      </div>
      <el-menu
        :default-active="$route.path"
        router
        text-color="rgba(255,255,255,0.82)"
        active-text-color="#d4c4a0"
      >
        <el-menu-item index="/reception/room-status">
          <el-icon><House /></el-icon>
          <span>房态监控</span>
        </el-menu-item>
        <el-menu-item index="/reception/reservations">
          <el-icon><Calendar /></el-icon>
          <span>预订管理</span>
        </el-menu-item>
        <el-menu-item index="/reception/checkin">
          <el-icon><Key /></el-icon>
          <span>入住办理</span>
        </el-menu-item>
        <el-menu-item index="/reception/checkout">
          <el-icon><Unlock /></el-icon>
          <span>退房结算</span>
        </el-menu-item>
        <el-menu-item index="/reception/consumption">
          <el-icon><Goods /></el-icon>
          <span>消费管理</span>
        </el-menu-item>
        <el-menu-item index="/reception/bills">
          <el-icon><Ticket /></el-icon>
          <span>账单管理</span>
        </el-menu-item>
        <el-menu-item index="/reception/guests">
          <el-icon><User /></el-icon>
          <span>客户管理</span>
        </el-menu-item>
      </el-menu>
    </el-aside>
    <el-container>
      <el-header class="hm-header">
        <div class="hm-header-left">
          <span class="hm-portal-name">当日接待与收银</span>
          <span class="hm-portal-desc">预订 · 入住 · 消费 · 结账一体化</span>
        </div>
        <div class="hm-header-right">
          <span class="hm-user-pill">{{ user.name }} · {{ user.storeName || '门店' }}</span>
          <el-button class="hm-logout" size="small" @click="handleLogout">交班退出</el-button>
        </div>
      </el-header>
      <el-main class="hm-main hm-card-panel">
        <router-view />
      </el-main>
    </el-container>
  </el-container>
</template>

<script>
import { getUser, clearAuth } from '../../utils/authStorage'

export default {
  name: 'Layout',
  data() {
    return {
      user: {}
    }
  },
  mounted() {
    const u = getUser()
    if (u) this.user = u
  },
  methods: {
    handleLogout() {
      clearAuth()
      this.$router.push('/login')
    }
  }
}
</script>

<style scoped>
.layout-container {
  height: 100vh;
}
</style>
