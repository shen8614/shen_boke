<template>
  <el-container class="layout-container hm-layout">
    <el-aside width="220px">
      <div class="hm-logo">
        <div class="hm-logo-row">
          <img class="hm-logo-icon" src="/images/brand-mark.svg" width="36" height="36" alt="" />
          <div class="hm-logo-texts">
            <span class="brand-cn">酒店客房管理</span>
            <span class="brand-en">Hotel Room Mgmt</span>
          </div>
        </div>
        <span class="brand-tag">集团管理后台</span>
      </div>
      <el-menu
        :default-active="$route.path"
        router
        text-color="rgba(255,255,255,0.82)"
        active-text-color="#d4c4a0"
      >
        <el-menu-item index="/admin/dashboard">
          <el-icon><DataAnalysis /></el-icon>
          <span>数据统计</span>
        </el-menu-item>
        <el-menu-item index="/admin/analytics">
          <el-icon><TrendCharts /></el-icon>
          <span>营业分析</span>
        </el-menu-item>
        <el-menu-item index="/admin/rooms">
          <el-icon><House /></el-icon>
          <span>客房管理</span>
        </el-menu-item>
        <el-menu-item index="/admin/room-types">
          <el-icon><Grid /></el-icon>
          <span>房型管理</span>
        </el-menu-item>
        <el-menu-item index="/admin/staff">
          <el-icon><User /></el-icon>
          <span>员工管理</span>
        </el-menu-item>
        <el-menu-item index="/admin/stores">
          <el-icon><OfficeBuilding /></el-icon>
          <span>门店管理</span>
        </el-menu-item>
        <el-menu-item index="/admin/guests">
          <el-icon><UserFilled /></el-icon>
          <span>客户管理</span>
        </el-menu-item>
      </el-menu>
    </el-aside>
    <el-container>
      <el-header class="hm-header">
        <div class="hm-header-left">
          <span class="hm-portal-name">全集团数据与资源配置</span>
          <span class="hm-portal-desc">多门店房态 · 员工权限 · 营收概览</span>
        </div>
        <div class="hm-header-right">
          <span class="hm-user-pill">{{ user.name }}</span>
          <el-button class="hm-logout" size="small" @click="handleLogout">安全退出</el-button>
        </div>
      </el-header>
      <el-main class="hm-main hm-card-panel">
        <router-view />
      </el-main>
    </el-container>
  </el-container>
</template>

<script>
import { getUser, clearAuth } from '../../utils/authStorage'

export default {
  name: 'Layout',
  data() {
    return {
      user: {}
    }
  },
  mounted() {
    const u = getUser()
    if (u) this.user = u
  },
  methods: {
    handleLogout() {
      clearAuth()
      this.$router.push('/login')
    }
  }
}
</script>

<style scoped>
.layout-container {
  height: 100vh;
}
</style>
