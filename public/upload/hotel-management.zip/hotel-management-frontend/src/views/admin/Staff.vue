<template>
  <div class="rooms-container">
    <el-card>
      <template #header>
        <div class="card-header">
          <span>员工管理</span>
          <el-button type="primary" @click="handleAdd">新增员工</el-button>
        </div>
      </template>
      <el-table :data="staff" border style="width: 100%">
        <el-table-column prop="username" label="用户名" width="120" />
        <el-table-column prop="name" label="姓名" width="100" />
        <el-table-column prop="roleName" label="角色" width="100" />
        <el-table-column prop="phone" label="电话" width="150" />
        <el-table-column prop="storeName" label="所属酒店" width="150" />
        <el-table-column label="操作" width="200" fixed="right">
          <template #default="scope">
            <el-button size="small" @click="handleEdit(scope.row)">编辑</el-button>
            <el-button size="small" type="danger" @click="handleDelete(scope.row.staffId)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <el-dialog v-model="dialogVisible" :title="dialogTitle" width="500px">
      <el-form :model="form" :rules="rules" ref="formRef" label-width="100px">
        <el-form-item label="用户名" prop="username">
          <el-input v-model="form.username" />
        </el-form-item>
        <el-form-item label="密码" prop="password">
          <el-input v-model="form.password" type="password" />
        </el-form-item>
        <el-form-item label="姓名" prop="name">
          <el-input v-model="form.name" />
        </el-form-item>
        <el-form-item label="角色" prop="roleId">
          <el-select v-model="form.roleId">
            <el-option label="管理员" :value="1" />
            <el-option label="前台" :value="2" />
          </el-select>
        </el-form-item>
        <el-form-item label="电话" prop="phone">
          <el-input v-model="form.phone" />
        </el-form-item>
        <el-form-item label="门店" prop="storeId">
          <el-select v-model="form.storeId">
            <el-option v-for="s in stores" :key="s.storeId" :label="s.storeName" :value="s.storeId" />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="handleSubmit">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script>
import { getStaff, addStaff, updateStaff, deleteStaff, getStores } from '../../api'
import { ElMessage, ElMessageBox } from 'element-plus'

export default {
  name: 'Staff',
  data() {
    return {
      staff: [],
      stores: [],
      dialogVisible: false,
      dialogTitle: '新增员工',
      form: { staffId: null, username: '', password: '', name: '', roleId: 2, phone: '', storeId: null },
      rules: {
        username: [{ required: true, message: '请输入用户名', trigger: 'blur' }],
        password: [{ required: true, message: '请输入密码', trigger: 'blur' }],
        name: [{ required: true, message: '请输入姓名', trigger: 'blur' }],
        roleId: [{ required: true, message: '请选择角色', trigger: 'change' }],
        phone: [{ required: true, message: '请输入电话', trigger: 'blur' }],
        storeId: []
      }
    }
  },
  mounted() { this.loadData() },
  methods: {
    async loadData() {
      const [staffRes, storesRes] = await Promise.all([getStaff(), getStores()])
      if (staffRes.code === 200) this.staff = staffRes.data
      if (storesRes.code === 200) this.stores = storesRes.data
    },
    handleAdd() {
      this.form = { staffId: null, username: '', password: '', name: '', roleId: 2, phone: '', storeId: null }
      this.dialogTitle = '新增员工'
      this.dialogVisible = true
    },
    handleEdit(row) {
      this.form = { ...row }
      this.dialogTitle = '编辑员工'
      this.dialogVisible = true
    },
    async handleSubmit() {
      this.$refs.formRef.validate(async (valid) => {
        if (valid) {
          const res = this.form.staffId ? await updateStaff(this.form) : await addStaff(this.form)
          if (res.code === 200) {
            ElMessage.success('操作成功')
            this.dialogVisible = false
            this.loadData()
          }
        }
      })
    },
    async handleDelete(id) {
      await ElMessageBox.confirm('确定要删除该员工吗？', '提示', { type: 'warning' })
      const res = await deleteStaff(id)
      if (res.code === 200) {
        ElMessage.success('删除成功')
        this.loadData()
      }
    }
  }
}
</script>

<style scoped>
.card-header { display: flex; justify-content: space-between; align-items: center; }
:deep(.el-select) { width: 100%; }
</style>
