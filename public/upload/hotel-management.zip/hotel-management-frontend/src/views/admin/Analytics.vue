<template>
  <div class="analytics hm-card-panel">
    <el-card class="toolbar-card" shadow="never">
      <div class="toolbar">
        <div class="toolbar-title">
          <el-icon class="title-icon"><TrendCharts /></el-icon>
          <div>
            <h2>营业分析 · 报表中心</h2>
            <p class="toolbar-desc">基于已结账账单统计营收；入住率为当前房态实时快照（与前台房态同步）</p>
          </div>
        </div>
        <div class="toolbar-filters">
          <el-date-picker
            v-model="dateRange"
            type="daterange"
            range-separator="至"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            value-format="YYYY-MM-DD"
            :disabled-date="disableFuture"
            @change="loadRevenue"
          />
          <el-select v-model="filterStoreId" placeholder="全部门店" clearable style="width: 200px" @change="loadAll">
            <el-option v-for="s in stores" :key="s.storeId" :label="s.storeName" :value="s.storeId" />
          </el-select>
          <el-button type="primary" @click="loadAll">
            <el-icon><Refresh /></el-icon>
            刷新
          </el-button>
        </div>
      </div>
    </el-card>

    <el-row :gutter="16" class="kpi-row">
      <el-col :xs="24" :sm="12" :lg="6">
        <el-card shadow="never" class="kpi-card">
          <div class="kpi-label">实时入住率</div>
          <div class="kpi-value">{{ occ.occupancyRatePercent != null ? occ.occupancyRatePercent.toFixed(2) : '0.00' }}%</div>
          <div class="kpi-sub">在住 {{ occ.occupiedRooms ?? 0 }} / 总房 {{ occ.totalRooms ?? 0 }}</div>
        </el-card>
      </el-col>
      <el-col :xs="24" :sm="12" :lg="6">
        <el-card shadow="never" class="kpi-card kpi-revenue">
          <div class="kpi-label">区间营业实收</div>
          <div class="kpi-value">¥{{ fmtMoney(summary.totalActualPay) }}</div>
          <div class="kpi-sub">房费 ¥{{ fmtMoney(summary.totalRoomCharge) }} · 杂费 ¥{{ fmtMoney(summary.totalOtherCharge) }}</div>
        </el-card>
      </el-col>
      <el-col :xs="24" :sm="12" :lg="6">
        <el-card shadow="never" class="kpi-card">
          <div class="kpi-label">结账订单数</div>
          <div class="kpi-value">{{ summary.billCount ?? 0 }}</div>
          <div class="kpi-sub">所选日期内完成结账的账单笔数</div>
        </el-card>
      </el-col>
      <el-col :xs="24" :sm="12" :lg="6">
        <el-card shadow="never" class="kpi-card">
          <div class="kpi-label">平均客单（实收）</div>
          <div class="kpi-value">¥{{ fmtMoney(summary.avgActualPay) }}</div>
          <div class="kpi-sub">实收总额 ÷ 订单数</div>
        </el-card>
      </el-col>
    </el-row>

    <el-row :gutter="16" class="block-row">
      <el-col :xs="24" :lg="14">
        <el-card shadow="never">
          <template #header>
            <span>分门店入住率（实时）</span>
          </template>
          <el-table :data="byStore" stripe style="width: 100%">
            <el-table-column prop="storeName" label="门店" min-width="140" />
            <el-table-column prop="totalRooms" label="总客房" width="100" />
            <el-table-column prop="occupiedRooms" label="在住" width="80" />
            <el-table-column label="入住率" width="200">
              <template #default="{ row }">
                <el-progress
                  :percentage="Math.min(100, Number(row.occupancyRatePercent) || 0)"
                  :stroke-width="10"
                  :format="() => `${(row.occupancyRatePercent ?? 0).toFixed(1)}%`"
                />
              </template>
            </el-table-column>
          </el-table>
        </el-card>
      </el-col>
      <el-col :xs="24" :lg="10">
        <el-card shadow="never">
          <template #header>
            <span>支付方式结构（区间内）</span>
          </template>
          <div v-if="!paymentMix.length" class="empty-hint">该条件下暂无结账数据</div>
          <div v-else class="pay-mix">
            <div v-for="p in paymentMix" :key="p.paymentMethod || 'x'" class="pay-row">
              <span class="pay-name">{{ p.paymentMethod || '未填写' }}</span>
              <el-progress
                :percentage="payPercent(p.amount)"
                :stroke-width="8"
                :format="() => `¥${fmtMoney(p.amount)}`"
              />
              <span class="pay-count">{{ p.billCount }} 笔</span>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <el-card shadow="never" class="block-row">
      <template #header>
        <span>营收趋势（按结账日）</span>
      </template>
      <div v-if="!trend.length" class="empty-hint">该日期范围内暂无账单</div>
      <div v-else class="trend-chart">
        <div v-for="t in trend" :key="t.day" class="trend-bar-wrap">
          <div class="trend-bar" :style="{ height: trendBarHeight(t.amount) + 'px' }" :title="`${t.day} ¥${fmtMoney(t.amount)}`" />
          <div class="trend-day">{{ t.day.slice(5) }}</div>
          <div class="trend-amt">¥{{ fmtMoney(t.amount) }}</div>
        </div>
      </div>
    </el-card>

    <el-card shadow="never">
      <template #header>
        <div class="report-header">
          <span>营业明细报表（可导出）</span>
          <el-button type="primary" plain size="small" :disabled="!reportRows.length" @click="exportCsv">
            <el-icon><Download /></el-icon>
            导出 CSV
          </el-button>
        </div>
      </template>
      <el-table :data="reportRows" stripe max-height="420" style="width: 100%">
        <el-table-column prop="billId" label="账单号" width="80" />
        <el-table-column prop="guestName" label="客人" width="100" />
        <el-table-column prop="roomNumber" label="房间" width="80" />
        <el-table-column label="门店" width="120">
          <template #default="{ row }">{{ storeName(row.storeId) }}</template>
        </el-table-column>
        <el-table-column label="入住时间" width="160">
          <template #default="{ row }">{{ formatDt(row.checkinTime) }}</template>
        </el-table-column>
        <el-table-column label="结账时间" width="160">
          <template #default="{ row }">{{ formatDt(row.checkoutTime) }}</template>
        </el-table-column>
        <el-table-column label="房费" width="100">
          <template #default="{ row }">¥{{ fmtMoney(row.roomCharge) }}</template>
        </el-table-column>
        <el-table-column label="杂费" width="100">
          <template #default="{ row }">¥{{ fmtMoney(row.otherCharge) }}</template>
        </el-table-column>
        <el-table-column label="实收" width="100">
          <template #default="{ row }">¥{{ fmtMoney(row.actualPay) }}</template>
        </el-table-column>
        <el-table-column prop="paymentMethod" label="支付" width="90" />
        <el-table-column prop="invoiceStatus" label="发票" width="90" />
      </el-table>
    </el-card>
  </div>
</template>

<script>
import {
  getStatisticsOccupancy,
  getStatisticsOccupancyByStore,
  getStatisticsRevenueAnalysis,
  getStatisticsReportBills,
  getStores
} from '../../api'
import { ElMessage } from 'element-plus'

function formatDate(d) {
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${y}-${m}-${day}`
}

export default {
  name: 'Analytics',
  data() {
    const end = new Date()
    const start = new Date()
    start.setDate(start.getDate() - 29)
    return {
      dateRange: [formatDate(start), formatDate(end)],
      filterStoreId: null,
      stores: [],
      occ: {},
      byStore: [],
      summary: {},
      trend: [],
      paymentMix: [],
      reportRows: [],
      trendMax: 1
    }
  },
  mounted() {
    this.initStores()
    this.loadAll()
  },
  methods: {
    disableFuture(time) {
      return time.getTime() > Date.now()
    },
    async initStores() {
      const res = await getStores()
      if (res.code === 200) this.stores = res.data || []
    },
    storeName(id) {
      const s = this.stores.find((x) => x.storeId === id)
      return s ? s.storeName : id != null ? `门店#${id}` : '-'
    },
    fmtMoney(v) {
      if (v == null || v === '') return '0.00'
      const n = Number(v)
      return Number.isFinite(n) ? n.toFixed(2) : '0.00'
    },
    formatDt(v) {
      if (v == null || v === '') return '-'
      if (typeof v === 'string') return v.replace('T', ' ').slice(0, 19)
      if (Array.isArray(v) && v.length >= 3) {
        const [y, m, d, h = 0, min = 0, s = 0] = v
        const pad = (n) => String(n).padStart(2, '0')
        return `${y}-${pad(m)}-${pad(d)} ${pad(h)}:${pad(min)}:${pad(s)}`
      }
      return String(v)
    },
    payPercent(amount) {
      const t = Number(this.summary.totalActualPay) || 0
      if (t <= 0) return 0
      return Math.min(100, Math.round((Number(amount) / t) * 1000) / 10)
    },
    trendBarHeight(amount) {
      const a = Number(amount) || 0
      const max = this.trendMax || 1
      return Math.max(4, Math.round((a / max) * 120))
    },
    async loadAll() {
      await Promise.all([this.loadOccupancy(), this.loadRevenue(), this.loadReport()])
    },
    async loadOccupancy() {
      try {
        const params = this.filterStoreId != null ? this.filterStoreId : undefined
        const [o, bs] = await Promise.all([
          getStatisticsOccupancy(params),
          getStatisticsOccupancyByStore()
        ])
        if (o.code !== 200) {
          ElMessage.error(o.message || '加载入住率失败')
          return
        }
        this.occ = o.data || {}
        if (bs.code === 200) this.byStore = bs.data || []
      } catch (e) {
        ElMessage.error('网络错误')
      }
    },
    async loadRevenue() {
      if (!this.dateRange || this.dateRange.length !== 2) return
      const [startDate, endDate] = this.dateRange
      try {
        const res = await getStatisticsRevenueAnalysis(
          startDate,
          endDate,
          this.filterStoreId
        )
        if (res.code !== 200) {
          ElMessage.error(res.message || '加载营收失败')
          return
        }
        const d = res.data || {}
        this.summary = d.summary || {}
        this.trend = d.trend || []
        this.paymentMix = d.paymentMix || []
        this.trendMax = Math.max(1, ...this.trend.map((t) => Number(t.amount) || 0))
      } catch (e) {
        ElMessage.error('网络错误')
      }
    },
    async loadReport() {
      if (!this.dateRange || this.dateRange.length !== 2) return
      const [startDate, endDate] = this.dateRange
      try {
        const res = await getStatisticsReportBills(startDate, endDate, this.filterStoreId)
        if (res.code !== 200) {
          ElMessage.error(res.message || '加载报表失败')
          return
        }
        this.reportRows = res.data || []
      } catch (e) {
        ElMessage.error('网络错误')
      }
    },
    exportCsv() {
      const headers = [
        '账单号',
        '客人',
        '房间',
        '门店',
        '入住时间',
        '结账时间',
        '房费',
        '杂费',
        '实收',
        '支付方式',
        '发票状态'
      ]
      const rows = this.reportRows.map((r) => [
        r.billId,
        r.guestName,
        r.roomNumber,
        this.storeName(r.storeId),
        this.formatDt(r.checkinTime),
        this.formatDt(r.checkoutTime),
        this.fmtMoney(r.roomCharge),
        this.fmtMoney(r.otherCharge),
        this.fmtMoney(r.actualPay),
        r.paymentMethod,
        r.invoiceStatus
      ])
      const body = [headers, ...rows].map((line) => line.map((c) => `"${String(c ?? '').replace(/"/g, '""')}"`).join(',')).join('\r\n')
      const bom = '\uFEFF'
      const blob = new Blob([bom + body], { type: 'text/csv;charset=utf-8' })
      const a = document.createElement('a')
      a.href = URL.createObjectURL(blob)
      a.download = `营业报表_${this.dateRange[0]}_${this.dateRange[1]}.csv`
      a.click()
      URL.revokeObjectURL(a.href)
      ElMessage.success('已导出 CSV')
    }
  }
}
</script>

<style scoped>
.analytics {
  padding: 0;
}

.toolbar-card {
  margin-bottom: 16px;
}

.toolbar {
  display: flex;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: space-between;
  gap: 16px;
}

.toolbar-title {
  display: flex;
  gap: 12px;
  align-items: flex-start;
}

.title-icon {
  font-size: 28px;
  color: var(--hm-primary, #1a3a52);
  margin-top: 4px;
}

.toolbar-title h2 {
  margin: 0 0 6px;
  font-size: 18px;
  font-weight: 600;
  color: var(--hm-text, #1c2938);
}

.toolbar-desc {
  margin: 0;
  font-size: 13px;
  color: var(--hm-text-muted, #5c6b7a);
  max-width: 520px;
  line-height: 1.5;
}

.toolbar-filters {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 12px;
}

.kpi-row {
  margin-bottom: 16px;
}

.kpi-card {
  margin-bottom: 16px;
  border-radius: var(--hm-radius, 10px);
}

.kpi-label {
  font-size: 13px;
  color: var(--hm-text-muted, #5c6b7a);
  margin-bottom: 8px;
}

.kpi-value {
  font-size: 26px;
  font-weight: 700;
  color: var(--hm-primary, #1a3a52);
  line-height: 1.2;
}

.kpi-revenue .kpi-value {
  font-size: 22px;
}

.kpi-sub {
  margin-top: 8px;
  font-size: 12px;
  color: #909399;
  line-height: 1.4;
}

.block-row {
  margin-bottom: 16px;
}

.empty-hint {
  color: #909399;
  font-size: 14px;
  padding: 24px 0;
  text-align: center;
}

.pay-mix {
  display: flex;
  flex-direction: column;
  gap: 14px;
}

.pay-row {
  display: grid;
  grid-template-columns: 72px 1fr 56px;
  gap: 10px;
  align-items: center;
}

.pay-name {
  font-size: 13px;
  color: var(--hm-text, #1c2938);
}

.pay-count {
  font-size: 12px;
  color: #909399;
  text-align: right;
}

.trend-chart {
  display: flex;
  align-items: flex-end;
  gap: 8px;
  min-height: 160px;
  padding: 8px 0 4px;
  overflow-x: auto;
}

.trend-bar-wrap {
  flex: 0 0 auto;
  width: 56px;
  display: flex;
  flex-direction: column;
  align-items: center;
}

.trend-bar {
  width: 28px;
  min-height: 4px;
  background: linear-gradient(180deg, #2d5a7b 0%, #1a3a52 100%);
  border-radius: 4px 4px 0 0;
  transition: height 0.2s;
}

.trend-day {
  margin-top: 6px;
  font-size: 11px;
  color: #909399;
}

.trend-amt {
  font-size: 10px;
  color: #606266;
  margin-top: 2px;
  white-space: nowrap;
}

.report-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
}
</style>
