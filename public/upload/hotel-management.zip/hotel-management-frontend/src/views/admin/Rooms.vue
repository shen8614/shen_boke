<template>
  <div class="rooms-container">
    <el-card>
      <template #header>
        <div class="card-header">
          <span>客房管理</span>
          <el-button type="primary" @click="handleAdd">新增客房</el-button>
        </div>
      </template>

      <el-table :data="rooms" border style="width: 100%">
        <el-table-column prop="roomNumber" label="房间号" width="100" />
        <el-table-column prop="typeName" label="房型" width="120" />
        <el-table-column prop="floor" label="楼层" width="80" />
        <el-table-column prop="standardPrice" label="价格" width="100">
          <template #default="scope">
            ¥{{ scope.row.standardPrice }}
          </template>
        </el-table-column>
        <el-table-column prop="status" label="状态" width="100">
          <template #default="scope">
            <el-tag :type="getStatusType(scope.row.status)">{{ scope.row.status }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="facilities" label="设施" />
        <el-table-column label="操作" width="200" fixed="right">
          <template #default="scope">
            <el-button size="small" @click="handleEdit(scope.row)">编辑</el-button>
            <el-button size="small" type="danger" @click="handleDelete(scope.row.roomId)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <el-dialog v-model="dialogVisible" :title="dialogTitle" width="500px">
      <el-form :model="roomForm" :rules="rules" ref="formRef" label-width="100px">
        <el-form-item label="房间号" prop="roomNumber">
          <el-input v-model="roomForm.roomNumber" placeholder="如：101" />
        </el-form-item>
        <el-form-item label="房型" prop="typeId">
          <el-select v-model="roomForm.typeId" placeholder="请选择房型">
            <el-option v-for="type in roomTypes" :key="type.typeId" :label="type.typeName" :value="type.typeId" />
          </el-select>
        </el-form-item>
        <el-form-item label="楼层" prop="floor">
          <el-input-number v-model="roomForm.floor" :min="1" :max="20" />
        </el-form-item>
        <el-form-item label="价格" prop="standardPrice">
          <el-input-number v-model="roomForm.standardPrice" :min="0" :precision="2" />
        </el-form-item>
        <el-form-item label="状态" prop="status">
          <el-select v-model="roomForm.status">
            <el-option label="可售" value="可售" />
            <el-option label="已入住" value="已入住" />
            <el-option label="清扫中" value="清扫中" />
            <el-option label="维修中" value="维修中" />
          </el-select>
        </el-form-item>
        <el-form-item label="设施" prop="facilities">
          <el-input v-model="roomForm.facilities" type="textarea" rows="3" placeholder="房间设施描述" />
        </el-form-item>
        <el-form-item label="所属门店" prop="storeId">
          <el-select v-model="roomForm.storeId" placeholder="请选择门店">
            <el-option v-for="store in stores" :key="store.storeId" :label="store.storeName" :value="store.storeId" />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="handleSubmit">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script>
import { getRooms, addRoom, updateRoom, deleteRoom, getRoomTypes, getStores } from '../../api'
import { ElMessage, ElMessageBox } from 'element-plus'

export default {
  name: 'Rooms',
  data() {
    return {
      rooms: [],
      roomTypes: [],
      stores: [],
      dialogVisible: false,
      dialogTitle: '新增客房',
      roomForm: {
        roomId: null,
        roomNumber: '',
        typeId: null,
        floor: 1,
        standardPrice: 0,
        status: '可售',
        facilities: '',
        storeId: null
      },
      rules: {
        roomNumber: [{ required: true, message: '请输入房间号', trigger: 'blur' }],
        typeId: [{ required: true, message: '请选择房型', trigger: 'change' }],
        floor: [{ required: true, message: '请输入楼层', trigger: 'blur' }],
        standardPrice: [{ required: true, message: '请输入价格', trigger: 'blur' }],
        storeId: [{ required: true, message: '请选择门店', trigger: 'change' }]
      }
    }
  },
  mounted() {
    this.loadData()
  },
  methods: {
    async loadData() {
      try {
        const [roomsRes, typesRes, storesRes] = await Promise.all([getRooms(), getRoomTypes(), getStores()])
        if (roomsRes.code === 200) this.rooms = roomsRes.data
        if (typesRes.code === 200) this.roomTypes = typesRes.data
        if (storesRes.code === 200) this.stores = storesRes.data
      } catch (error) {
        console.error(error)
      }
    },
    getStatusType(status) {
      const map = { '可售': 'success', '已入住': 'warning', '清扫中': 'info', '维修中': 'danger' }
      return map[status] || ''
    },
    handleAdd() {
      this.roomForm = { roomId: null, roomNumber: '', typeId: null, floor: 1, standardPrice: 0, status: '可售', facilities: '', storeId: null }
      this.dialogTitle = '新增客房'
      this.dialogVisible = true
    },
    handleEdit(row) {
      this.roomForm = { ...row }
      this.dialogTitle = '编辑客房'
      this.dialogVisible = true
    },
    async handleSubmit() {
      this.$refs.formRef.validate(async (valid) => {
        if (valid) {
          try {
            const res = this.roomForm.roomId ? await updateRoom(this.roomForm) : await addRoom(this.roomForm)
            if (res.code === 200) {
              ElMessage.success(this.roomForm.roomId ? '修改成功' : '添加成功')
              this.dialogVisible = false
              this.loadData()
            } else {
              ElMessage.error(res.message)
            }
          } catch (error) {
            ElMessage.error('操作失败')
          }
        }
      })
    },
    async handleDelete(id) {
      try {
        await ElMessageBox.confirm('确定要删除该客房吗？', '提示', { type: 'warning' })
        const res = await deleteRoom(id)
        if (res.code === 200) {
          ElMessage.success('删除成功')
          this.loadData()
        } else {
          ElMessage.error(res.message)
        }
      } catch (e) {}
    }
  }
}
</script>

<style scoped>
.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

:deep(.el-select) {
  width: 100%;
}
</style>
