<template>
  <div class="rooms-container">
    <el-card>
      <template #header>
        <div class="card-header">
          <span>房型管理</span>
          <el-button type="primary" @click="handleAdd">新增房型</el-button>
        </div>
      </template>
      <el-table :data="roomTypes" border style="width: 100%">
        <el-table-column label="房型图片" width="100">
          <template #default="scope">
            <el-image
              v-if="scope.row.image"
              :src="scope.row.image"
              style="width: 60px; height: 40px; border-radius: 4px"
              fit="cover"
              :preview-src-list="[scope.row.image]"
            />
            <span v-else style="color: #c0c4cc">无图片</span>
          </template>
        </el-table-column>
        <el-table-column prop="storeName" label="所属门店" width="120" />
        <el-table-column prop="typeName" label="房型名称" width="130" />
        <el-table-column prop="description" label="描述" />
        <el-table-column prop="basePrice" label="基础价格" width="110">
          <template #default="scope">¥{{ scope.row.basePrice }}</template>
        </el-table-column>
        <el-table-column prop="maxOccupancy" label="最大人数" width="90" />
        <el-table-column label="操作" width="200" fixed="right">
          <template #default="scope">
            <el-button size="small" @click="handleEdit(scope.row)">编辑</el-button>
            <el-button size="small" type="danger" @click="handleDelete(scope.row.typeId)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <el-dialog v-model="dialogVisible" :title="dialogTitle" width="550px">
      <el-form :model="form" :rules="rules" ref="formRef" label-width="100px">
        <el-form-item label="门店" prop="storeId">
          <el-select v-model="form.storeId" placeholder="请选择门店">
            <el-option v-for="store in stores" :key="store.storeId" :label="store.storeName" :value="store.storeId" />
          </el-select>
        </el-form-item>
        <el-form-item label="房型名称" prop="typeName">
          <el-input v-model="form.typeName" />
        </el-form-item>
        <el-form-item label="描述" prop="description">
          <el-input v-model="form.description" type="textarea" rows="3" />
        </el-form-item>
        <el-form-item label="基础价格" prop="basePrice">
          <el-input-number v-model="form.basePrice" :min="0" :precision="2" />
        </el-form-item>
        <el-form-item label="最大人数" prop="maxOccupancy">
          <el-input-number v-model="form.maxOccupancy" :min="1" :max="10" />
        </el-form-item>
        <el-form-item label="房型图片">
          <el-upload
            class="store-upload"
            :action="''"
            :show-file-list="false"
            :http-request="customUpload"
            :before-upload="beforeUpload"
            :on-change="handleFileChange"
          >
            <img v-if="form.image" :src="form.image" class="upload-preview" />
            <img v-else-if="previewUrl" :src="previewUrl" class="upload-preview" />
            <el-icon v-else class="upload-icon"><Plus /></el-icon>
          </el-upload>
          <span v-if="uploading" style="margin-left: 8px; color: #409eff; font-size: 13px">上传中...</span>
          <el-button v-if="form.image && !uploading" type="danger" size="small" plain @click="removeImage" style="margin-left: 10px">
            移除图片
          </el-button>
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="handleSubmit" :loading="submitting">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script>
import { getRoomTypes, addRoomType, updateRoomType, deleteRoomType, getStores, uploadFile } from '../../api'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Plus } from '@element-plus/icons-vue'

export default {
  name: 'RoomTypes',
  components: { Plus },
  data() {
    return {
      roomTypes: [],
      stores: [],
      dialogVisible: false,
      dialogTitle: '新增房型',
      submitting: false,
      previewUrl: '',
      uploading: false,
      form: { typeId: null, typeName: '', description: '', basePrice: 0, maxOccupancy: 2, storeId: null, image: '' },
      rules: {
        typeName: [{ required: true, message: '请输入房型名称', trigger: 'blur' }],
        basePrice: [{ required: true, message: '请输入基础价格', trigger: 'blur' }],
        maxOccupancy: [{ required: true, message: '请输入最大人数', trigger: 'blur' }],
        storeId: [{ required: true, message: '请选择门店', trigger: 'change' }]
      }
    }
  },
  mounted() { this.loadData() },
  beforeUnmount() { this.revokePreview() },
  watch: {
    dialogVisible(val) {
      if (!val) this.revokePreview()
    }
  },
  methods: {
    async loadData() {
      const [typesRes, storesRes] = await Promise.all([getRoomTypes(), getStores()])
      if (typesRes.code === 200) this.roomTypes = typesRes.data
      if (storesRes.code === 200) this.stores = storesRes.data
    },
    handleAdd() {
      this.revokePreview()
      this.form = { typeId: null, typeName: '', description: '', basePrice: 0, maxOccupancy: 2, storeId: null, image: '' }
      this.dialogTitle = '新增房型'
      this.dialogVisible = true
    },
    handleEdit(row) {
      this.revokePreview()
      this.form = { ...row }
      this.dialogTitle = '编辑房型'
      this.dialogVisible = true
    },
    handleFileChange(file) {
      this.revokePreview()
      if (file.status !== 'fail') {
        this.previewUrl = URL.createObjectURL(file.raw)
      }
    },
    revokePreview() {
      if (this.previewUrl) {
        URL.revokeObjectURL(this.previewUrl)
        this.previewUrl = ''
      }
    },
    removeImage() {
      this.revokePreview()
      this.form.image = ''
    },
    beforeUpload(file) {
      const isImage = file.type.startsWith('image/')
      const isLt10M = file.size / 1024 / 1024 < 10
      if (!isImage) {
        ElMessage.error('只能上传图片文件')
        return false
      }
      if (!isLt10M) {
        ElMessage.error('图片大小不能超过 10MB')
        return false
      }
      return true
    },
    async customUpload(options) {
      this.uploading = true
      try {
        const res = await uploadFile(options.file, 'room-types')
        if (res.code === 200) {
          this.revokePreview()
          this.form.image = res.data.url
          ElMessage.success('图片上传成功')
        } else {
          ElMessage.error(res.message || '上传失败')
        }
      } catch (e) {
        ElMessage.error('上传失败，请检查网络')
      } finally {
        this.uploading = false
      }
    },
    async handleSubmit() {
      this.$refs.formRef.validate(async (valid) => {
        if (valid) {
          this.submitting = true
          const data = {
            typeName: this.form.typeName,
            description: this.form.description,
            basePrice: this.form.basePrice,
            maxOccupancy: this.form.maxOccupancy,
            storeId: this.form.storeId,
            image: this.form.image
          }
          if (this.form.typeId) {
            data.typeId = this.form.typeId
          }
          const res = this.form.typeId ? await updateRoomType(data) : await addRoomType(data)
          this.submitting = false
          if (res.code === 200) {
            ElMessage.success('操作成功')
            this.dialogVisible = false
            this.loadData()
          }
        }
      })
    },
    async handleDelete(id) {
      await ElMessageBox.confirm('确定要删除该房型吗？', '提示', { type: 'warning' })
      const res = await deleteRoomType(id)
      if (res.code === 200) {
        ElMessage.success('删除成功')
        this.loadData()
      }
    }
  }
}
</script>

<style scoped>
.card-header { display: flex; justify-content: space-between; align-items: center; }
.store-upload { cursor: pointer; }
.store-upload .el-upload {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  width: 120px;
  height: 80px;
  display: flex;
  align-items: center;
  justify-content: center;
}
.store-upload .el-upload:hover {
  border-color: #409eff;
}
.upload-preview {
  width: 120px;
  height: 80px;
  object-fit: cover;
  border-radius: 6px;
}
.upload-icon {
  font-size: 28px;
  color: #8c939d;
}
</style>
