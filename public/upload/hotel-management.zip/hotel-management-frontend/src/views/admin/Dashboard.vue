<template>
  <div class="dashboard hm-card-panel">
    <el-row :gutter="20">
      <el-col :span="6">
        <el-card class="stat-card">
          <div class="stat-icon stat-total">
            <el-icon size="30"><House /></el-icon>
          </div>
          <div class="stat-info">
            <div class="stat-value">{{ stats.totalRooms }}</div>
            <div class="stat-label">总房间数</div>
          </div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card class="stat-card">
          <div class="stat-icon stat-free">
            <el-icon size="30"><CircleCheck /></el-icon>
          </div>
          <div class="stat-info">
            <div class="stat-value">{{ stats.availableRooms }}</div>
            <div class="stat-label">可售房间</div>
          </div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card class="stat-card">
          <div class="stat-icon stat-in">
            <el-icon size="30"><User /></el-icon>
          </div>
          <div class="stat-info">
            <div class="stat-value">{{ stats.checkinRooms }}</div>
            <div class="stat-label">已入住</div>
          </div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card class="stat-card">
          <div class="stat-icon stat-ops">
            <el-icon size="30"><Warning /></el-icon>
          </div>
          <div class="stat-info">
            <div class="stat-value">{{ stats.maintenanceRooms }}</div>
            <div class="stat-label">维修/清扫中</div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <el-row :gutter="20" style="margin-top: 20px;">
      <el-col :span="16">
        <el-card>
          <template #header>
            <span>集团房态一览</span>
          </template>
          <div class="room-grid">
            <div
              v-for="room in rooms"
              :key="room.roomId"
              class="room-item"
              :class="getStatusClass(room.status)"
            >
              <div class="room-number">{{ room.roomNumber }}</div>
              <div class="room-status-icon">
                <el-tooltip :content="room.status" placement="top">
                  <el-icon size="20">
                    <CircleCheck v-if="room.status === '可售'" />
                    <User v-else-if="room.status === '已入住'" />
                    <Brush v-else-if="room.status === '清扫中'" />
                    <Tools v-else-if="room.status === '维修中'" />
                    <House v-else />
                  </el-icon>
                </el-tooltip>
              </div>
            </div>
          </div>
        </el-card>
      </el-col>
      <el-col :span="8">
        <el-card>
          <template #header>
            <span>在住客人动态</span>
          </template>
          <el-table :data="recentCheckins" style="width: 100%">
            <el-table-column prop="guestName" label="客人" />
            <el-table-column prop="roomNumber" label="房间号" />
            <el-table-column prop="checkinTime" label="入住时间" width="150" />
          </el-table>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import { getRooms, getRoomsByStore, getActiveCheckins } from '../../api'
import { getUser } from '../../utils/authStorage'

export default {
  name: 'Dashboard',
  data() {
    return {
      stats: {
        totalRooms: 0,
        availableRooms: 0,
        checkinRooms: 0,
        maintenanceRooms: 0
      },
      rooms: [],
      recentCheckins: []
    }
  },
  mounted() {
    this.loadData()
  },
  methods: {
    async loadData() {
      try {
        const storeId = getUser()?.storeId ?? null

        let roomsRes
        if (storeId) {
          roomsRes = await getRoomsByStore(storeId)
        } else {
          roomsRes = await getRooms()
        }
        
        if (roomsRes.code === 200) {
          this.rooms = roomsRes.data
          this.stats.totalRooms = roomsRes.data.length
          this.stats.availableRooms = roomsRes.data.filter(r => r.status === '可售').length
          this.stats.checkinRooms = roomsRes.data.filter(r => r.status === '已入住').length
          this.stats.maintenanceRooms = roomsRes.data.filter(r => r.status === '清扫中' || r.status === '维修中').length
        }

        const checkinsRes = await getActiveCheckins()
        if (checkinsRes.code === 200) {
          let allCheckins = checkinsRes.data
          if (storeId) {
            allCheckins = allCheckins.filter(c => c.storeId === storeId)
          }
          this.recentCheckins = allCheckins.slice(0, 5)
        }
      } catch (error) {
        console.error(error)
      }
    },
    getStatusIcon(status) {
      const iconMap = {
        '可售': 'CircleCheck',
        '已入住': 'User',
        '清扫中': 'Brush',
        '维修中': 'Tools'
      }
      return iconMap[status] || 'House'
    },
    getStatusClass(status) {
      const classMap = {
        '可售': 'status-available',
        '已入住': 'status-occupied',
        '清扫中': 'status-cleaning',
        '维修中': 'status-maintenance'
      }
      return classMap[status] || ''
    }
  }
}
</script>

<style scoped>
.dashboard {
  padding: 0;
}

.stat-card {
  display: flex;
  align-items: center;
  padding: 20px;
}

.stat-icon {
  width: 60px;
  height: 60px;
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  margin-right: 15px;
}

.stat-total {
  background: linear-gradient(135deg, #1a3a52 0%, #2d5a7b 100%);
}

.stat-free {
  background: linear-gradient(135deg, #2d6a4f 0%, #3d8b6a 100%);
}

.stat-in {
  background: linear-gradient(135deg, #3d5a73 0%, #5a7a94 100%);
}

.stat-ops {
  background: linear-gradient(135deg, #8b4a4a 0%, #a94442 100%);
}

.stat-info {
  flex: 1;
  text-align: center;
}

.stat-value {
  font-size: 32px;
  font-weight: bold;
  color: #333;
}

.stat-label {
  font-size: 14px;
  color: #999;
  margin-top: 5px;
}

.room-grid {
  display: grid;
  grid-template-columns: repeat(5, 1fr);
  gap: 10px;
}

.room-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 15px 10px;
  border-radius: 8px;
  transition: all 0.3s;
}

.room-number {
  font-size: 16px;
  font-weight: bold;
  color: #333;
  margin-bottom: 8px;
}

.room-status-icon {
  display: flex;
  align-items: center;
  justify-content: center;
}

.status-available {
  background-color: #f0f9eb;
  border: 1px solid #e1f3d8;
}
.status-available .room-status-icon {
  color: #67c23a;
}

.status-occupied {
  background-color: #e8eef4;
  border: 1px solid #c5d3e0;
}
.status-occupied .room-status-icon {
  color: #3d5a73;
}

.status-cleaning {
  background-color: #f4f4f5;
  border: 1px solid #e9e9eb;
}
.status-cleaning .room-status-icon {
  color: #909399;
}

.status-maintenance {
  background-color: #fef0f0;
  border: 1px solid #fde2e2;
}
.status-maintenance .room-status-icon {
  color: #f56c6c;
}
</style>
