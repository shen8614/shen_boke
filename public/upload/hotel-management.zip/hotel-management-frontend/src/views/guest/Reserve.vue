<template>
  <div class="reserve-container">
    <div class="reserve-header">
      <h2>官方渠道预订</h2>
      <p class="subtitle">酒店客房管理系统，选择城市门店与房型，价格与房态与前台实时同步</p>
    </div>

    <el-card class="search-card" shadow="hover">
      <div class="search-form">
        <div class="search-item">
          <label>入住日期</label>
          <el-date-picker
            v-model="searchDates.checkin"
            type="date"
            value-format="YYYY-MM-DD"
            format="YYYY-MM-DD"
            placeholder="选择入住日期"
            :disabled-date="disabledCheckinDate"
            @change="handleDateChange"
          />
        </div>
        <div class="search-item">
          <label>离店日期</label>
          <el-date-picker
            v-model="searchDates.checkout"
            type="date"
            value-format="YYYY-MM-DD"
            format="YYYY-MM-DD"
            placeholder="选择离店日期"
            :disabled-date="disabledCheckoutDate"
            @change="handleDateChange"
          />
        </div>
        <div class="search-item">
          <label>入住人数</label>
          <el-select v-model="searchDates.guestCount" placeholder="请选择">
            <el-option v-for="n in 10" :key="n" :label="n + '人'" :value="n" />
          </el-select>
        </div>
        <el-button type="primary" class="search-btn" @click="searchRooms">
          <el-icon><Search /></el-icon>
          搜索酒店
        </el-button>
      </div>
      <div class="search-info" v-if="nights > 0">
        <span class="nights-tag">共 <strong>{{ nights }}</strong> 晚</span>
      </div>
    </el-card>

    <div class="hotel-section" v-if="!selectedStore">
      <h3 class="section-title">
        <el-icon><OfficeBuilding /></el-icon>
        选择酒店
      </h3>
      <div class="hotel-list">
        <div
          v-for="store in stores"
          :key="store.storeId"
          class="hotel-card"
          @click="selectStore(store)"
        >
          <div class="hotel-image">
            <img
              v-if="store.image"
              :src="store.image"
              :alt="`${store.storeName}门店`"
              loading="lazy"
              decoding="async"
            />
            <div v-else class="hotel-image-fallback">
              <el-icon><OfficeBuilding /></el-icon>
              <span>{{ store.storeName.substring(0, 1) }}</span>
            </div>
            <div class="hotel-badge">直营</div>
          </div>
          <div class="hotel-info">
            <h4 class="hotel-name">{{ store.storeName }}</h4>
            <p class="hotel-address">
              <el-icon><Location /></el-icon>
              {{ store.address }}
            </p>
            <p class="hotel-desc">{{ store.description }}</p>
            <div class="hotel-stats">
              <span><el-icon><House /></el-icon> {{ getRoomCountByStore(store.storeId) }} 间客房</span>
              <span><el-icon><Star /></el-icon> 4.8 分</span>
            </div>
            <div class="hotel-price">
              <span class="price-label">起价</span>
              <span class="price-value">¥{{ getMinPrice(store.storeId) }}</span>
              <span class="price-unit">/晚</span>
            </div>
          </div>
          <div class="hotel-action">
            <el-button type="primary" round>
              查看详情 <el-icon><ArrowRight /></el-icon>
            </el-button>
          </div>
        </div>
      </div>
    </div>

    <div class="back-store" v-if="selectedStore">
      <el-button @click="selectedStore = null" text>
        <el-icon><ArrowLeft /></el-icon>
        返回酒店列表
      </el-button>
    </div>

    <div class="store-detail" v-if="selectedStore">
      <div class="store-header">
        <div class="store-main-info">
          <h2>{{ selectedStore.storeName }}</h2>
          <p class="store-address">
            <el-icon><Location /></el-icon>
            {{ selectedStore.address }}
          </p>
          <p class="store-desc">{{ selectedStore.description }}</p>
        </div>
        <div class="store-rating">
          <div class="rating-score">4.8</div>
          <div class="rating-text"> excellent </div>
        </div>
      </div>

      <div class="store-facilities">
        <div class="facility-item">
          <el-icon><Wifi /></el-icon>
          <span>免费WiFi</span>
        </div>
        <div class="facility-item">
          <el-icon><Coffee /></el-icon>
          <span>免费早餐</span>
        </div>
        <div class="facility-item">
          <el-icon><Car /></el-icon>
          <span>免费停车</span>
        </div>
        <div class="facility-item">
          <el-icon><Service /></el-icon>
          <span>24小时前台</span>
        </div>
      </div>

      <h3 class="section-title">
        <el-icon><House /></el-icon>
        选择房型
      </h3>
      <div class="room-type-list">
        <div
          v-for="type in filteredRoomTypes"
          :key="type.typeId"
          class="room-type-card"
          :class="{ active: form.typeId === type.typeId, unavailable: !isRoomAvailable(type) }"
          @click="isRoomAvailable(type) && (form.typeId = type.typeId)"
        >
          <div class="room-type-image">
            <img
              v-if="type.image"
              :src="type.image"
              :alt="`${type.typeName}房型`"
              loading="lazy"
              decoding="async"
            />
            <div v-else class="room-image-fallback">
              <el-icon><House /></el-icon>
            </div>
            <div class="room-tag" v-if="isRoomAvailable(type)">可预订</div>
            <div class="room-tag unavailable" v-else>已满房</div>
          </div>
          <div class="room-type-content">
            <div class="room-type-header">
              <h4>{{ type.typeName }}</h4>
              <div class="room-capacity">
                <el-icon><User /></el-icon>
                可住{{ type.maxOccupancy }}人
              </div>
            </div>
            <p class="room-type-desc">{{ type.description }}</p>
            <div class="room-facilities">
              <span v-for="(facility, idx) in getRoomFacilities(type)" :key="idx">
                {{ facility }}
              </span>
            </div>
            <div class="room-type-footer">
              <div class="room-price">
                <span class="price-amount">¥{{ type.basePrice }}</span>
                <span class="price-unit">/晚</span>
                <span class="price-nights" v-if="nights > 0">×{{ nights }}晚</span>
              </div>
              <el-button
                :type="form.typeId === type.typeId ? 'primary' : 'default'"
                size="small"
                :disabled="!isRoomAvailable(type)"
                @click.stop="form.typeId = type.typeId"
              >
                {{ form.typeId === type.typeId ? '已选择' : '选择' }}
              </el-button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <el-card class="booking-form" v-if="selectedStore && form.typeId" shadow="never">
      <template #header>
        <span class="form-header">
          <el-icon><Calendar /></el-icon>
          填写预订信息
        </span>
      </template>
      <el-form :model="form" :rules="rules" ref="formRef" label-width="100px">
        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item label="入住日期">
              <el-input :value="searchDates.checkin" disabled />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="离店日期">
              <el-input :value="searchDates.checkout" disabled />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="12">
            <el-form-item label="房间数" prop="roomCount">
              <el-input-number v-model="form.roomCount" :min="1" :max="5" style="width: 100%" />
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="入住人数" prop="actualGuests">
              <el-input-number v-model="form.actualGuests" :min="1" :max="10" style="width: 100%" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-form-item label="特殊要求">
          <el-input v-model="form.notes" type="textarea" rows="3" placeholder="如有特殊需求请备注说明（如加床、婴儿床等）" />
        </el-form-item>

        <div class="price-summary" v-if="nights > 0 && selectedRoomType">
          <div class="summary-row">
            <span>房型</span>
            <span>{{ selectedRoomType.typeName }} × {{ form.roomCount }}间 × {{ nights }}晚</span>
          </div>
          <div class="summary-row">
            <span>房价</span>
            <span>¥{{ selectedRoomType.basePrice }} × {{ nights }}晚</span>
          </div>
          <div class="summary-row total">
            <span>合计</span>
            <span class="total-price">¥{{ totalPrice }}</span>
          </div>
        </div>

        <el-form-item>
          <el-button type="primary" size="large" class="submit-btn" @click="handleSubmit">
            <el-icon><Ticket /></el-icon>
            立即预订
          </el-button>
        </el-form-item>
      </el-form>
    </el-card>

    <el-dialog v-model="detailVisible" title="酒店详情" width="600px" center>
      <div class="store-detail-dialog" v-if="selectedStore">
        <div class="detail-image">
          <img
            v-if="selectedStore.image"
            :src="selectedStore.image"
            :alt="`${selectedStore.storeName}门店`"
            loading="lazy"
            decoding="async"
          />
          <div v-else class="hotel-image-fallback detail-fallback">
            <el-icon><OfficeBuilding /></el-icon>
            <span>{{ selectedStore.storeName.substring(0, 1) }}</span>
          </div>
        </div>
        <el-descriptions :column="1" border>
          <el-descriptions-item label="酒店名称">{{ selectedStore.storeName }}</el-descriptions-item>
          <el-descriptions-item label="酒店地址">{{ selectedStore.address }}</el-descriptions-item>
          <el-descriptions-item label="联系电话">{{ selectedStore.phone }}</el-descriptions-item>
          <el-descriptions-item label="酒店简介">{{ selectedStore.description }}</el-descriptions-item>
          <el-descriptions-item label="客房数量">{{ getRoomCountByStore(selectedStore.storeId) }} 间</el-descriptions-item>
          <el-descriptions-item label="最低价格">¥{{ getMinPrice(selectedStore.storeId) }}/晚起</el-descriptions-item>
        </el-descriptions>
      </div>
      <template #footer>
        <el-button @click="detailVisible = false">关闭</el-button>
        <el-button type="primary" @click="viewRooms">查看房型</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script>
import { getStores, getRoomTypes, getRooms, addReservation, getGuests } from '../../api'
import { getUser } from '../../utils/authStorage'
import { ElMessage } from 'element-plus'

export default {
  data() {
    return {
      stores: [],
      roomTypes: [],
      rooms: [],
      selectedStore: null,
      detailVisible: false,
      searchDates: {
        checkin: '',
        checkout: '',
        guestCount: 1
      },
      form: { typeId: null, roomCount: 1, actualGuests: 1, notes: '' },
      rules: {
        typeId: [{ required: true, message: '请选择房型', trigger: 'change' }],
        roomCount: [{ required: true, message: '请选择房间数', trigger: 'change' }],
        actualGuests: [{ required: true, message: '请选择入住人数', trigger: 'change' }]
      }
    }
  },
  computed: {
    nights() {
      if (!this.searchDates.checkin || !this.searchDates.checkout) return 0
      const checkin = new Date(this.searchDates.checkin)
      const checkout = new Date(this.searchDates.checkout)
      const diffTime = checkout - checkin
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
      return diffDays > 0 ? diffDays : 0
    },
    filteredRoomTypes() {
      if (!this.selectedStore) return []
      return this.roomTypes.filter(rt => rt.storeId === this.selectedStore.storeId)
    },
    selectedRoomType() {
      if (!this.form.typeId) return null
      return this.roomTypes.find(rt => rt.typeId === this.form.typeId)
    },
    totalPrice() {
      if (!this.selectedRoomType || this.nights <= 0) return 0
      return this.selectedRoomType.basePrice * this.form.roomCount * this.nights
    }
  },
  mounted() {
    this.loadData()
  },
  methods: {
    async loadData() {
      const [storesRes, roomTypesRes, roomsRes] = await Promise.all([getStores(), getRoomTypes(), getRooms()])
      if (storesRes.code === 200) this.stores = storesRes.data
      if (roomTypesRes.code === 200) this.roomTypes = roomTypesRes.data
      if (roomsRes.code === 200) this.rooms = roomsRes.data
    },
    getRoomCountByStore(storeId) {
      return this.rooms.filter(r => r.storeId === storeId).length
    },
    getMinPrice(storeId) {
      const storeRoomTypes = this.roomTypes.filter(rt => rt.storeId === storeId)
      if (storeRoomTypes.length === 0) return 0
      return Math.min(...storeRoomTypes.map(rt => rt.basePrice))
    },
    isRoomAvailable(type) {
      const storeRooms = this.rooms.filter(r => r.typeId === type.typeId && r.storeId === this.selectedStore?.storeId)
      const availableRooms = storeRooms.filter(r => r.status === '可售')
      return availableRooms.length > 0
    },
    getRoomFacilities(type) {
      const facilitiesMap = {
        1: ['WiFi', '空调', '电视', '独立卫浴'],
        2: ['WiFi', '空调', '电视', '独立卫浴', '迷你吧'],
        3: ['WiFi', '空调', '电视', '独立卫浴', '迷你吧', '办公桌'],
        4: ['WiFi', '空调', '电视', '独立卫浴', '迷你吧', '多卧室'],
        5: ['WiFi', '空调', '电视', '独立卫浴', '迷你吧', '豪华装修', '专属管家'],
        6: ['WiFi', '空调', '电视', '独立卫浴', '海景'],
        7: ['WiFi', '空调', '电视', '独立卫浴', '迷你吧', '海景'],
        8: ['WiFi', '空调', '电视', '独立卫浴', '迷你吧', '办公桌', '海景']
      }
      return facilitiesMap[type.typeId] || ['WiFi', '空调', '电视', '独立卫浴']
    },
    selectStore(store) {
      this.selectedStore = store
      this.detailVisible = false
    },
    viewRooms() {
      this.detailVisible = false
    },
    disabledCheckinDate(time) {
      return time.getTime() < Date.now() - 86400000
    },
    disabledCheckoutDate(time) {
      if (!this.searchDates.checkin) return time.getTime() < Date.now() - 86400000
      const checkinDate = new Date(this.searchDates.checkin)
      checkinDate.setHours(0, 0, 0, 0)
      return time.getTime() <= checkinDate.getTime()
    },
    handleDateChange() {
      if (this.searchDates.checkin && this.searchDates.checkout) {
        const checkin = new Date(this.searchDates.checkin)
        const checkout = new Date(this.searchDates.checkout)
        if (checkout <= checkin) {
          const nextDay = new Date(checkin)
          nextDay.setDate(nextDay.getDate() + 1)
          this.searchDates.checkout = nextDay.toISOString().split('T')[0]
        }
      }
    },
    searchRooms() {
      if (!this.searchDates.checkin) {
        ElMessage.warning('请选择入住日期')
        return
      }
      if (!this.searchDates.checkout) {
        ElMessage.warning('请选择离店日期')
        return
      }
      if (this.nights <= 0) {
        ElMessage.warning('离店日期必须晚于入住日期')
        return
      }
      ElMessage.success('已找到符合条件的酒店和房型')
    },
    async handleSubmit() {
      this.$refs.formRef.validate(async (valid) => {
        if (valid) {
          const user = getUser()
          if (!user?.id) {
            ElMessage.error('请先登录')
            return
          }
          const guestsRes = await getGuests()
          let guestId = user.id
          if (guestsRes.code === 200) {
            const guest = guestsRes.data.find(g => g.phone === user.username)
            if (guest) guestId = guest.guestId
          }

          const res = await addReservation({
            guestId,
            typeId: this.form.typeId,
            checkinDate: this.searchDates.checkin,
            checkoutDate: this.searchDates.checkout,
            roomCount: this.form.roomCount,
            actualGuests: this.searchDates.guestCount || this.form.actualGuests,
            status: '待确认',
            deposit: 0,
            notes: this.form.notes
          })

          if (res.code === 200) {
            ElMessage.success('预订成功！请等待酒店确认')
            this.$refs.formRef.resetFields()
            this.form.typeId = null
          }
        }
      })
    }
  }
}
</script>

<style scoped>
.reserve-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}

.reserve-header {
  text-align: center;
  margin-bottom: 30px;
}

.reserve-header h2 {
  font-size: 28px;
  color: #303133;
  margin-bottom: 10px;
}

.subtitle {
  color: #909399;
  font-size: 14px;
}

.search-card {
  margin-bottom: 30px;
  border-radius: 12px;
}

.search-form {
  display: flex;
  gap: 20px;
  align-items: flex-end;
  flex-wrap: wrap;
}

.search-item {
  flex: 1;
  min-width: 180px;
}

.search-item label {
  display: block;
  margin-bottom: 8px;
  color: #606266;
  font-size: 14px;
}

.search-btn {
  height: 40px;
  padding: 0 30px;
  font-size: 16px;
}

.search-info {
  margin-top: 15px;
  padding-top: 15px;
  border-top: 1px dashed #ebeef5;
}

.nights-tag {
  background: linear-gradient(135deg, #1a3a52 0%, #2d5a7b 100%);
  color: #f5f2eb;
  padding: 5px 15px;
  border-radius: 20px;
  font-size: 14px;
  border: 1px solid rgba(201, 169, 98, 0.35);
}

.nights-tag strong {
  font-size: 18px;
  margin: 0 3px;
}

.section-title {
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: 20px;
  color: #303133;
  margin: 30px 0 20px;
}

.hotel-list {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
  gap: 20px;
}

.hotel-card {
  display: flex;
  flex-direction: column;
  background: white;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.08);
  cursor: pointer;
  transition: all 0.3s;
  border: 2px solid transparent;
}

.hotel-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 10px 28px rgba(15, 36, 51, 0.12);
  border-color: #1a3a52;
}

.hotel-image {
  position: relative;
  height: 180px;
  overflow: hidden;
}

.hotel-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform 0.3s;
}

.hotel-card:hover .hotel-image img {
  transform: scale(1.05);
}

.hotel-image-fallback {
  width: 100%;
  height: 100%;
  background: linear-gradient(135deg, #1a3a52 0%, #2d5a7b 50%, #3d7ea6 100%);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 4px;
  color: rgba(245, 242, 235, 0.7);
}

.hotel-image-fallback .el-icon {
  font-size: 36px;
}

.hotel-image-fallback span {
  font-size: 16px;
  font-weight: 700;
  color: #f5f2eb;
  letter-spacing: 0.05em;
}

.detail-fallback {
  border-radius: 8px;
}

.hotel-badge {
  position: absolute;
  top: 15px;
  left: 15px;
  background: rgba(26, 58, 82, 0.92);
  color: #e8d5a8;
  padding: 4px 12px;
  border-radius: 4px;
  font-size: 11px;
  font-weight: 600;
  letter-spacing: 0.08em;
  border: 1px solid rgba(201, 169, 98, 0.4);
}

.hotel-info {
  padding: 20px;
  flex: 1;
}

.hotel-name {
  font-size: 18px;
  color: #303133;
  margin: 0 0 10px;
}

.hotel-address {
  display: flex;
  align-items: center;
  gap: 5px;
  color: #909399;
  font-size: 13px;
  margin: 0 0 8px;
}

.hotel-desc {
  color: #606266;
  font-size: 13px;
  line-height: 1.5;
  margin: 0 0 15px;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.hotel-stats {
  display: flex;
  gap: 20px;
  color: #909399;
  font-size: 13px;
  margin-bottom: 15px;
}

.hotel-stats span {
  display: flex;
  align-items: center;
  gap: 5px;
}

.hotel-price {
  display: flex;
  align-items: baseline;
  gap: 5px;
}

.price-label {
  color: #909399;
  font-size: 12px;
}

.price-value {
  color: #1a3a52;
  font-size: 24px;
  font-weight: bold;
}

.price-unit {
  color: #909399;
  font-size: 12px;
}

.hotel-action {
  padding: 15px 20px;
  border-top: 1px solid #ebeef5;
  text-align: right;
}

.back-store {
  margin-bottom: 20px;
}

.store-detail {
  background: white;
  border-radius: 12px;
  padding: 30px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.08);
}

.store-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 20px;
  padding-bottom: 20px;
  border-bottom: 1px solid #ebeef5;
}

.store-main-info h2 {
  font-size: 24px;
  margin: 0 0 10px;
}

.store-address {
  display: flex;
  align-items: center;
  gap: 5px;
  color: #606266;
  margin: 0 0 10px;
}

.store-desc {
  color: #909399;
  margin: 0;
}

.store-rating {
  text-align: center;
}

.rating-score {
  font-size: 32px;
  font-weight: bold;
  color: #c9a962;
}

.rating-text {
  color: #909399;
  font-size: 12px;
}

.store-facilities {
  display: flex;
  gap: 30px;
  padding: 20px;
  background: #e8ecf1;
  border-radius: 8px;
  margin-bottom: 30px;
  flex-wrap: wrap;
  border: 1px solid #d5dde6;
}

.facility-item {
  display: flex;
  align-items: center;
  gap: 8px;
  color: #606266;
}

.facility-item .el-icon {
  font-size: 20px;
  color: #1a3a52;
}

.room-type-list {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
  gap: 20px;
}

.room-type-card {
  display: flex;
  background: white;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.08);
  border: 2px solid #ebeef5;
  transition: all 0.3s;
  cursor: pointer;
}

.room-type-card:hover:not(.unavailable) {
  border-color: #1a3a52;
}

.room-type-card.active {
  border-color: #1a3a52;
  background: rgba(26, 58, 82, 0.06);
}

.room-type-card.unavailable {
  opacity: 0.6;
  cursor: not-allowed;
}

.room-type-image {
  position: relative;
  width: 140px;
  min-width: 140px;
  height: 160px;
}

.room-type-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.room-image-fallback {
  width: 100%;
  height: 100%;
  background: linear-gradient(135deg, #1a3a52 0%, #3d7ea6 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  color: rgba(245, 242, 235, 0.5);
  font-size: 40px;
}

.room-tag {
  position: absolute;
  bottom: 8px;
  left: 8px;
  background: rgba(26, 58, 82, 0.92);
  color: #f5f2eb;
  padding: 2px 8px;
  border-radius: 4px;
  font-size: 12px;
}

.room-tag.unavailable {
  background: rgba(245, 108, 108, 0.9);
}

.room-type-content {
  flex: 1;
  padding: 15px;
  display: flex;
  flex-direction: column;
}

.room-type-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8px;
}

.room-type-header h4 {
  margin: 0;
  font-size: 16px;
  color: #303133;
}

.room-capacity {
  display: flex;
  align-items: center;
  gap: 4px;
  color: #909399;
  font-size: 12px;
}

.room-type-desc {
  color: #606266;
  font-size: 13px;
  margin: 0 0 10px;
  line-height: 1.4;
}

.room-facilities {
  display: flex;
  flex-wrap: wrap;
  gap: 5px;
  margin-bottom: 10px;
}

.room-facilities span {
  background: #f0f2f5;
  color: #606266;
  padding: 2px 8px;
  border-radius: 4px;
  font-size: 11px;
}

.room-type-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: auto;
}

.room-price {
  display: flex;
  align-items: baseline;
  gap: 3px;
}

.price-amount {
  color: #1a3a52;
  font-size: 20px;
  font-weight: bold;
}

.price-unit {
  color: #909399;
  font-size: 12px;
}

.price-nights {
  color: #909399;
  font-size: 12px;
  margin-left: 5px;
}

.booking-form {
  margin-top: 30px;
  border-radius: 12px;
}

.form-header {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 18px;
  font-weight: bold;
}

.price-summary {
  background: #e8ecf1;
  border-radius: 8px;
  padding: 20px;
  margin-bottom: 20px;
  border: 1px solid #d5dde6;
}

.summary-row {
  display: flex;
  justify-content: space-between;
  padding: 8px 0;
  color: #606266;
}

.summary-row.total {
  border-top: 1px solid #dcdfe6;
  margin-top: 10px;
  padding-top: 15px;
  font-size: 16px;
  font-weight: bold;
}

.total-price {
  color: #1a3a52;
  font-size: 24px;
}

.submit-btn {
  width: 100%;
  height: 50px;
  font-size: 18px;
}

.store-detail-dialog .detail-image {
  width: 100%;
  height: 250px;
  border-radius: 8px;
  overflow: hidden;
  margin-bottom: 20px;
}

.store-detail-dialog .detail-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
</style>
