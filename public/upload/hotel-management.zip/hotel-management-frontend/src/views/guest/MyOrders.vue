<template>
  <div class="orders-container">
    <el-card>
      <template #header>
        <span>我的订单</span>
      </template>
      <el-table :data="orders" border>
        <el-table-column prop="reservationId" label="订单号" width="80" />
        <el-table-column prop="typeName" label="房型" width="120" />
        <el-table-column prop="roomNumber" label="房间号" width="100">
          <template #default="scope">{{ scope.row.roomNumber || '-' }}</template>
        </el-table-column>
        <el-table-column prop="checkinDate" label="入住日期" width="120" />
        <el-table-column prop="checkoutDate" label="离店日期" width="120" />
        <el-table-column prop="roomCount" label="房间数" width="80" />
        <el-table-column prop="actualGuests" label="入住人数" width="100" />
        <el-table-column prop="status" label="状态" width="100">
          <template #default="scope">
            <el-tag :type="getStatusType(scope.row.status)">{{ scope.row.status }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="notes" label="备注" />
        <el-table-column label="操作" width="120" fixed="right">
          <template #default="scope">
            <el-button
              v-if="scope.row.status === '待确认'"
              type="danger"
              size="small"
              @click="handleCancel(scope.row)"
            >
              取消预订
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script>
import { getReservationsByGuest, updateReservationStatus } from '../../api'
import { getUser } from '../../utils/authStorage'
import { ElMessage, ElMessageBox } from 'element-plus'

export default {
  name: 'MyOrders',
  data() {
    return {
      orders: []
    }
  },
  mounted() {
    this.loadOrders()
  },
  methods: {
    async loadOrders() {
      const user = getUser()
      if (!user?.id) return
      const res = await getReservationsByGuest(user.id)
      if (res.code === 200) this.orders = res.data
    },
    getStatusType(status) {
      const map = { '待确认': 'info', '已确认': 'success', '已入住': 'warning', '已取消': 'danger', '已完成': '' }
      return map[status] || ''
    },
    async handleCancel(row) {
      try {
        await ElMessageBox.confirm('确定要取消此预订吗？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        })
        const res = await updateReservationStatus(row.reservationId, '已取消')
        if (res.code === 200) {
          ElMessage.success('预订已取消')
          this.loadOrders()
        }
      } catch {
      }
    }
  }
}
</script>
