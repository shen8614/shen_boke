<template>
  <el-container class="layout-container hm-layout">
    <el-aside width="220px">
      <div class="hm-logo">
        <div class="hm-logo-row">
          <img class="hm-logo-icon" src="/images/brand-mark.svg" width="36" height="36" alt="" />
          <div class="hm-logo-texts">
            <span class="brand-cn">酒店客房管理</span>
            <span class="brand-en">Hotel Room Mgmt</span>
          </div>
        </div>
        <span class="brand-tag">官方预订 · 会员服务</span>
      </div>
      <el-menu
        :default-active="$route.path"
        router
        text-color="rgba(255,255,255,0.82)"
        active-text-color="#d4c4a0"
      >
        <el-menu-item index="/guest/reserve">
          <el-icon><Calendar /></el-icon>
          <span>在线预订</span>
        </el-menu-item>
        <el-menu-item index="/guest/my-orders">
          <el-icon><List /></el-icon>
          <span>我的订单</span>
        </el-menu-item>
        <el-menu-item index="/guest/profile">
          <el-icon><User /></el-icon>
          <span>个人信息</span>
        </el-menu-item>
      </el-menu>
    </el-aside>
    <el-container>
      <el-header class="hm-header">
        <div class="hm-header-left">
          <span class="hm-portal-name">宾客自助服务</span>
          <span class="hm-portal-desc">直连集团库存 · 订单可追踪</span>
        </div>
        <div class="hm-header-right">
          <span class="hm-user-pill">{{ user.name }}</span>
          <el-button class="hm-logout" size="small" @click="handleLogout">退出登录</el-button>
        </div>
      </el-header>
      <el-main class="hm-main hm-card-panel">
        <router-view />
      </el-main>
    </el-container>
  </el-container>
</template>

<script>
import { getUser, clearAuth } from '../../utils/authStorage'

export default {
  name: 'Layout',
  data() {
    return {
      user: {}
    }
  },
  mounted() {
    const u = getUser()
    if (u) this.user = u
  },
  methods: {
    handleLogout() {
      clearAuth()
      this.$router.push('/login')
    }
  }
}
</script>

<style scoped>
.layout-container {
  height: 100vh;
}
</style>
