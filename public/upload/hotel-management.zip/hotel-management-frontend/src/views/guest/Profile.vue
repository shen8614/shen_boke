<template>
  <div class="profile-container">
    <el-card>
      <template #header>
        <span>个人信息</span>
      </template>
      <el-form :model="form" :rules="rules" ref="formRef" label-width="100px">
        <el-form-item label="姓名" prop="name">
          <el-input v-model="form.name" />
        </el-form-item>
        <el-form-item label="手机号" prop="phone">
          <el-input v-model="form.phone" disabled />
        </el-form-item>
        <el-form-item label="证件类型" prop="idType">
          <el-select v-model="form.idType">
            <el-option label="身份证" value="身份证" />
            <el-option label="护照" value="护照" />
            <el-option label="军官证" value="军官证" />
          </el-select>
        </el-form-item>
        <el-form-item label="证件号码" prop="idNumber">
          <el-input v-model="form.idNumber" />
        </el-form-item>
        <el-form-item label="邮箱" prop="email">
          <el-input v-model="form.email" />
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="handleSubmit">保存修改</el-button>
        </el-form-item>
      </el-form>
    </el-card>
  </div>
</template>

<script>
import { getGuests, updateGuest } from '../../api'
import { getUser } from '../../utils/authStorage'
import { ElMessage } from 'element-plus'

export default {
  name: 'Profile',
  data() {
    return {
      form: { guestId: null, name: '', phone: '', idType: '身份证', idNumber: '', email: '' },
      rules: {
        name: [{ required: true, message: '请输入姓名', trigger: 'blur' }],
        idType: [{ required: true, message: '请选择证件类型', trigger: 'change' }],
        idNumber: [{ required: true, message: '请输入证件号码', trigger: 'blur' }]
      }
    }
  },
  mounted() {
    this.loadProfile()
  },
  methods: {
    async loadProfile() {
      const user = getUser()
      if (!user?.username) return
      const res = await getGuests()
      if (res.code === 200) {
        const guest = res.data.find(g => g.phone === user.username)
        if (guest) {
          this.form = { ...guest }
        }
      }
    },
    async handleSubmit() {
      this.$refs.formRef.validate(async (valid) => {
        if (valid) {
          const res = await updateGuest(this.form)
          if (res.code === 200) {
            ElMessage.success('保存成功')
          }
        }
      })
    }
  }
}
</script>

<style scoped>
:deep(.el-select) { width: 100%; }
</style>
