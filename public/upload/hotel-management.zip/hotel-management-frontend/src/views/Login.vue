<template>
  <div class="login-page">
    <div class="login-brand">
      <div class="brand-photo" aria-hidden="true"></div>
      <div class="brand-inner">
        <div class="brand-mark">
          <img src="/images/brand-mark.svg" width="40" height="40" alt="" />
        </div>
        <h1 class="brand-title">酒店客房管理系统</h1>
        <p class="brand-sub">Hotel Room Management System</p>
        <ul class="brand-points">
          <li>多门店房态与库存集中管理</li>
          <li>预订、入住、收银全流程可追溯</li>
          <li>集团标准与单店执行同一套系统</li>
        </ul>
      </div>
      <footer class="brand-foot">
        <span>© 连锁酒店内部系统 · 请使用授权账号登录</span>
        <span class="photo-credit">题图来源 Unsplash</span>
      </footer>
    </div>

    <div class="login-panel">
      <div class="login-box">
        <div class="login-box-accent" aria-hidden="true">
          <img src="/images/login-hero.jpg" alt="" class="login-box-accent-img" />
        </div>
        <div class="login-header">
          <h2>账号登录</h2>
          <p>集团员工使用工号登录，宾客请使用注册手机号</p>
        </div>
        <el-form :model="loginForm" :rules="rules" ref="formRef" class="login-form">
          <el-form-item prop="userType">
            <el-radio-group v-model="loginForm.userType" class="type-tabs">
              <el-radio-button label="staff">员工通道</el-radio-button>
              <el-radio-button label="guest">宾客通道</el-radio-button>
            </el-radio-group>
          </el-form-item>
          <el-form-item prop="username">
            <el-input v-model="loginForm.username" placeholder="用户名 / 手机号" size="large" clearable>
              <template #prefix>
                <el-icon><User /></el-icon>
              </template>
            </el-input>
          </el-form-item>
          <el-form-item prop="password">
            <el-input
              v-model="loginForm.password"
              type="password"
              placeholder="密码"
              size="large"
              show-password
              @keyup.enter="handleLogin"
            >
              <template #prefix>
                <el-icon><Lock /></el-icon>
              </template>
            </el-input>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" class="login-button" size="large" @click="handleLogin" :loading="loading">
              进入系统
            </el-button>
          </el-form-item>
          <div class="login-footer" v-if="loginForm.userType === 'guest'">
            <el-link type="primary" :underline="false" @click="showRegister = true">还没有账号？注册为集团宾客会员</el-link>
          </div>
        </el-form>
      </div>
    </div>

    <el-dialog v-model="showRegister" title="宾客注册" width="440px" class="register-dialog" destroy-on-close>
      <el-form :model="registerForm" :rules="registerRules" ref="registerFormRef" label-width="88px">
        <el-form-item label="姓名" prop="name">
          <el-input v-model="registerForm.name" placeholder="与证件一致" />
        </el-form-item>
        <el-form-item label="手机号" prop="phone">
          <el-input v-model="registerForm.phone" placeholder="作为登录账号" maxlength="11" />
        </el-form-item>
        <el-form-item label="密码" prop="password">
          <el-input v-model="registerForm.password" type="password" placeholder="请设置登录密码" show-password />
        </el-form-item>
        <el-form-item label="证件类型" prop="idType">
          <el-select v-model="registerForm.idType" placeholder="请选择" style="width: 100%">
            <el-option label="身份证" value="身份证" />
            <el-option label="护照" value="护照" />
            <el-option label="军官证" value="军官证" />
          </el-select>
        </el-form-item>
        <el-form-item label="证件号" prop="idNumber">
          <el-input v-model="registerForm.idNumber" placeholder="请输入证件号码" />
        </el-form-item>
        <el-form-item label="邮箱" prop="email">
          <el-input v-model="registerForm.email" placeholder="选填，用于接收订单通知" />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="showRegister = false">取消</el-button>
        <el-button type="primary" @click="handleRegister" :loading="registerLoading">提交注册</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script>
import { login, registerGuest } from '../api'
import { setAuth } from '../utils/authStorage'
import { ElMessage } from 'element-plus'

export default {
  name: 'Login',
  data() {
    return {
      loginForm: {
        userType: 'staff',
        username: '',
        password: ''
      },
      rules: {
        username: [{ required: true, message: '请输入用户名或手机号', trigger: 'blur' }],
        password: [{ required: true, message: '请输入密码', trigger: 'blur' }]
      },
      registerForm: {
        name: '',
        phone: '',
        password: '123456',
        idType: '身份证',
        idNumber: '',
        email: ''
      },
      registerRules: {
        name: [{ required: true, message: '请输入姓名', trigger: 'blur' }],
        phone: [{ required: true, message: '请输入手机号', trigger: 'blur' }],
        password: [{ required: true, message: '请输入密码', trigger: 'blur' }],
        idType: [{ required: true, message: '请选择证件类型', trigger: 'change' }],
        idNumber: [{ required: true, message: '请输入证件号码', trigger: 'blur' }]
      },
      loading: false,
      registerLoading: false,
      showRegister: false
    }
  },
  methods: {
    async handleLogin() {
      this.$refs.formRef.validate(async (valid) => {
        if (valid) {
          this.loading = true
          try {
            const res = await login(this.loginForm)
            if (res.code === 200) {
              setAuth(res.data.token, res.data)
              ElMessage.success('登录成功')
              if (res.data.roleName === '管理员') {
                this.$router.push('/admin')
              } else if (res.data.roleName === '前台') {
                this.$router.push('/reception')
              } else {
                this.$router.push('/guest')
              }
            } else {
              ElMessage.error(res.message)
            }
          } catch (error) {
            ElMessage.error('登录失败')
          } finally {
            this.loading = false
          }
        }
      })
    },
    async handleRegister() {
      this.$refs.registerFormRef.validate(async (valid) => {
        if (valid) {
          this.registerLoading = true
          try {
            const res = await registerGuest(this.registerForm)
            if (res.code === 200) {
              ElMessage.success('注册成功，请登录')
              this.showRegister = false
              this.loginForm.username = this.registerForm.phone
              this.loginForm.password = ''
            } else {
              ElMessage.error(res.message)
            }
          } catch (error) {
            ElMessage.error('注册失败')
          } finally {
            this.registerLoading = false
          }
        }
      })
    }
  }
}
</script>

<style scoped>
.login-page {
  min-height: 100vh;
  display: flex;
  background: var(--hm-page-bg, #e8ecf1);
}

.login-brand {
  flex: 1;
  min-width: 0;
  position: relative;
  background: #0f2230;
  color: #fff;
  display: flex;
  flex-direction: column;
  justify-content: center;
  padding: 48px 56px;
  overflow: hidden;
}

.brand-photo {
  position: absolute;
  inset: 0;
  z-index: 0;
  background: url('/images/login-hero.jpg') center / cover no-repeat;
  transform: scale(1.02);
}

.login-brand::before {
  content: '';
  position: absolute;
  inset: 0;
  z-index: 1;
  pointer-events: none;
  background: linear-gradient(
      105deg,
      rgba(8, 18, 28, 0.92) 0%,
      rgba(15, 36, 51, 0.78) 38%,
      rgba(20, 45, 62, 0.55) 72%,
      rgba(15, 36, 51, 0.35) 100%
    ),
    radial-gradient(circle at 18% 85%, rgba(201, 169, 98, 0.14) 0%, transparent 42%),
    radial-gradient(circle at 92% 12%, rgba(255, 255, 255, 0.05) 0%, transparent 38%);
}

.login-brand::after {
  content: '';
  position: absolute;
  right: 0;
  top: 0;
  bottom: 0;
  z-index: 1;
  width: 1px;
  background: linear-gradient(180deg, transparent, rgba(201, 169, 98, 0.4), transparent);
  pointer-events: none;
}

.brand-inner {
  position: relative;
  z-index: 2;
  max-width: 420px;
}

.brand-mark {
  width: 52px;
  height: 52px;
  border-radius: 12px;
  background: rgba(201, 169, 98, 0.12);
  border: 1px solid rgba(201, 169, 98, 0.4);
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 28px;
}

.brand-mark img {
  display: block;
}

.brand-title {
  font-size: 28px;
  font-weight: 600;
  margin: 0 0 12px;
  letter-spacing: 0.04em;
  line-height: 1.3;
}

.brand-sub {
  margin: 0 0 32px;
  font-size: 14px;
  color: rgba(255, 255, 255, 0.55);
  line-height: 1.6;
}

.brand-points {
  margin: 0;
  padding-left: 18px;
  color: rgba(255, 255, 255, 0.75);
  font-size: 14px;
  line-height: 2;
}

.brand-foot {
  position: absolute;
  bottom: 28px;
  left: 56px;
  right: 56px;
  z-index: 2;
  display: flex;
  flex-direction: column;
  gap: 6px;
  font-size: 12px;
  color: rgba(255, 255, 255, 0.4);
}

.photo-credit {
  font-size: 11px;
  color: rgba(255, 255, 255, 0.28);
}

.login-panel {
  width: min(480px, 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 40px 32px;
  background: #f3f5f8;
}

.login-box {
  width: 100%;
  max-width: 400px;
  padding: 0;
  background: #fff;
  border-radius: 14px;
  box-shadow: var(--hm-shadow-lg, 0 12px 40px rgba(15, 36, 51, 0.12));
  border: 1px solid var(--hm-border, #d5dde6);
  overflow: hidden;
}

.login-box-accent {
  height: 112px;
  overflow: hidden;
  background: #1a3a52;
}

.login-box-accent-img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  object-position: center 42%;
  opacity: 0.95;
}

.login-box .login-form,
.login-box .login-header {
  padding-left: 36px;
  padding-right: 36px;
}

.login-box .login-header {
  padding-top: 28px;
}

.login-box .login-form {
  padding-bottom: 36px;
}

.login-header {
  margin-bottom: 28px;
}

.login-header h2 {
  font-size: 22px;
  font-weight: 600;
  color: var(--hm-text, #1c2938);
  margin: 0 0 8px;
}

.login-header p {
  margin: 0;
  font-size: 13px;
  color: var(--hm-text-muted, #5c6b7a);
  line-height: 1.5;
}

.type-tabs {
  width: 100%;
  display: flex;
}

.type-tabs :deep(.el-radio-button) {
  flex: 1;
}

.type-tabs :deep(.el-radio-button__inner) {
  width: 100%;
}

.login-button {
  width: 100%;
  height: 44px;
  font-size: 15px;
  font-weight: 500;
}

.login-footer {
  text-align: center;
  margin-top: 4px;
}

:deep(.el-input__wrapper) {
  border-radius: 8px;
}

@media (max-width: 900px) {
  .login-page {
    flex-direction: column;
  }

  .login-brand {
    min-height: 260px;
    padding: 28px 24px 32px;
  }

  .login-box-accent {
    height: 96px;
  }

  .brand-foot {
    position: static;
    margin-top: 24px;
    left: auto;
    right: auto;
  }

  .login-panel {
    width: 100%;
    flex: 1;
  }
}
</style>
