/**
 * 使用 sessionStorage：每个浏览器标签页独立会话，避免多标签不同身份登录互相覆盖。
 */
const TOKEN_KEY = 'token'
const USER_KEY = 'user'

export function getToken() {
  return sessionStorage.getItem(TOKEN_KEY)
}

export function setAuth(token, userObj) {
  sessionStorage.setItem(TOKEN_KEY, token)
  sessionStorage.setItem(USER_KEY, JSON.stringify(userObj))
}

export function clearAuth() {
  sessionStorage.removeItem(TOKEN_KEY)
  sessionStorage.removeItem(USER_KEY)
}

/** @returns {string|null} */
export function getUserRaw() {
  return sessionStorage.getItem(USER_KEY)
}

/** @returns {object|null} */
export function getUser() {
  const s = sessionStorage.getItem(USER_KEY)
  if (!s) return null
  try {
    return JSON.parse(s)
  } catch {
    return null
  }
}
