import axios from 'axios'
import { getToken, clearAuth } from '../utils/authStorage'

const api = axios.create({
  baseURL: '/api',
  timeout: 10000
})

api.interceptors.request.use(
  config => {
    const token = getToken()
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  error => {
    return Promise.reject(error)
  }
)

api.interceptors.response.use(
  response => {
    return response.data
  },
  error => {
    if (error.response && error.response.status === 401) {
      clearAuth()
      window.location.href = '/login'
    }
    return Promise.reject(error)
  }
)

export default api

export const login = (data) => api.post('/auth/login', data)
export const registerGuest = (data) => api.post('/auth/guest/register', data)

export const getRooms = () => api.get('/rooms')
export const getRoom = (id) => api.get(`/rooms/${id}`)
export const getRoomsByStore = (storeId) => api.get(`/rooms/store/${storeId}`)
export const getRoomsByStatus = (status) => api.get(`/rooms/status/${status}`)
export const addRoom = (data) => api.post('/rooms', data)
export const updateRoom = (data) => api.put('/rooms', data)
export const deleteRoom = (id) => api.delete(`/rooms/${id}`)
export const updateRoomStatus = (id, status) => api.put(`/rooms/${id}/status?status=${status}`)

export const getRoomTypes = () => api.get('/room-types')
export const getRoomType = (id) => api.get(`/room-types/${id}`)
export const addRoomType = (data) => api.post('/room-types', data)
export const updateRoomType = (data) => api.put('/room-types', data)
export const deleteRoomType = (id) => api.delete(`/room-types/${id}`)

export const getGuests = () => api.get('/guests')
export const getGuest = (id) => api.get(`/guests/${id}`)
export const addGuest = (data) => api.post('/guests', data)
export const updateGuest = (data) => api.put('/guests', data)
export const deleteGuest = (id) => api.delete(`/guests/${id}`)

export const getStaff = () => api.get('/staff')
export const getStaffMember = (id) => api.get(`/staff/${id}`)
export const addStaff = (data) => api.post('/staff', data)
export const updateStaff = (data) => api.put('/staff', data)
export const deleteStaff = (id) => api.delete(`/staff/${id}`)

export const getReservations = () => api.get('/reservations')
export const getReservation = (id) => api.get(`/reservations/${id}`)
export const getReservationsByGuest = (guestId) => api.get(`/reservations/guest/${guestId}`)
export const getReservationsByStatus = (status) => api.get(`/reservations/status/${status}`)
export const addReservation = (data) => api.post('/reservations', data)
export const updateReservation = (data) => api.put('/reservations', data)
export const deleteReservation = (id) => api.delete(`/reservations/${id}`)
export const updateReservationStatus = (id, status) => api.put(`/reservations/${id}/status?status=${status}`)

export const getCheckins = () => api.get('/checkins')
export const getCheckin = (id) => api.get(`/checkins/${id}`)
export const getCheckinsByGuest = (guestId) => api.get(`/checkins/guest/${guestId}`)
export const getActiveCheckins = () => api.get('/checkins/active')
export const addCheckin = (data) => api.post('/checkins', data)
export const updateCheckin = (data) => api.put('/checkins', data)
export const deleteCheckin = (id) => api.delete(`/checkins/${id}`)
export const checkout = (id) => api.put(`/checkins/${id}/checkout`)

export const getBills = () => api.get('/bills')
export const getBill = (id) => api.get(`/bills/${id}`)
export const getBillByCheckin = (checkinId) => api.get(`/bills/checkin/${checkinId}`)
export const addBill = (data) => api.post('/bills', data)
export const updateBill = (data) => api.put('/bills', data)
export const deleteBill = (id) => api.delete(`/bills/${id}`)
export const getMaxInvoiceNumber = () => api.get('/bills/maxInvoiceNumber')

export const getConsumptionItems = () => api.get('/consumption-items')
export const getConsumptionByCheckin = (checkinId) => api.get(`/consumption/checkin/${checkinId}`)
export const getConsumptionTotal = (checkinId) => api.get(`/consumption/checkin/${checkinId}/total`)
export const addConsumption = (data) => api.post('/consumption', data)
export const updateConsumption = (data) => api.put('/consumption', data)
export const deleteConsumption = (id) => api.delete(`/consumption/${id}`)

export const getStores = () => api.get('/stores')
export const getStore = (id) => api.get(`/stores/${id}`)
export const addStore = (data) => api.post('/stores', data)
export const updateStore = (data) => api.put('/stores', data)
export const deleteStore = (id) => api.delete(`/stores/${id}`)

export const uploadFile = (file, folder = 'stores') => {
  const formData = new FormData()
  formData.append('file', file)
  return api.post(`/upload?folder=${folder}`, formData, { timeout: 60000 })
}

/** 管理员 · 营业统计与报表 */
export const getStatisticsOccupancy = (storeId) =>
  api.get('/statistics/occupancy', { params: storeId != null ? { storeId } : {} })
export const getStatisticsOccupancyByStore = () => api.get('/statistics/occupancy-by-store')
export const getStatisticsRevenueAnalysis = (startDate, endDate, storeId) =>
  api.get('/statistics/revenue-analysis', {
    params: {
      startDate,
      endDate,
      ...(storeId != null && storeId !== '' ? { storeId } : {})
    }
  })
export const getStatisticsReportBills = (startDate, endDate, storeId) =>
  api.get('/statistics/report-bills', {
    params: {
      startDate,
      endDate,
      ...(storeId != null && storeId !== '' ? { storeId } : {})
    }
  })
