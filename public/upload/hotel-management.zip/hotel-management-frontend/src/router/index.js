import { createRouter, createWebHistory } from 'vue-router'
import { getUserRaw } from '../utils/authStorage'

const routes = [
  {
    path: '/',
    redirect: '/login'
  },
  {
    path: '/login',
    name: 'Login',
    component: () => import('../views/Login.vue')
  },
  {
    path: '/admin',
    name: 'Admin',
    component: () => import('../views/admin/Layout.vue'),
    children: [
      {
        path: '',
        redirect: '/admin/dashboard'
      },
      {
        path: 'dashboard',
        name: 'Dashboard',
        component: () => import('../views/admin/Dashboard.vue')
      },
      {
        path: 'analytics',
        name: 'Analytics',
        component: () => import('../views/admin/Analytics.vue')
      },
      {
        path: 'rooms',
        name: 'Rooms',
        component: () => import('../views/admin/Rooms.vue')
      },
      {
        path: 'room-types',
        name: 'RoomTypes',
        component: () => import('../views/admin/RoomTypes.vue')
      },
      {
        path: 'staff',
        name: 'Staff',
        component: () => import('../views/admin/Staff.vue')
      },
      {
        path: 'stores',
        name: 'Stores',
        component: () => import('../views/admin/Stores.vue')
      },
      {
        path: 'guests',
        name: 'AdminGuests',
        component: () => import('../views/admin/Guests.vue')
      }
    ]
  },
  {
    path: '/reception',
    name: 'Reception',
    component: () => import('../views/reception/Layout.vue'),
    children: [
      {
        path: '',
        redirect: '/reception/room-status'
      },
      {
        path: 'room-status',
        name: 'RoomStatus',
        component: () => import('../views/reception/RoomStatus.vue')
      },
      {
        path: 'reservations',
        name: 'Reservations',
        component: () => import('../views/reception/Reservations.vue')
      },
      {
        path: 'checkin',
        name: 'Checkin',
        component: () => import('../views/reception/Checkin.vue')
      },
      {
        path: 'checkout',
        name: 'Checkout',
        component: () => import('../views/reception/Checkout.vue')
      },
      {
        path: 'consumption',
        name: 'Consumption',
        component: () => import('../views/reception/Consumption.vue')
      },
      {
        path: 'bills',
        name: 'Bills',
        component: () => import('../views/reception/Bills.vue')
      },
      {
        path: 'guests',
        name: 'Guests',
        component: () => import('../views/reception/Guests.vue')
      }
    ]
  },
  {
    path: '/guest',
    name: 'Guest',
    component: () => import('../views/guest/Layout.vue'),
    children: [
      {
        path: '',
        redirect: '/guest/reserve'
      },
      {
        path: 'reserve',
        name: 'Reserve',
        component: () => import('../views/guest/Reserve.vue')
      },
      {
        path: 'my-orders',
        name: 'MyOrders',
        component: () => import('../views/guest/MyOrders.vue')
      },
      {
        path: 'profile',
        name: 'Profile',
        component: () => import('../views/guest/Profile.vue')
      }
    ]
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

router.beforeEach((to, from, next) => {
  const user = getUserRaw()
  if (!user && to.path !== '/login') {
    next('/login')
  } else if (user && to.path === '/login') {
    const userData = JSON.parse(user)
    if (userData.roleName === '管理员') {
      next('/admin')
    } else if (userData.roleName === '前台') {
      next('/reception')
    } else {
      next('/guest')
    }
  } else {
    next()
  }
})

export default router
