-- 酒店管理系统数据库SQL文件

SET FOREIGN_KEY_CHECKS = 0;

DROP DATABASE IF EXISTS hotel_management;
CREATE DATABASE hotel_management CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE hotel_management;

-- -----------------------------
-- 表结构：门店表 (stores)
-- -----------------------------
CREATE TABLE stores (
  store_id INT PRIMARY KEY AUTO_INCREMENT COMMENT '门店ID',
  store_name VARCHAR(100) NOT NULL COMMENT '门店名称',
  address VARCHAR(255) NOT NULL COMMENT '门店地址',
  phone VARCHAR(20) NOT NULL COMMENT '联系电话',
  description TEXT COMMENT '门店描述',
  image VARCHAR(500) COMMENT '门店图片路径',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='门店信息表';

-- -----------------------------
-- 表结构：客房类型表 (room_types)
-- -----------------------------
CREATE TABLE room_types (
  type_id INT PRIMARY KEY AUTO_INCREMENT COMMENT '客房类型ID',
  type_name VARCHAR(50) NOT NULL COMMENT '客房类型名称',
  description TEXT COMMENT '类型描述',
  base_price DECIMAL(10,2) NOT NULL COMMENT '基础价格',
  max_occupancy INT NOT NULL COMMENT '最大容纳人数',
  store_id INT NOT NULL COMMENT '所属门店ID',
  image VARCHAR(500) COMMENT '房型图片路径',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='客房类型表';

ALTER TABLE room_types ADD FOREIGN KEY (store_id) REFERENCES stores(store_id);

-- -----------------------------
-- 表结构：客房表 (rooms)
-- -----------------------------
CREATE TABLE rooms (
  room_id INT PRIMARY KEY AUTO_INCREMENT COMMENT '房间ID',
  room_number VARCHAR(20) NOT NULL COMMENT '房间号',
  type_id INT NOT NULL COMMENT '客房类型ID',
  floor INT NOT NULL COMMENT '楼层',
  standard_price DECIMAL(10,2) NOT NULL COMMENT '标准价格',
  status ENUM('可售', '已预订', '已入住', '清扫中', '维修中') DEFAULT '可售' COMMENT '当前状态',
  facilities TEXT COMMENT '房间设施描述',
  store_id INT NOT NULL COMMENT '所属门店ID',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  FOREIGN KEY (type_id) REFERENCES room_types(type_id),
  FOREIGN KEY (store_id) REFERENCES stores(store_id),
  UNIQUE KEY uk_store_room (store_id, room_number)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='客房信息表';

-- -----------------------------
-- 表结构：客人表 (guests)
-- -----------------------------
CREATE TABLE guests (
  guest_id INT PRIMARY KEY AUTO_INCREMENT COMMENT '客人ID',
  name VARCHAR(50) NOT NULL COMMENT '姓名',
  id_type ENUM('身份证', '护照', '军官证', '其他') NOT NULL DEFAULT '身份证' COMMENT '证件类型',
  id_number VARCHAR(50) COMMENT '证件号码',
  phone VARCHAR(20) NOT NULL COMMENT '手机号',
  password VARCHAR(100) NOT NULL DEFAULT '123456' COMMENT '登录密码',
  email VARCHAR(100) COMMENT '邮箱',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  UNIQUE KEY uk_phone (phone)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='客人信息表';

-- -----------------------------
-- 表结构：角色表 (roles)
-- -----------------------------
CREATE TABLE roles (
  role_id INT PRIMARY KEY AUTO_INCREMENT COMMENT '角色ID',
  role_name VARCHAR(50) NOT NULL COMMENT '角色名称',
  description TEXT COMMENT '角色描述',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  UNIQUE KEY uk_role_name (role_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='角色表';

-- -----------------------------
-- 表结构：员工表 (staff)
-- -----------------------------
CREATE TABLE staff (
  staff_id INT PRIMARY KEY AUTO_INCREMENT COMMENT '员工ID',
  username VARCHAR(50) NOT NULL COMMENT '用户名',
  password VARCHAR(100) NOT NULL COMMENT '密码',
  name VARCHAR(50) NOT NULL COMMENT '姓名',
  role_id INT NOT NULL COMMENT '角色ID',
  phone VARCHAR(20) NOT NULL COMMENT '联系方式',
  store_id INT COMMENT '所属门店ID',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  FOREIGN KEY (role_id) REFERENCES roles(role_id),
  FOREIGN KEY (store_id) REFERENCES stores(store_id),
  UNIQUE KEY uk_username (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='员工信息表';

-- -----------------------------
-- 表结构：预订表 (reservations)
-- -----------------------------
CREATE TABLE reservations (
  reservation_id INT PRIMARY KEY AUTO_INCREMENT COMMENT '预订ID',
  guest_id INT NOT NULL COMMENT '客人ID',
  room_id INT COMMENT '房间ID（可选）',
  type_id INT NOT NULL COMMENT '预订房型ID',
  checkin_date DATE NOT NULL COMMENT '预订入住日期',
  checkout_date DATE NOT NULL COMMENT '预订离店日期',
  room_count INT NOT NULL DEFAULT 1 COMMENT '预订间数',
  actual_guests INT COMMENT '实际入住人数',
  status ENUM('待确认', '已确认', '已入住', '已取消', '已完成') DEFAULT '待确认' COMMENT '预订状态',
  deposit DECIMAL(10,2) DEFAULT 0 COMMENT '押金',
  notes TEXT COMMENT '备注',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  FOREIGN KEY (guest_id) REFERENCES guests(guest_id),
  FOREIGN KEY (room_id) REFERENCES rooms(room_id),
  FOREIGN KEY (type_id) REFERENCES room_types(type_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='预订信息表';

-- -----------------------------
-- 表结构：入住登记表 (checkins)
-- -----------------------------
CREATE TABLE checkins (
  checkin_id INT PRIMARY KEY AUTO_INCREMENT COMMENT '入住ID',
  reservation_id INT COMMENT '预订ID（外键）',
  guest_id INT NOT NULL COMMENT '客人ID',
  room_id INT NOT NULL COMMENT '房间ID',
  checkin_time DATETIME NOT NULL COMMENT '实际入住时间',
  checkout_time DATETIME COMMENT '实际离店时间',
  status ENUM('入住中', '已退房') DEFAULT '入住中' COMMENT '入住状态',
  staff_id INT NOT NULL COMMENT '登记员工ID',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  FOREIGN KEY (reservation_id) REFERENCES reservations(reservation_id),
  FOREIGN KEY (guest_id) REFERENCES guests(guest_id),
  FOREIGN KEY (room_id) REFERENCES rooms(room_id),
  FOREIGN KEY (staff_id) REFERENCES staff(staff_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='入住登记表';

-- -----------------------------
-- 表结构：消费项目表 (consumption_items)
-- -----------------------------
CREATE TABLE consumption_items (
  item_id INT PRIMARY KEY AUTO_INCREMENT COMMENT '项目ID',
  item_name VARCHAR(100) NOT NULL COMMENT '项目名称',
  price DECIMAL(10,2) NOT NULL COMMENT '项目价格',
  category VARCHAR(50) COMMENT '项目类别',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='消费项目表';

-- -----------------------------
-- 表结构：消费记录表 (consumption)
-- -----------------------------
CREATE TABLE consumption (
  consumption_id INT PRIMARY KEY AUTO_INCREMENT COMMENT '消费记录ID',
  checkin_id INT NOT NULL COMMENT '入住ID',
  item_id INT NOT NULL COMMENT '消费项目ID',
  quantity INT NOT NULL DEFAULT 1 COMMENT '数量',
  amount DECIMAL(10,2) NOT NULL COMMENT '消费金额',
  consumption_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '消费时间',
  FOREIGN KEY (checkin_id) REFERENCES checkins(checkin_id),
  FOREIGN KEY (item_id) REFERENCES consumption_items(item_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='消费记录表';

-- -----------------------------
-- 表结构：账单表 (bills)
-- -----------------------------
CREATE TABLE bills (
  bill_id INT PRIMARY KEY AUTO_INCREMENT COMMENT '账单ID',
  checkin_id INT NOT NULL COMMENT '入住ID',
  room_charge DECIMAL(10,2) NOT NULL COMMENT '房费',
  other_charge DECIMAL(10,2) DEFAULT 0 COMMENT '其他费用',
  total_charge DECIMAL(10,2) NOT NULL COMMENT '总费用',
  deposit DECIMAL(10,2) DEFAULT 0 COMMENT '押金',
  actual_pay DECIMAL(10,2) NOT NULL COMMENT '实际支付',
  payment_method ENUM('现金', '刷卡', '微信', '支付宝') COMMENT '支付方式',
  invoice_status ENUM('未开具', '已开具') DEFAULT '未开具' COMMENT '发票状态',
  invoice_number VARCHAR(50) COMMENT '发票号码',
  checkout_time DATETIME NOT NULL COMMENT '结账时间',
  staff_id INT NOT NULL COMMENT '结账员工ID',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  FOREIGN KEY (checkin_id) REFERENCES checkins(checkin_id),
  FOREIGN KEY (staff_id) REFERENCES staff(staff_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='账单表';

SET FOREIGN_KEY_CHECKS = 1;

-- -----------------------------
-- 插入测试数据
-- -----------------------------

INSERT INTO roles (role_name, description) VALUES
('管理员', '系统管理员，拥有所有权限'),
('前台', '前台工作人员，负责预订、入住、退房等操作'),
('客人', '酒店客人，可在线预订和管理个人信息');

INSERT INTO stores (store_name, address, phone, description, image) VALUES
('阳光大酒店', '北京市朝阳区建国路88号', '010-12345678', '豪华五星级酒店，位于市中心商业区', '/uploads/stores/1.jpg'),
('海景度假酒店', '上海市浦东新区滨海大道123号', '021-87654321', '海景度假酒店，靠近海滩和旅游景点', '/uploads/stores/2.jpg');

INSERT INTO room_types (type_name, description, base_price, max_occupancy, store_id, image) VALUES
('标准间', '舒适单人或双人房，配备基本设施', 388.00, 2, 1, '/uploads/room-types/1.jpg'),
('豪华间', '宽敞舒适，配备豪华设施', 588.00, 2, 1, '/uploads/room-types/2.jpg'),
('行政套房', '商务人士首选，配备办公设施', 888.00, 2, 1, '/uploads/room-types/3.jpg'),
('家庭套房', '适合家庭入住，有多个卧室', 1288.00, 4, 1, '/uploads/room-types/4.jpg'),
('总统套房', '顶级豪华套房，尊享服务', 2888.00, 2, 1, '/uploads/room-types/5.jpg'),
('海景标准间', '舒适单人或双人房，海景视野', 368.00, 2, 2, '/uploads/room-types/6.jpg'),
('海景豪华间', '宽敞舒适，海景豪华设施', 568.00, 2, 2, '/uploads/room-types/7.jpg'),
('海景行政套房', '商务海景套房，配备办公设施', 868.00, 2, 2, '/uploads/room-types/8.jpg');

INSERT INTO rooms (room_number, type_id, floor, standard_price, status, facilities, store_id) VALUES
('101', 1, 1, 388.00, '可售', '空调、电视、独立卫浴、免费WiFi', 1),
('102', 1, 1, 388.00, '可售', '空调、电视、独立卫浴、免费WiFi', 1),
('201', 2, 2, 588.00, '已入住', '空调、电视、独立卫浴、免费WiFi、迷你吧', 1),
('202', 2, 2, 588.00, '可售', '空调、电视、独立卫浴、免费WiFi、迷你吧', 1),
('301', 3, 3, 888.00, '可售', '空调、电视、独立卫浴、免费WiFi、迷你吧、办公桌椅', 1),
('302', 3, 3, 888.00, '清扫中', '空调、电视、独立卫浴、免费WiFi、迷你吧、办公桌椅', 1),
('401', 4, 4, 1288.00, '可售', '空调、电视、独立卫浴、免费WiFi、迷你吧、多个卧室', 1),
('501', 5, 5, 2888.00, '维修中', '空调、电视、独立卫浴、免费WiFi、迷你吧、豪华装修、专属管家', 1),
('A101', 6, 1, 368.00, '可售', '空调、电视、独立卫浴、免费WiFi', 2),
('A102', 6, 1, 368.00, '可售', '空调、电视、独立卫浴、免费WiFi', 2),
('A201', 7, 2, 568.00, '可售', '空调、电视、独立卫浴、免费WiFi、迷你吧', 2),
('A202', 7, 2, 568.00, '已入住', '空调、电视、独立卫浴、免费WiFi、迷你吧', 2);

INSERT INTO guests (name, id_type, id_number, phone, password, email) VALUES
('张三丰', '身份证', '110101199001011234', '13800138001', '123456', 'zhangsan@example.com'),
('李明', '身份证', '110101199002022345', '13900139001', '123456', 'lisi@example.com'),
('王芳', '护照', 'E12345678', '13700137001', '123456', 'wangwu@example.com'),
('赵强', '身份证', '110101199003033456', '13600136001', '123456', 'zhaoliu@example.com'),
('钱静', '军官证', 'J123456', '13500135001', '123456', 'qianqi@example.com'),
('新客户', '身份证', '110101199009999999', '13900999999', '123456', 'newguest@example.com');

INSERT INTO staff (username, password, name, role_id, phone, store_id) VALUES
('admin', '123456', '系统管理员', 1, '13812345678', NULL),
('reception1', '123456', '阳光大堂经理', 2, '13912345678', 1),
('reception2', '123456', '海景前台主管', 2, '13712345678', 2),
('admin2', '123456', '海景经理', 1, '13612345678', NULL);

INSERT INTO reservations (guest_id, room_id, type_id, checkin_date, checkout_date, room_count, actual_guests, status, deposit, notes) VALUES
(1, 3, 2, '2026-04-01', '2026-04-03', 1, 2, '已入住', 500.00, '需要安静的房间'),
(2, NULL, 3, '2026-04-05', '2026-04-07', 1, 1, '已确认', 800.00, '商务出行，需要办公设施'),
(3, NULL, 1, '2026-04-10', '2026-04-12', 1, 2, '待确认', 0.00, '首次入住'),
(4, NULL, 4, '2026-04-15', '2026-04-18', 1, 4, '待确认', 1000.00, '家庭出行'),
(5, 12, 2, '2026-04-02', '2026-04-04', 1, 2, '已入住', 500.00, '海景房优先');

INSERT INTO checkins (reservation_id, guest_id, room_id, checkin_time, checkout_time, status, staff_id) VALUES
(1, 1, 3, '2026-04-01 14:00:00', NULL, '入住中', 2),
(5, 5, 12, '2026-04-02 15:30:00', NULL, '入住中', 3);

INSERT INTO consumption_items (item_name, price, category) VALUES
('早餐', 68.00, '餐饮'),
('午餐', 128.00, '餐饮'),
('晚餐', 168.00, '餐饮'),
('迷你吧', 88.00, '饮品'),
('洗衣服务', 50.00, '服务'),
('叫醒服务', 0.00, '服务'),
('会议室', 500.00, '场地');

INSERT INTO consumption (checkin_id, item_id, quantity, amount) VALUES
(1, 1, 2, 136.00),
(1, 4, 1, 88.00);

INSERT INTO bills (checkin_id, room_charge, other_charge, total_charge, deposit, actual_pay, payment_method, invoice_status, invoice_number, checkout_time, staff_id) VALUES
(1, 1200.00, 224.00, 1424.00, 500.00, 924.00, '微信', '已开具', 'A0001', '2026-03-15 12:00:00', 2);

-- 已退房记录与历史账单（管理员营业分析、营收趋势演示）
INSERT INTO checkins (reservation_id, guest_id, room_id, checkin_time, checkout_time, status, staff_id) VALUES
(NULL, 2, 2, '2026-03-28 14:00:00', '2026-03-30 11:00:00', '已退房', 2),
(NULL, 3, 4, '2026-03-30 15:00:00', '2026-04-02 10:00:00', '已退房', 2),
(NULL, 4, 5, '2026-04-01 16:00:00', '2026-04-03 12:00:00', '已退房', 2);

INSERT INTO bills (checkin_id, room_charge, other_charge, total_charge, deposit, actual_pay, payment_method, invoice_status, invoice_number, checkout_time, staff_id) VALUES
(3, 1176.00, 0.00, 1176.00, 0.00, 1176.00, '支付宝', '已开具', 'A0002', '2026-03-30 11:00:00', 2),
(4, 1764.00, 128.00, 1892.00, 0.00, 1892.00, '刷卡', '已开具', 'A0003', '2026-04-02 10:00:00', 2),
(5, 2576.00, 88.00, 2664.00, 100.00, 2564.00, '现金', '已开具', 'A0004', '2026-04-03 12:00:00', 2);

COMMIT;
