# 酒店客房管理系统

基于 **Spring Boot + Vue 3 + Element Plus + MySQL** 的全栈酒店客房管理系统，支持多门店运营、客房管理、客人预订、入住退房、账单发票、图片上传及经营数据分析。

---

## 技术栈

| 层级 | 技术 | 版本 |
|------|------|------|
| 后端框架 | Spring Boot | 3.2.0 |
| ORM | MyBatis / MyBatis-Spring-Boot-Starter | 3.0.3 |
| 数据库 | MySQL | 8.0 |
| 认证授权 | JWT (jjwt) | 0.12.3 |
| 构建工具 | Maven | — |
| 前端框架 | Vue 3 | ^3.4.0 |
| 路由 | Vue Router | ^4.2.5 |
| UI 组件库 | Element Plus | ^2.4.4 |
| HTTP 客户端 | Axios | ^1.6.2 |
| 构建工具 | Vite | ^5.0.8 |

---

## 功能模块

### 三种角色，统一入口

| 角色 | 登录方式 | 核心功能 |
|------|----------|----------|
| **管理员** | 用户名+密码 | 全系统管理，数据分析，门店/员工/房型管理，图片上传 |
| **前台** | 用户名+密码 | 客房状态查看，预订/入住/退房办理，账单开具 |
| **客人** | 手机号+密码 | 房间预订，订单查询，个人信息管理 |

### 管理员端
- **工作台** — 实时客房概况（总数/可用/入住/维修）及入住率
- **经营分析** — 营收概览、日趋势图表、支付方式占比、账单报表
- **门店管理** — 酒店分店 CRUD，门店图片上传（自动预览/替换/删除旧图）
- **员工管理** — 员工账号 CRUD，角色分配
- **房型管理** — 房型定义及定价，房型图片上传
- **客房管理** — 房间 CRUD，状态变更
- **客人管理** — 全部客人信息管理

### 前台端（门店隔离）
- **客房状态** — 房间状态色块视图（可售/已预订/已入住/清扫中/维修中）
- **预订管理** — 创建/确认/取消预订，按状态筛选
- **入住办理** — 客人登记入住，关联预订
- **退房结算** — 退房处理，消费计费，多种支付方式（现金/刷卡/微信/支付宝）
- **发票管理** — 账单查看，发票号自动生成（A 开头流水号）
- **客人管理** — 客人信息查询维护

### 客人端
- **房间预订** — 浏览门店和房型并下单（图片动态加载）
- **我的订单** — 预订记录查看
- **个人资料** — 信息修改

### 多门店支持
- 所有资源按 `store_id` 隔离
- 非管理员员工仅能访问所属门店数据
- 跨门店访问返回 403

### 图片上传
- 管理员可为门店和房型上传图片（当前端无图片时显示品牌色占位）
- 上传文件存储在 `hotel-backend/uploads/` 目录，通过 `/uploads/**` 静态服务访问
- 更新图片时自动删除旧文件，删除门店/房型时同步清理图片
- 前端开发环境通过 Vite 代理 `/uploads` 到后端

---

## 系统架构

```
┌─────────────────────────────────────────────────────┐
│                   前端 (Vue 3)                        │
│  hotel-frontend/                                     │
│  ├── Login.vue          统一登录页                     │
│  ├── admin/             管理员模块 (8 页面)             │
│  ├── reception/         前台模块 (6 页面)              │
│  └── guest/             客人模块 (3 页面)              │
├─────────────────────────────────────────────────────┤
│  Axios ←── /api/*, /uploads/* ──→  JWT 认证拦截器     │
├─────────────────────────────────────────────────────┤
│                   后端 (Spring Boot)                   │
│  hotel-backend/                                      │
│  ├── controller/        13 个 REST 控制器              │
│  ├── service/           12 个业务服务                   │
│  ├── mapper/            12 个 MyBatis 映射器            │
│  ├── entity/            11 个实体类                    │
│  ├── config/            JWT / 拦截器 / 静态资源配置     │
│  └── uploads/           上传图片存储目录                │
├─────────────────────────────────────────────────────┤
│                   数据库 (MySQL)                       │
│  11 张表：stores, room_types, rooms, guests,          │
│  roles, staff, reservations, checkins,                │
│  consumption_items, consumption, bills                │
└─────────────────────────────────────────────────────┘
```

### API 路由 (`/api`)

| 控制器 | 基础路径 | 说明 |
|--------|----------|------|
| AuthController | `/api/auth` | 登录 / 客人注册 |
| StoreController | `/api/stores` | 门店 CRUD |
| RoomTypeController | `/api/room-types` | 房型 CRUD |
| RoomController | `/api/rooms` | 客房 CRUD，状态变更 |
| GuestController | `/api/guests` | 客人 CRUD |
| StaffController | `/api/staff` | 员工 CRUD |
| ReservationController | `/api/reservations` | 预订管理，状态流转 |
| CheckinController | `/api/checkins` | 入住 / 退房 |
| BillController | `/api/bills` | 账单 / 发票 |
| ConsumptionController | `/api/consumption` | 消费记录 CRUD |
| ConsumptionItemController | `/api/consumption-items` | 消费项目目录 |
| StatisticsController | `/api/statistics` | 经营数据统计（管理员专享） |
| UploadController | `/api/upload` | 图片上传（门店/房型） |

---

## 快速开始

### 环境要求
- **JDK 17+**
- **Maven 3.6+**
- **MySQL 8.0+**（运行在 `localhost:3306`）
- **Node.js 18+** / npm

### 1. 导入数据库

```bash
mysql -u root -p < hotel_management.sql
```

### 2. 配置数据库连接

编辑 `hotel-backend/src/main/resources/application.yml`，确保 MySQL 连接信息正确（默认：`root` / `123456`）。

### 3. 启动后端

```bash
cd hotel-backend
mvn spring-boot:run
```

后端服务启动在 **http://localhost:8080**。

### 4. 启动前端

```bash
cd hotel-frontend
npm install
npm run dev
```

前端开发服务启动在 **http://localhost:5173**。

---

## 测试账号

| 角色 | 用户名 | 密码 |
|------|--------|------|
| 管理员（系统） | `admin` | `123456` |
| 管理员（门店） | `admin2` | `123456` |
| 前台（门店1） | `reception1` | `123456` |
| 前台（门店2） | `reception2` | `123456` |
| 客人 | `13800138001`（手机号） | `123456` |

---

## 项目结构

```
aicode/
├── README.md                          # 本文件
├── hotel_management.sql               # 数据库建表脚本 + 种子数据（含图片路径）
├── hotel-backend/                     # Spring Boot 后端
│   ├── pom.xml
│   ├── uploads/                       # 图片上传存储目录
│   │   ├── stores/                    #   门店图片
│   │   └── room-types/               #   房型图片
│   └── src/main/
│       ├── java/com/hotel/
│       │   ├── HotelManagementApplication.java
│       │   ├── common/Result.java
│       │   ├── config/                 # JWT / 拦截器 / 静态资源配置
│       │   ├── controller/             # 13 个控制器
│       │   ├── service/                # 业务逻辑（含图片清理）
│       │   ├── mapper/                 # MyBatis 映射接口
│       │   ├── entity/                 # 实体类（store/roomType 含 image 字段）
│       │   └── dto/                    # 数据传输对象
│       └── resources/
│           ├── application.yml         # 含 multipart 上传配置及 upload-dir
│           └── mapper/                 # MyBatis XML 映射文件
└── hotel-frontend/                     # Vue 3 前端
    ├── package.json
    ├── vite.config.js                  # 含 /api 及 /uploads 代理配置
    └── src/
        ├── main.js
        ├── App.vue
        ├── router/index.js             # 路由（含角色守卫）
        ├── api/index.js                # Axios 封装 + 全部接口（含文件上传）
        ├── utils/authStorage.js        # 认证 Token 存储
        └── views/
            ├── Login.vue
            ├── admin/                   # 管理员页面（门店/房型含图片上传）
            ├── reception/               # 前台页面
            └── guest/                   # 客人页面（动态加载门店/房型图片）
```
